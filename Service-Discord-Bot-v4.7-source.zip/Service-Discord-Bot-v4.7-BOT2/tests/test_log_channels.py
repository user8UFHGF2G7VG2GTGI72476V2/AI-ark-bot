import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
import test_bot
import db
import ark_feed
import log_channels
import nitrado_api
import asyncio
import unittest


class Role:
    def __init__(self,default=False): self.default=default
    def is_default(self): return self.default


class Resource:
    def __init__(self,identity,**kwargs):
        self.id=identity
        self.mention=f'<#{identity}>'
        self.messages=[]
        self.__dict__.update(kwargs)
    async def edit(self,**kwargs): self.__dict__.update(kwargs)
    async def send(self,*args,**kwargs):
        attachment=kwargs.get('file')
        self.messages.append(attachment.fp.read().decode() if attachment else str(kwargs.get('embed') or args))


class Category(Resource): pass
class Channel(Resource): pass


class Guild:
    id=1
    def __init__(self):
        self.default_role=Role(True)
        self.me=object()
        self.resources={}
        self.count=100
    def get_channel(self,identity): return self.resources.get(identity)
    async def create_category(self,name,**kwargs): return self.add(Category,name,kwargs)
    async def create_text_channel(self,name,**kwargs): return self.add(Channel,name,kwargs)
    def add(self,cls,name,kwargs):
        self.count+=1
        resource=cls(self.count,name=name,**kwargs)
        self.resources[resource.id]=resource
        return resource


class LogChannelTests(unittest.TestCase):
    # Reuse only database isolation helpers, not inherited tests.
    setUp=test_bot.DatabaseTest.setUp
    tearDown=test_bot.DatabaseTest.tearDown

    def environment(self,sample='Alice killed Bob\nAdmin used cheat\nPlayer joined this ARK\n'):
        guild=Guild()
        api=SimpleNamespace(service=AsyncMock(return_value='42'),log_tail=AsyncMock(return_value=sample))
        bot=SimpleNamespace(nitrado_api=api)
        feed=ark_feed.FeedCog(bot,api)
        feed.file_size=AsyncMock(return_value=100)
        bot.get_cog=lambda name:feed
        cog=log_channels.LogChannelsCog(bot)
        i=SimpleNamespace(guild_id=1,guild=guild,response=SimpleNamespace(defer=AsyncMock(),send_message=AsyncMock()),followup=SimpleNamespace(send=AsyncMock()))
        return cog,i,feed

    def run_setup(self,cog,i,staff,**kwargs):
        with patch.object(log_channels.discord,'CategoryChannel',Category),patch.object(log_channels.discord,'TextChannel',Channel):
            asyncio.run(cog.logs_setup.callback(cog,i,staff,**kwargs))

    def test_private_overwrites_deny_public_and_allow_readonly_staff(self):
        guild=Guild()
        staff=Role()
        permissions=log_channels.private_overwrites(guild,staff)
        self.assertFalse(permissions[guild.default_role].view_channel)
        self.assertTrue(permissions[staff].view_channel)
        self.assertFalse(permissions[staff].send_messages)
        self.assertTrue(permissions[guild.me].send_messages)
        self.assertEqual(len(permissions),3)
        with self.assertRaises(nitrado_api.NitradoError): log_channels.private_overwrites(guild,guild.default_role)

    def test_only_recognized_event_routes_are_selected(self):
        self.assertEqual(log_channels.observed_routes('Server started',ark_feed.DEFAULT_KILL),{'all'})
        self.assertEqual(log_channels.observed_routes('Alice killed Bob\nPlayer joined\nAdmin cheat',ark_feed.DEFAULT_KILL),{'all','kills','joins','admin'})

    def test_setup_is_idempotent_and_preserves_cursor_and_repairs_permissions(self):
        cog,i,feed=self.environment()
        staff=Role()
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'42'}):
            self.run_setup(cog,i,staff,service='42',file='/game.log')
            identities=set(i.guild.resources)
            channels=[r for r in i.guild.resources.values() if isinstance(r,Channel)]
            self.assertEqual(len(channels),6)
            with db.conn() as c: c.execute("UPDATE ark_feed SET offset=17,pending=X'6162' WHERE service='42'")
            for channel in channels: channel.overwrites={i.guild.default_role:log_channels.discord.PermissionOverwrite(view_channel=True)}
            self.run_setup(cog,i,staff,service='42',file='/game.log')
        self.assertEqual(set(i.guild.resources),identities)
        for channel in channels:
            self.assertFalse(channel.overwrites[i.guild.default_role].view_channel)
            self.assertTrue(channel.overwrites[staff].view_channel)
        with db.conn() as c:
            row=c.execute('SELECT * FROM ark_feed').fetchone()
            self.assertEqual(row['offset'],17)
            self.assertEqual(bytes(row['pending']),b'ab')
        self.assertEqual(set(db.get_setting(1,'ark_routes:42')),{'kills','kd','admin','joins'})
        self.assertIsNotNone(db.get_setting(1,'ticket_log_channel_id'))

    def test_empty_history_still_creates_and_wires_all_implemented_channels(self):
        cog,i,feed=self.environment('Server started\n')
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'42'}): self.run_setup(cog,i,Role(),service='42',file='/game.log')
        names={r.name for r in i.guild.resources.values() if isinstance(r,Channel)}
        self.assertEqual(names,{'🎫・ticket-transcripts','📋・server-logs','⚔️・kill-logs','📊・kd-logs','🛠️・admin-logs','🚪・join-leave-logs'})
        self.assertEqual(set(db.get_setting(1,'ark_routes:42')),{'kills','kd','admin','joins'})

    def test_unreadable_log_creates_channels_with_explicit_disconnected_status(self):
        cog,i,feed=self.environment()
        feed.file_size.side_effect=nitrado_api.NitradoError('Unreadable log')
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'42'}):
            self.run_setup(cog,i,Role(),service='42',file='/game.log')
        self.assertEqual(len([r for r in i.guild.resources.values() if isinstance(r,Channel)]),6)
        self.assertIn('not connected',i.followup.send.call_args.kwargs['embed'].title)
        self.assertEqual(set(db.get_setting(1,'ark_pending_routes:42')),{'all','kills','kd','admin','joins'})

    def test_without_token_refuses_to_claim_game_log_setup_complete(self):
        cog,i,feed=self.environment()
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'','NITRADO_TOKEN':''}):
            with self.assertRaises(nitrado_api.NitradoError): self.run_setup(cog,i,Role())
        self.assertEqual(i.guild.resources,{})
        cog.bot.nitrado_api.service.assert_not_awaited()

    def test_setup_without_ids_checks_every_discovered_service(self):
        cog,i,feed=self.environment()
        cog.setup_one=AsyncMock(return_value=log_channels.discord.Embed(description='Configured private channels'))
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'42,43'}):
            asyncio.run(cog.logs_setup.callback(cog,i,Role()))
        self.assertEqual([call.args[2] for call in cog.setup_one.await_args_list],['42','43'])
        i.response.defer.assert_awaited_once()
        i.followup.send.assert_awaited_once()

    def test_live_worker_routes_each_new_event_to_its_saved_channel(self):
        cog,i,feed=self.environment()
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'42'}): self.run_setup(cog,i,Role(),service='42',file='/game.log')
        data=b'Alice killed Bob\nAdmin used cheat\nPlayer joined this ARK\nServer tick\n'
        feed.file_size=AsyncMock(return_value=100+len(data))
        feed.read_chunk=AsyncMock(return_value=data)
        feed.sample_playtime=AsyncMock()
        cog.bot.get_channel=i.guild.get_channel
        with db.conn() as c: row=dict(c.execute('SELECT * FROM ark_feed').fetchone())
        asyncio.run(feed.step(row))
        routes=db.get_setting(1,'ark_routes:42')
        self.assertEqual(i.guild.get_channel(routes['kills']).messages,['Alice killed Bob'])
        self.assertIn('Alice K/D: 1/0',i.guild.get_channel(routes['kd']).messages[0])
        self.assertIn('Bob K/D: 0/1',i.guild.get_channel(routes['kd']).messages[0])
        self.assertEqual(i.guild.get_channel(routes['admin']).messages,['Admin used cheat'])
        self.assertEqual(i.guild.get_channel(routes['joins']).messages,['Player joined this ARK'])
        self.assertIn('Server tick',i.guild.get_channel(row['channel_id']).messages[0])
        with db.conn() as c: self.assertEqual(c.execute('SELECT COUNT(*) FROM ark_events WHERE delivered=0').fetchone()[0],0)

    def test_log_discovery_searches_known_ark_directories(self):
        from log_sources import find_log
        api=SimpleNamespace(details=AsyncMock(return_value={}))
        async def response(method,path,**kwargs):
            if path.endswith('/bookmarks'): return {'bookmarks':['/arkse/ShooterGame/Saved/Logs']}
            return {'entries':[{'type':'file','path':'/arkse/ShooterGame/Saved/Logs/ShooterGame.log','name':'ShooterGame.log','modified_at':123}]}
        api.request=AsyncMock(side_effect=response)
        self.assertEqual(asyncio.run(find_log(api,'42')),'/arkse/ShooterGame/Saved/Logs/ShooterGame.log')


if __name__=='__main__': unittest.main()

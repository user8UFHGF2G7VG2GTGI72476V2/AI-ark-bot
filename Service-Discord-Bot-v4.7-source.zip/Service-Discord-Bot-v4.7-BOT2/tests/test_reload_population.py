import asyncio
import importlib
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'bot'))
import db
import main
import population


class PopulationTests(unittest.TestCase):
    def test_real_browser_fields_match_froakie_and_include_empty_servers(self):
        rows=population.parse_feed([
            {'Name':"[EU] FROAKIE SOLO'S - 20X - RAG",'NumPlayers':0,'MaxPlayers':20,'MapName':'Ragnarok','SearchTags':['crossplayallowxbox','crossplayallowuwp']},
            {'Name':"[EU] FROAKIE SOLO'S - 20X - EXT",'NumPlayers':3,'MaxPlayers':20,'MapName':'Extinction','SearchTags':['crossplayallowxbox','crossplayallowuwp']},
            {'Name':'Another server','NumPlayers':1,'MaxPlayers':10},
        ],'xbox')
        matches=population.matching(rows,'froakie solos')
        self.assertEqual(len(matches),2)
        self.assertEqual([r['players'] for r in matches],[3,0])
        self.assertEqual(matches[1]['map'],'Ragnarok')
        self.assertEqual(matches[0]['platform'],'Xbox / Windows 10')

    def test_missing_population_is_unknown_not_zero(self):
        rows=population.parse_feed([{'Name':'Froakie','MaxPlayers':20}],'xbox')
        self.assertIsNone(rows[0]['players'])

    def test_platform_filter_and_malformed_rows(self):
        rows=population.parse_feed([None,{}, {'Name':'Same','NumPlayers':1}, {'Name':'Crossplay','NumPlayers':2,'SearchTags':['crossplayallowuwp']}],'xbox')
        self.assertEqual([r['name'] for r in population.matching(rows,'cross',platform='xw10')],['Crossplay'])
        self.assertEqual(population.matching(rows,'same',platform='xw10'),[])
        with self.assertRaises(population.FeedError): population.parse_feed({},'xbox')

    def test_one_provider_failure_does_not_hide_other_provider_matches(self):
        async def check():
            cog=population.PopulationCog(None)
            row=population.parse_feed([{'Name':'Froakie','NumPlayers':2}],'xbox')
            cog.fetch=AsyncMock(side_effect=[(row,123,False),population.FeedError('PlayStation unavailable')])
            matches,notices,timestamp=await cog.search('froakie')
            self.assertEqual(len(matches),1)
            self.assertEqual(timestamp,123)
            self.assertIn('PlayStation unavailable',notices)
        asyncio.run(check())


class ReloadTests(unittest.TestCase):
    def setUp(self):
        scratch=Path(__file__).resolve().parents[2]/'test-temp'
        scratch.mkdir(exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(dir=scratch)
        self.previous=db.DB
        db.DB=Path(self.tmp.name)/'bot.sqlite'
        db.init()

    def tearDown(self):
        db.DB=self.previous
        self.tmp.cleanup()

    async def loaded_bot(self):
        bot=main.FentDiscordManager()
        await bot.__aenter__()
        for name in main.STARTUP_EXTENSIONS: await bot.load_extension(name)
        return bot

    def test_repeated_reload_preserves_state_and_stops_previous_workers(self):
        async def check():
            bot=await self.loaded_bot()
            try:
                initial={cmd.name for cmd in bot.tree.get_commands()}
                client=bot.nitrado_api
                config_lock=bot.nitrado_config_lock
                bot.get_cog('InviteCog').cache[1]={'example':(3,7)}
                with db.conn() as c:
                    c.execute("INSERT INTO ark_feed(guild_id,service,path,channel_id,kill_pattern,offset) VALUES(1,'42','/log',7,'unused',123)")
                for _ in range(2):
                    old_feed=bot.get_cog('FeedCog').poller.get_task()
                    old_giveaway=bot.get_cog('GiveawayCog').ender.get_task()
                    old_view=bot.get_cog('GiveawayCog').view
                    completed,failed,error=await bot.get_cog('MaintenanceCog').reload_features(list(importlib.import_module('extensions').FEATURE_EXTENSIONS))
                    self.assertIsNone(failed,error)
                    self.assertEqual(len(completed),len(__import__("extensions").FEATURE_EXTENSIONS))
                    self.assertTrue(old_feed.done())
                    self.assertTrue(old_giveaway.done())
                    self.assertTrue(old_view.is_finished())
                    self.assertIsNot(old_feed,bot.get_cog('FeedCog').poller.get_task())
                    self.assertIs(bot.nitrado_api,client)
                    self.assertIs(bot.nitrado_config_lock,config_lock)
                    self.assertEqual(bot.get_cog('InviteCog').cache[1],{'example':(3,7)})
                    self.assertEqual({cmd.name for cmd in bot.tree.get_commands()},initial)
                    self.assertEqual(len(bot.persistent_views),2)
                with db.conn() as c: self.assertEqual(c.execute('SELECT offset FROM ark_feed').fetchone()[0],123)
            finally: await bot.close()
        asyncio.run(check())

    def test_reload_is_owner_only_even_for_discord_admin(self):
        async def check():
            bot=await self.loaded_bot()
            try:
                bot.is_owner=AsyncMock(return_value=False)
                i=SimpleNamespace(user=SimpleNamespace(id=3,guild_permissions=SimpleNamespace(administrator=True)))
                with self.assertRaises(main.discord.app_commands.CheckFailure): await bot.get_cog('MaintenanceCog').owner(i)
                bot.is_owner.return_value=True
                await bot.get_cog('MaintenanceCog').owner(i)
            finally: await bot.close()
        asyncio.run(check())

    def test_failed_extension_reload_restores_old_module(self):
        async def check():
            bot=await self.loaded_bot()
            root=Path(self.tmp.name)
            path=root/'reload_fixture.py'
            path.write_text("async def setup(bot):\n    bot.reload_probe='original'\n",encoding='utf-8')
            sys.path.insert(0,str(root))
            try:
                await bot.load_extension('reload_fixture')
                old=bot.extensions['reload_fixture']
                path.write_text("async def setup(bot):\n    raise RuntimeError('broken update')\n",encoding='utf-8')
                module=bot.extensions['maintenance']
                with patch.object(module,'FEATURE_EXTENSIONS',('reload_fixture',)),patch.object(module,'__file__',str(root/'maintenance.py')):
                    completed,failed,error=await bot.get_cog('MaintenanceCog').reload_features(['reload_fixture'])
                self.assertEqual(completed,[])
                self.assertEqual(failed,'reload_fixture')
                self.assertEqual(error,'ExtensionFailed')
                self.assertIs(bot.extensions['reload_fixture'],old)
                self.assertEqual(bot.reload_probe,'original')
            finally:
                await bot.close()
                sys.path.remove(str(root))
        asyncio.run(check())

    def test_syntax_error_is_rejected_before_unload(self):
        async def check():
            bot=await self.loaded_bot()
            try:
                root=Path(self.tmp.name)
                (root/'general.py').write_text('def broken(:',encoding='utf-8')
                module=bot.extensions['maintenance']
                original=bot.get_cog('GeneralCog')
                with patch.object(module,'__file__',str(root/'maintenance.py')):
                    with self.assertRaises(SyntaxError): await bot.get_cog('MaintenanceCog').reload_features(['general'])
                self.assertIs(bot.get_cog('GeneralCog'),original)
            finally: await bot.close()
        asyncio.run(check())


if __name__=='__main__': unittest.main()

import asyncio
import os
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'bot'))
import db
import general
import economy
import hype
import nitrado
import ark_feed
import nitrado_config


class DatabaseTest(unittest.TestCase):
    def setUp(self):
        scratch=Path(__file__).resolve().parents[2]/'test-temp'
        scratch.mkdir(exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(dir=scratch)
        self.original=db.DB
        db.DB=Path(self.tmp.name)/'test.sqlite'
        db.init()
        general.init_tables()
        economy.init_tables()
        hype.init_tables()
        ark_feed.init_tables()

    def tearDown(self):
        db.DB=self.original
        self.tmp.cleanup()

    def interaction(self,uid=2):
        return SimpleNamespace(guild_id=1,user=SimpleNamespace(id=uid),response=SimpleNamespace(send_message=AsyncMock()))

    def test_credit_transfer_and_insufficient_funds_rollback(self):
        economy.add(1,2,'credits',150)
        self.assertTrue(economy.transfer(1,2,3,'credits',100))
        self.assertFalse(economy.transfer(1,2,3,'credits',100))
        self.assertEqual((economy.balance(1,2,'credits'),economy.balance(1,3,'credits')),(50,100))

    def test_daily_cannot_be_claimed_twice(self):
        ok,_=economy.claim_daily(1,2,100,now=1_000_000)
        again,nxt=economy.claim_daily(1,2,100,now=1_000_100)
        self.assertTrue(ok); self.assertFalse(again); self.assertEqual(nxt,1_000_000+86400)
        self.assertTrue(economy.claim_daily(1,2,100,now=1_000_000+86400)[0])
        self.assertEqual(economy.balance(1,2,'credits'),200)

    def test_buy_spins_is_atomic(self):
        economy.add(1,2,'credits',25)
        self.assertIsNone(economy.buy(1,2,'spins',3,10))
        self.assertEqual(economy.balance(1,2,'credits'),25)
        self.assertEqual(economy.buy(1,2,'spins',2,10),2)
        self.assertEqual(economy.balance(1,2,'credits'),5)

    def test_take_never_goes_negative(self):
        economy.add(1,2,'boxes',2)
        self.assertIsNone(economy.take(1,2,'boxes',3))
        self.assertEqual(economy.take_up_to(1,2,'boxes',5),(2,0))

    def test_old_wallets_migrate_once(self):
        with db.conn() as c:
            c.execute('DELETE FROM settings WHERE guild_id=0')
            c.execute('INSERT INTO wallets(guild_id,user_id,balance,daily) VALUES(1,9,300,5)')
        economy.init_tables(); economy.init_tables()
        self.assertEqual(economy.balance(1,9,'credits'),300)

    def test_wheel_lands_on_picked_slice(self):
        import wheel_render
        gif,ms=wheel_render.render_spin(['A','B','C'],[1,2,1],1,frames=6)
        self.assertTrue(gif.startswith(b'GIF')); self.assertGreater(ms,0)

    def test_prize_pool_seed_add_remove(self):
        opts=economy.pool_options(1,'wheel')
        self.assertEqual(len(opts),len(economy.DEFAULT_PRIZES))
        self.assertFalse(economy.pool_upsert(1,'wheel','Gold',5))
        self.assertTrue(economy.pool_upsert(1,'wheel','gold',2))
        self.assertEqual(economy.pool_remove(1,'wheel','GOLD'),1)
        economy.pool_clear(1,'wheel')
        self.assertEqual(economy.pool_options(1,'wheel'),[])

    def test_log_chunk_boundaries_and_replay_do_not_duplicate_kills(self):
        with db.conn() as c:
            c.execute('INSERT INTO ark_feed(guild_id,service,path,channel_id,kill_pattern,ready) VALUES(1,\'42\',\'/server.log\',9,?,1)',(ark_feed.DEFAULT_KILL,))
            row=dict(c.execute('SELECT * FROM ark_feed').fetchone())
        data=b'Alice killed Bo'
        ark_feed.ingest(row,data,len(data))
        with db.conn() as c: row2=dict(c.execute('SELECT * FROM ark_feed').fetchone())
        rest=b'b\nServer status\n'
        ark_feed.ingest(row2,rest,len(data)+len(rest))
        ark_feed.ingest(row2,rest,len(data)+len(rest))
        with db.conn() as c:
            kills=c.execute('SELECT killer,victim FROM ark_events WHERE killer IS NOT NULL').fetchall()
            self.assertEqual([(r[0],r[1]) for r in kills],[('Alice','Bob')])
            self.assertEqual(c.execute('SELECT COUNT(*) FROM ark_events').fetchone()[0],2)

    def test_name_resolution_rejects_ambiguity_and_partial_names(self):
        players=[{'name':'Bob','id':'1'},{'name':'Bob','id':'2'}]
        with self.assertRaises(nitrado.NitradoError): nitrado.resolve_name(players,'Bob')
        with self.assertRaises(nitrado.NitradoError): nitrado.resolve_name(players,'Bo')
        self.assertEqual(nitrado.resolve_name(players[:1],'bOb')['id'],'1')

    def test_target_hierarchy(self):
        i=SimpleNamespace(user=SimpleNamespace(id=2,top_role=10),client=SimpleNamespace(user=SimpleNamespace(id=3)),guild=SimpleNamespace(owner_id=1,me=SimpleNamespace(top_role=20)))
        for member in [SimpleNamespace(id=1,top_role=0),SimpleNamespace(id=2,top_role=10),SimpleNamespace(id=4,top_role=10)]:
            with self.assertRaises(nitrado.app_commands.CheckFailure): general.target_check(i,member)
        general.target_check(i,SimpleNamespace(id=4,top_role=9))

    def test_platform_capability_prevents_write(self):
        api=nitrado.Client()
        api.request=AsyncMock(return_value={'player_lists':[]})
        with self.assertRaises(nitrado.NitradoError): asyncio.run(api.lists('42','banlist'))
        self.assertEqual(api.request.await_count,1)

    def test_service_allowlist(self):
        api=nitrado.Client()
        with patch.dict(os.environ,{'NITRADO_SERVICE_IDS':'42,43'}):
            self.assertEqual(asyncio.run(api.service(1,'42')),'42')
            with self.assertRaises(nitrado.NitradoError): asyncio.run(api.service(1,'99'))

    def test_all_cogs_register_and_commands_serialize(self):
        import main
        async def check():
            async with main.FentDiscordManager() as bot:
                for name in main.STARTUP_EXTENSIONS: await bot.load_extension(name)
                cmds=bot.tree.get_commands()
                names={cmd.name for cmd in cmds}
                self.assertTrue({'ticket','giveaway','nitrado','pop','credit','wheel','mysterybox','prizes','economy','nametag','link','hype','kd','playtime','kick','ban','timeout','invite-leaderboard','reload','sync-commands'}<=names)
                self.assertLessEqual(len(cmds),100)
                for cmd in cmds:
                    payload=cmd.to_dict(bot.tree)
                    self.assertLessEqual(len(payload.get('options',[])),25)
        asyncio.run(check())

    def test_ticket_does_not_delete_when_transcript_cannot_be_read(self):
        import tickets
        class BrokenChannel:
            id=7
            name='test-ticket'
            delete=AsyncMock()
            def permissions_for(self,member): return SimpleNamespace(manage_channels=True)
            async def history(self,**kwargs):
                raise RuntimeError('history unavailable')
                yield
        channel=BrokenChannel()
        i=SimpleNamespace(user=SimpleNamespace(id=2),channel=channel,guild=SimpleNamespace(id=1,me=None),response=SimpleNamespace(defer=AsyncMock()),followup=SimpleNamespace(send=AsyncMock()))
        with db.conn() as c:
            c.execute("INSERT INTO tickets(channel_id,guild_id,opener_id,kind,opened_at) VALUES(7,1,2,'support',0)")
        with patch.object(tickets,'can_close',return_value=True),patch.object(db,'DATA',Path(self.tmp.name)):
            asyncio.run(tickets.close_ticket_interaction(i))
        channel.delete.assert_not_awaited()
        with db.conn() as c: self.assertEqual(c.execute('SELECT status FROM tickets').fetchone()[0],'open')

    def test_kill_parser_ignores_noise_and_suicide(self):
        self.assertEqual(ark_feed.parse_kill('Alice killed Bob'),('Alice','Bob'))
        self.assertIsNone(ark_feed.parse_kill('Server is starting'))
        self.assertIsNone(ark_feed.parse_kill('Alice killed Alice'))

    def test_env_save_preserves_other_settings_and_survives_reload(self):
        from dotenv import dotenv_values
        target=Path(self.tmp.name)/'.env'
        target.write_text('# my settings\nDISCORD_TOKEN=keep-me\nARK_LOG_POLL_SECONDS=1\nNITRADO_SERVICE_IDS=42\n',encoding='utf-8')
        with patch.dict(os.environ,{},clear=False):
            nitrado_config.save_config('test-token',['42','43'],target)
            self.assertEqual(os.environ['NITRADO_TOKEN'],'test-token')
            self.assertEqual(nitrado.service_ids(),['42','43'])
        restored=dotenv_values(target)
        self.assertEqual(restored['NITRADO_TOKEN'],'test-token')
        self.assertEqual(restored['NITRADO_SERVICE_IDS'],'42,43')
        self.assertEqual(restored['DISCORD_TOKEN'],'keep-me')
        self.assertEqual(restored['ARK_LOG_POLL_SECONDS'],'1')
        self.assertIn('# my settings',target.read_text())

    def test_env_failure_keeps_previous_file_and_process(self):
        target=Path(self.tmp.name)/'.env'
        target.write_text('DISCORD_TOKEN=keep-me\n',encoding='utf-8')
        with patch.dict(os.environ,{'NITRADO_TOKEN':'old','NITRADO_SERVICE_IDS':'42'}):
            with patch.object(nitrado_config.os,'replace',side_effect=OSError('write failed')):
                with self.assertRaises(OSError): nitrado_config.save_config('new',['43'],target)
            self.assertEqual(os.environ['NITRADO_TOKEN'],'old')
            self.assertEqual(os.environ['NITRADO_SERVICE_IDS'],'42')
        self.assertEqual(target.read_text(),'DISCORD_TOKEN=keep-me\n')
        self.assertEqual(list(Path(self.tmp.name).glob('.nitrado-*.tmp')),[])

    def test_service_id_parsing(self):
        self.assertEqual(nitrado_config.parse_service_ids('42,43\n42; 0044'),['42','43','44'])
        for raw in ('','42,bad','0','-42','42/other'):
            with self.assertRaises(ValueError): nitrado_config.parse_service_ids(raw)

    def config_group(self):
        api=SimpleNamespace(request=AsyncMock(return_value={'gameserver':{'status':'started'}}))
        cog=SimpleNamespace(api=api,config_lock=asyncio.Lock())
        return nitrado.NitradoGroup(cog)

    def test_discord_setup_validates_and_appends_all_ids(self):
        group=self.config_group()
        i=self.interaction()
        i.response.defer=AsyncMock()
        i.followup=SimpleNamespace(send=AsyncMock())
        target=Path(self.tmp.name)/'.env'
        def save(token,ids): nitrado_config.save_config(token,ids,target)
        with patch.dict(os.environ,{'NITRADO_TOKEN':'old','NITRADO_SERVICE_IDS':'42'}),patch.object(nitrado,'save_config',side_effect=save):
            asyncio.run(group.configure(i,'43,44,43','new-token'))
            self.assertEqual(nitrado.service_ids(),['42','43','44'])
            self.assertEqual(os.environ['NITRADO_TOKEN'],'new-token')
        self.assertEqual(group.api.request.await_count,3)
        for call in group.api.request.await_args_list: self.assertEqual(call.kwargs['token_override'],'new-token')
        self.assertEqual(str(db.get_setting(1,'nitrado_service')),'43')
        self.assertNotIn('new-token',str(i.followup.send.call_args))

    def test_discord_setup_rejects_credentials_without_saving(self):
        group=self.config_group()
        group.api.request.side_effect=nitrado.NitradoError('Nitrado denied access.')
        i=self.interaction()
        i.response.defer=AsyncMock()
        with patch.dict(os.environ,{'NITRADO_TOKEN':'old','NITRADO_SERVICE_IDS':'42'}),patch.object(nitrado,'save_config') as save:
            with self.assertRaises(nitrado.NitradoError): asyncio.run(group.configure(i,'43','invalid'))
            save.assert_not_called()
            self.assertEqual(os.environ['NITRADO_TOKEN'],'old')
            self.assertEqual(nitrado.service_ids(),['42'])

    def test_modal_rechecks_administrator_permission(self):
        async def check():
            modal=nitrado.SetupModal(self.config_group(),2,1)
            i=self.interaction()
            i.user.guild_permissions=SimpleNamespace(administrator=False)
            self.assertFalse(await modal.interaction_check(i))
            i.user.guild_permissions.administrator=True
            self.assertTrue(await modal.interaction_check(i))
            i.user.id=3
            self.assertFalse(await modal.interaction_check(i))
        asyncio.run(check())

    def test_service_remove_stops_only_removed_service_and_updates_default(self):
        group=self.config_group()
        i=self.interaction()
        i.response.defer=AsyncMock()
        i.followup=SimpleNamespace(send=AsyncMock())
        with db.conn() as c:
            for sid in ('42','43'):
                c.execute('INSERT INTO ark_feed(guild_id,service,path,channel_id,kill_pattern,ready) VALUES(1,?,\'/log.txt\',9,?,1)',(sid,ark_feed.DEFAULT_KILL))
        db.set_setting(1,'nitrado_service','42')
        target=Path(self.tmp.name)/'.env'
        def save(token,ids): nitrado_config.save_config(token,ids,target)
        with patch.dict(os.environ,{'NITRADO_TOKEN':'saved','NITRADO_SERVICE_IDS':'42,43'}),patch.object(nitrado,'save_config',side_effect=save):
            asyncio.run(group.service_remove.callback(group,i,'42'))
            self.assertEqual(nitrado.service_ids(),['43'])
        self.assertEqual(db.get_setting(1,'nitrado_service'),'43')
        with db.conn() as c:
            self.assertEqual([(r[0],r[1]) for r in c.execute('SELECT service,ready FROM ark_feed ORDER BY service')],[('42',0),('43',1)])

    def test_token_only_setup_discovers_multiple_servers_and_saves_ids(self):
        group=self.config_group()
        async def response(method,path,**kwargs):
            if path=='/services': return {'services':[{'id':42,'type':'gameserver'},{'id':9,'type':'domain'}]}
            if path=='/uwp/services/list': return {'services':[{'id':42,'type':'gameserver'},{'id':43,'type':'gameserver'}]}
            return {'gameserver':{'game':'arkxb' if '43' in path else 'arkse','game_specific':{'log_files':['/game.log']}}}
        group.api.request=AsyncMock(side_effect=response)
        i=self.interaction()
        i.response.defer=AsyncMock()
        i.followup=SimpleNamespace(send=AsyncMock())
        target=Path(self.tmp.name)/'.env'
        def save(token,ids): nitrado_config.save_config(token,ids,target)
        with patch.dict(os.environ,{'NITRADO_TOKEN':'old','NITRADO_SERVICE_IDS':'999'}),patch.object(nitrado,'save_config',side_effect=save):
            asyncio.run(group.configure(i,new_token='candidate'))
            self.assertEqual(nitrado.service_ids(),['42','43'])
        self.assertEqual(group.api.request.await_count,4)
        self.assertEqual(db.get_setting(1,'nitrado_service'),'42')
        self.assertEqual(db.get_setting(1,'ark_discovered_logs:43'),['/game.log'])
        self.assertNotIn('candidate',str(i.followup.send.call_args))

    def test_token_only_setup_rejects_no_ase_without_saving(self):
        group=self.config_group()
        async def response(method,path,**kwargs):
            if path in ('/services','/uwp/services/list'): return {'services':[{'id':42,'type':'gameserver'}]}
            return {'gameserver':{'game':'arksa'}}
        group.api.request=AsyncMock(side_effect=response)
        i=self.interaction()
        i.response.defer=AsyncMock()
        with patch.object(nitrado,'save_config') as save:
            with self.assertRaises(nitrado.NitradoError): asyncio.run(group.configure(i,new_token='candidate'))
            save.assert_not_called()

    def test_discovery_uses_xbox_fallback_and_reports_partial_access(self):
        from nitrado_discovery import discover_services
        group=self.config_group()
        async def response(method,path,**kwargs):
            if path=='/services': raise nitrado.NitradoError('Access denied')
            if path=='/uwp/services/list': return {'services':[{'id':43,'type':'gameserver'}]}
            return {'gameserver':{'game':'arkxb'}}
        group.api.request=AsyncMock(side_effect=response)
        rows,notes=asyncio.run(discover_services(group.api,'candidate'))
        self.assertEqual(list(rows),['43'])
        self.assertTrue(notes)

    def test_nitrado_setup_form_only_asks_for_token(self):
        async def check():
            modal=nitrado.SetupModal(self.config_group(),2,1)
            self.assertEqual(len(modal.children),1)
            self.assertIn('token',modal.children[0].label.lower())
        asyncio.run(check())


if __name__=='__main__': unittest.main()

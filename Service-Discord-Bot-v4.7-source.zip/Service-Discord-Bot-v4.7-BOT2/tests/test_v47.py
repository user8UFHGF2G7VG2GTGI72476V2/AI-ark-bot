import asyncio
import json
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'bot'))
import db
import ark_feed
import embeds
import playtime
import notifiers
import xbox_link
import ark_services
import economy
import findlog
import kd
import ca


def fake_guild(gid=1, channels=()):
    chans = [SimpleNamespace(id=cid, name=name, mention=f'<#{cid}>') for cid, name in channels]
    return SimpleNamespace(id=gid, name='Energy', icon=None, member_count=50, channels=chans,
                           get_channel=lambda cid: next((c for c in chans if c.id == cid), None), get_member=lambda uid: None,
                           get_role=lambda rid: None)


def in_loop(fn, *args):
    async def run():
        return fn(*args)
    return asyncio.run(run())


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.original = db.DB
        db.DB = Path(self.tmp.name) / 't.sqlite'
        db.init()
        for mod in (ark_feed, embeds, playtime, notifiers, xbox_link, economy, kd, ca):
            mod.init_tables()

    def tearDown(self):
        db.DB = self.original
        self.tmp.cleanup()


class EmbedTests(Base):
    def test_fonts_keep_placeholders_and_mentions(self):
        out = embeds.stylize('Kick Me {server} <#123>', 'serif')
        self.assertIn('{server}', out)
        self.assertIn('<#123>', out)
        self.assertNotIn('Kick', out)
        self.assertEqual(embeds.stylize('abc', 'normal'), 'abc')

    def test_placeholders_resolve_panel_channels(self):
        guild = fake_guild(channels=[(55, '🔗│link-gamertag'), (66, '📋│kick-me')])
        eid = embeds.create_embed(1, 'kick', 'kickme')
        embeds.set_location(eid, 66, 999)
        text = embeds.fill('Use {kickme_channel} and {#link-gamertag} on {server}. Missing: {playtime_channel}', guild)
        self.assertEqual(text, 'Use <#66> and <#55> on Energy. Missing: #playtime')

    def test_panel_kinds_build_working_components(self):
        guild = fake_guild()
        cog = embeds.EmbedCog(SimpleNamespace())
        for kind, custom_id in (('link', 'xl:connect'), ('kickme', 'xl:kick'), ('playtime', 'pt:board')):
            row = embeds.get_embed(embeds.create_embed(1, kind, kind))
            view = in_loop(cog.build_view, guild, row)
            self.assertIn(custom_id, [getattr(c, 'custom_id', None) for c in view.children])
            embeds.build_embed(guild, row['data'])  # renders within limits

    def test_information_options_become_a_dropdown(self):
        guild = fake_guild()
        eid = embeds.create_embed(1, 'duos', 'custom')
        with db.conn() as c:
            c.execute("INSERT INTO embed_info(embed_id,position,label,emoji,description,data) VALUES(?,?,?,?,?,?)",
                      (eid, 1, 'Player Stats', '✅', None, json.dumps({'body': '- +12.5'})))
        view = in_loop(embeds.EmbedCog(SimpleNamespace()).build_view, guild, embeds.get_embed(eid))
        select = [c for c in view.children if getattr(c, 'custom_id', '') == f'ei:{eid}']
        self.assertEqual(len(select), 1)
        self.assertEqual(select[0].item.options[0].label, 'Player Stats')

    def test_channel_embed_resolution(self):
        a = embeds.create_embed(1, 'a'); b = embeds.create_embed(1, 'b')
        row, err = embeds.channel_embed(1, 10, None)
        self.assertIsNone(row); self.assertIn('No saved embed', err)
        embeds.set_location(a, 10, 1)
        self.assertEqual(embeds.channel_embed(1, 10, None)[0]['id'], a)
        embeds.set_location(b, 10, 2)
        self.assertIn('several', embeds.channel_embed(1, 10, None)[1])
        self.assertEqual(embeds.channel_embed(1, 10, str(b))[0]['id'], b)


class KDTests(Base):
    LINES = [
        '[2026.10.24-16.29.39:578][820]2026.10.24_16.29.39: mok - Lvl 105 () was killed by Blrddd - Lvl 105 ()! [KillerSID: 950526505]',
        '[2026.10.24-16.29.56:746][329]2026.10.24_16.29.56: ski - Lvl 105 () was killed by a R-Allosaurus  - Lvl 241 ()!',
        '[2026.10.24-16.30.04:773][570]2026.10.24_16.30.04: Maewing - Lvl 349 (Maewing) () was killed by Blrddd - Lvl 105 ()! [KillerSID: 950526505]',
        '[2026.10.24-16.28.21:537][190]2026.10.24_16.28.21: Human - Lvl 1 () was killed by a Spino - Lvl 150 ()!',
        '[2026.10.24-17.00.00:000][1]2026.10.24_17.00.00: vexx - Lvl 90 (Tribe of vexx) was killed by Blrddd - Lvl 105 (Tribe of Fred)! [KillerSID: 1]',
        '2026.10.24_17.00.00: Tribe Fred, ID 1: Day 3, 1:00:00: <RichColor Color="1, 0, 0, 1">Your vexx - Lvl 90 () was killed by Blrddd - Lvl 105 ()!</>)',
        'Mavrzo joined this ARK!',
    ]

    def test_parses_real_lines(self):
        self.assertEqual(kd.parse_death(self.LINES[0])['killer'], 'Blrddd')
        self.assertFalse(kd.parse_death(self.LINES[1])['pvp'])
        self.assertIsNone(kd.parse_death(self.LINES[2]))  # tamed dino death is not a player death
        self.assertIsNone(kd.parse_death(self.LINES[5]))  # tribe-log copy is ignored
        self.assertIsNone(kd.parse_death(self.LINES[6]))

    def test_counts_once_and_ranks(self):
        self.assertEqual(kd.record_lines('1', self.LINES), 4)
        self.assertEqual(kd.record_lines('1', self.LINES), 0)  # re-reading never double counts
        top = kd.kd_ranking(['1'])
        self.assertEqual((top[0]['name'], top[0]['kills'], top[0]['deaths']), ('Blrddd', 2, 0))
        mok = next(r for r in top if r['name'] == 'mok')
        self.assertEqual((mok['kills'], mok['deaths']), (0, 1))
        self.assertEqual(kd.kd_ranking(['2']), [])


class CATests(Base):
    HEAVY = ('[2026.10.25-05.35.20:745][817]2026.10.25_05.35.20: Tribe Tribe of N I X U S, ID 1366573257: Day 1, 20:47:02: '
             '<RichColor Color="1, 0.75, 0.3, 1">mavrixzo - Lvl 135 destroyed their \'Heavy Automated Turret (Locked)  (The Retards)\')!</>)')
    YOURS = ('[2026.10.25-05.35.20:743][817]2026.10.25_05.35.20: Tribe The Retards, ID 1664987353: Day 1, 20:47:02: '
             '<RichColor Color="1, 0, 0, 1">mavrixzo - Lvl 135 (Tribe of N I X U S) destroyed your \'Heavy Automated Turret (Locked) \'!</>)')
    TEK = HEAVY.replace('Heavy Automated Turret', 'Tek Turret').replace(':745]', ':800]')
    DOOR = HEAVY.replace('Heavy Automated Turret (Locked)', 'Metal Double Doorframe').replace(':745]', ':900]')

    def test_scoring_after_registration_only(self):
        with db.conn() as c:
            c.execute("INSERT INTO ca_points VALUES(1,'Heavy Automated Turret','Heavy Turret',5)")
            c.execute("INSERT INTO ca_points VALUES(1,'Tek Turret','Tek Turret',10)")
            c.execute("INSERT INTO ca_tribes VALUES(1,'Tribe of N I X U S','tribe of n i x u s',?,NULL)", (ca.line_time(self.HEAVY),))
        new = ca.record_lines('5', [self.HEAVY, self.YOURS, self.TEK, self.DOOR])
        self.assertEqual(sorted(e['structure'] for e in new), ['Heavy Automated Turret', 'Tek Turret'])
        self.assertEqual(ca.record_lines('5', [self.HEAVY]), [])
        s = ca.standings(1)[0]
        self.assertEqual((s['points'], s['breaks']), (15, 2))
        self.assertEqual(ca.parse_break(self.HEAVY)['victim'], 'The Retards')
        with db.conn() as c:
            c.execute('UPDATE ca_tribes SET registered_at=?', (ca.line_time(self.HEAVY) + 1,))
        self.assertEqual(ca.standings(1)[0]['points'], 0)


class FindLogTests(unittest.TestCase):
    def test_plain_words_match_ark_wording(self):
        g = findlog.concepts('turret broken')
        self.assertTrue(findlog.matches("Tribe X, ID 1: Day 5, 12:00:00: Your 'Heavy Auto Turret' was destroyed!", g))
        self.assertFalse(findlog.matches("Your 'Rex - Lvl 150' was killed!", g))
        self.assertTrue(findlog.matches('A purple Orbital Supply Drop landed', findlog.concepts('find osd logs')))
        self.assertTrue(findlog.matches('Dxjxx joined this ARK!', findlog.concepts('dxjxx joins')))
        self.assertTrue(findlog.matches('x said "gg ez"', findlog.concepts('"gg ez"')))
        self.assertEqual(findlog.concepts('the logs'), [])


class InfoTextTests(unittest.TestCase):
    def test_easy_text_format(self):
        out = embeds.format_text('Harvest Rates - 20x | Tribe Limit: 2 | ➕ +12.5 | Fed suits on | - kept')
        self.assertEqual(out.split('\n'), ['- Harvest Rates - `20x`', '- Tribe Limit - `2`', '- ➕ `+12.5`', '- Fed suits on', '- kept'])
        self.assertEqual(embeds.format_text('Hi | there', 'plain'), 'Hi\nthere')
        self.assertEqual(embeds.format_text('a - b', 'bullets'), '- a - b')


class PlaytimeTests(Base):
    def test_only_back_to_back_sightings_count(self):
        playtime.record_sample('1', [('p1', 'Gamer')], 1000, 180)
        playtime.record_sample('1', [('p1', 'Gamer')], 1060, 180)
        playtime.record_sample('1', [], 1120, 180)              # went offline
        playtime.record_sample('1', [('p1', 'Gamer')], 5000, 180)  # comes back: no gap credit
        playtime.record_sample('1', [('p1', 'Gamer')], 5060, 180)
        with db.conn() as c:
            self.assertEqual(c.execute("SELECT seconds FROM pt_time").fetchone()[0], 120)

    def test_cluster_ranking_sums_servers_and_ignores_others(self):
        with patch.object(playtime, 'service_ids', return_value=['1', '2', '3']):
            for sid, secs in (('1', 100), ('2', 50), ('3', 999)):
                with db.conn() as c:
                    c.execute("INSERT INTO pt_time(service,player_id,name,seconds) VALUES(?,?,?,?)", (sid, 'x' + sid, 'Gamer', secs))
            with db.conn() as c:
                c.execute("INSERT INTO pt_time(service,player_id,name,seconds) VALUES('1','y','Other',120)")
                c.execute("INSERT INTO pt_clusters(guild_id,name,services) VALUES(1,'Duos',?)", (json.dumps(['1', '2']),))
            top = playtime.ranking(1, 'Duos')
            self.assertEqual([(r['name'], r['seconds']) for r in top], [('Gamer', 150), ('Other', 120)])
            self.assertEqual(playtime.ranking(1, '*')[0]['seconds'], 1149)


class NotifierTests(Base):
    def rule(self, preset, **kw):
        p = dict(notifiers.PRESETS[preset])
        r = dict(guild_id=1, preset=preset, pattern=p['pattern'], title=p['title'], fields=p['fields'], description='',
                 color=p['color'], image='', image_file=None)
        r.update(kw)
        return r

    def test_presets_match_and_fill(self):
        r = self.rule('osd')
        found = notifiers.match_line(r, 'A purple orbital supply drop landed at 28.9, 58.1')
        self.assertEqual((found['color'], found['lat'], found['lon']), ('purple', '28.9', '58.1'))
        values = {'map': 'Extinction'}; values.update(found)
        e = notifiers.build(r, values)
        self.assertEqual(e.title, 'Purple OSD has spawned on Extinction!')
        self.assertIn('28.9', e.fields[0].value)
        self.assertTrue(e.fields[0].value.startswith('```ansi'))
        self.assertIsNone(notifiers.match_line(r, 'Player joined the tribe'))
        join = notifiers.match_line(self.rule('join'), 'Gamer Tag joined this ARK!')
        self.assertEqual(join['player'], 'Gamer Tag')
        self.assertEqual(notifiers.match_line(self.rule('element_node'), '50K Element Node spawned 67.8 31.1')['size'], '50K')

    def test_missing_values_show_dash(self):
        self.assertEqual(notifiers.fill('{Color} at {lat}', {'color': 'red'}), 'Red at —')


class FakeApi:
    def __init__(self, kick=False, fail_unban=False, command=False):
        self.calls, self.kick, self.fail_unban, self.command = [], kick, fail_unban, command

    async def request(self, method, path, params=None, payload=None, **kw):
        self.calls.append((method, path, params, payload))
        if path.endswith('/gameservers/command') and not self.command:
            raise xbox_link.NitradoError('This endpoint is unavailable for this service/game/platform.')
        if method == 'GET' and '/players/' in path and not params:
            return {'player_actions': ['kick'] if self.kick else []}
        if method == 'DELETE' and self.fail_unban:
            raise xbox_link.NitradoError('down')
        return {}

    async def players(self, sid):
        return [{'id': 'X1', 'name': 'GamerTag#1234', 'online': True}, {'id': 'X2', 'name': 'Someone', 'online': False}]


class KickTests(Base):
    def test_find_online_matches_gamertag_case_and_suffix(self):
        with patch.object(xbox_link, 'service_ids', return_value=['5']):
            hits = asyncio.run(xbox_link.find_online(FakeApi(), 'gamertag'))
        self.assertEqual([(s, p['id']) for s, p in hits], [('5', 'X1')])

    def test_kickplayer_command_first(self):
        api = FakeApi(command=True)
        how = asyncio.run(xbox_link.kick_player(api, '5', {'id': 'X1', 'name': 'G'}, xuid='2535'))
        self.assertEqual(how, 'command')
        self.assertEqual([c[3]['command'] for c in api.calls], ['KickPlayer X1', 'KickPlayer 2535'])

    def test_clear_error_when_nothing_works(self):
        class NoBan(FakeApi):
            async def request(self, method, path, **kw):
                if 'banlist' in path:
                    raise xbox_link.NitradoError('unavailable')
                return await super().request(method, path, **kw)
        with self.assertRaises(xbox_link.NitradoError) as ctx:
            asyncio.run(xbox_link.kick_player(NoBan(), '5', {'id': 'X1', 'name': 'G'}))
        self.assertIn('No kick method works', str(ctx.exception))
        with db.conn() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM xbox_pending_unbans').fetchone()[0], 0)

    def test_direct_kick_when_offered(self):
        api = FakeApi(kick=True)
        how = asyncio.run(xbox_link.kick_player(api, '5', {'id': 'X1', 'name': 'G'}))
        self.assertEqual(how, 'kick')
        self.assertFalse(any('banlist' in c[1] for c in api.calls))

    def test_ban_unban_fallback_and_retry_record(self):
        api = FakeApi(kick=False)
        with patch('asyncio.sleep', new=AsyncMock()):
            self.assertEqual(asyncio.run(xbox_link.kick_player(api, '5', {'id': 'X1', 'name': 'G'})), 'ban-unban')
        self.assertEqual([c[0] for c in api.calls if 'banlist' in c[1]], ['POST', 'DELETE'])
        with db.conn() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM xbox_pending_unbans').fetchone()[0], 0)
        api = FakeApi(kick=False, fail_unban=True)
        with patch('asyncio.sleep', new=AsyncMock()):
            asyncio.run(xbox_link.kick_player(api, '5', {'id': 'X1', 'name': 'G'}))
        with db.conn() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM xbox_pending_unbans').fetchone()[0], 1)

    def test_verified_link_replaces_other_claims_and_syncs_prize_tag(self):
        xbox_link.save_link(10, 'GamerTag', None, 'manual', False, 1)
        xbox_link.save_link(20, 'gamertag', 'XUID9', 'oauth', True, 1)
        self.assertIsNone(xbox_link.get_link(10))
        self.assertEqual(xbox_link.get_link(20)['verified'], 1)
        self.assertEqual(economy.gamertag_of(1, 20), 'gamertag')


class FakeResp:
    def __init__(self, status, data):
        self.status, self.data = status, data
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def json(self): return self.data


class FakeSession:
    def __init__(self, connections):
        self.connections = connections
    def post(self, url, **kw):
        return FakeResp(200, {'access_token': 'tok'})
    def get(self, url, **kw):
        if url.endswith('/connections'):
            return FakeResp(200, self.connections)
        return FakeResp(200, {'id': '42'})


class OAuthTests(Base):
    def run_callback(self, connections, user='42'):
        bot = SimpleNamespace(nitrado_api=None, application_id=777, get_guild=lambda gid: None)
        cog = xbox_link.XboxLinkCog(bot)
        cog.http = AsyncMock(return_value=FakeSession(connections))
        interaction = SimpleNamespace(edit_original_response=AsyncMock())
        cog.pending['s1'] = {'user_id': int(user), 'guild_id': 1, 'created': __import__('time').time(), 'interaction': interaction}
        request = SimpleNamespace(query={'state': 's1', 'code': 'abc'})
        with patch.dict('os.environ', {'LINK_PUBLIC_URL': 'https://x.example', 'DISCORD_CLIENT_SECRET': 's'}):
            resp = asyncio.run(cog.web_callback(request))
        return resp, interaction

    def test_links_the_connected_xbox_account(self):
        resp, inter = self.run_callback([{'type': 'steam', 'name': 'nope', 'id': '1'}, {'type': 'xbox', 'name': 'Energy Gamer', 'id': '2535', 'verified': True}])
        self.assertIn('Gamertag linked', resp.text)
        link = xbox_link.get_link(42)
        self.assertEqual((link['gamertag'], link['xuid'], link['verified']), ('Energy Gamer', '2535', 1))
        inter.edit_original_response.assert_awaited()

    def test_no_xbox_connection(self):
        resp, _ = self.run_callback([])
        self.assertIn('No Xbox account found', resp.text)
        self.assertIsNone(xbox_link.get_link(42))

    def test_state_cannot_be_reused(self):
        bot = SimpleNamespace(nitrado_api=None, application_id=777, get_guild=lambda gid: None)
        cog = xbox_link.XboxLinkCog(bot)
        resp = asyncio.run(cog.web_callback(SimpleNamespace(query={'state': 'never', 'code': 'x'})))
        self.assertIn('Link expired', resp.text)

    def test_wrong_discord_account_rejected(self):
        resp, _ = self.run_callback([{'type': 'xbox', 'name': 'G', 'id': '1'}], user='99')
        self.assertIn('Wrong Discord account', resp.text)
        self.assertIsNone(xbox_link.get_link(99))


class ServiceTests(unittest.TestCase):
    def test_map_names(self):
        self.assertEqual(ark_services.pretty_map('Extinction'), 'Extinction')
        self.assertEqual(ark_services.pretty_map('Genesis2'), 'Genesis 2')
        self.assertEqual(ark_services.pretty_map('ScorchedEarth_P'), 'Scorched Earth')
        self.assertEqual(ark_services.fmt_duration(3 * 3600 + 120), '3h 2m')


if __name__ == '__main__':
    unittest.main()

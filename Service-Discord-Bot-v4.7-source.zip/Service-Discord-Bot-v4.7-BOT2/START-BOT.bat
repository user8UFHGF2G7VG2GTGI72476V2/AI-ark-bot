@echo off
title Service Manager BOT 2
cd /d "%~dp0"
if not exist .venv (
  echo Run INSTALL.bat first.
  pause
  exit /b
)
call .venv\Scripts\activate.bat
python bot\main.py
echo.
echo Bot stopped.
pause

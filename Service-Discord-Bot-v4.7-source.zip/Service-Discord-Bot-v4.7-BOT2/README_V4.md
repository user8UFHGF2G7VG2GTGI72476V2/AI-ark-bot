# Service Discord Bot 4.5 preview

## Token-only Nitrado setup (new)

Run /nitrado setup and paste only your Nitrado lifetime token into the private form. There is no service-ID field. The bot checks both /services and /uwp/services/list, deduplicates IDs, verifies each candidate's game, and saves accessible ARK: Survival Evolved servers and the token to .env. It chooses a default server automatically. Multiple servers are supported without entering IDs. /nitrado refresh rediscovers servers using the saved token.

Discovery filters out non-ASE services and reports unavailable endpoints/skipped services. Failed discovery does not replace your saved credentials. Automatic discovery replaces the saved ID list with the currently verified ASE services; manual /nitrado service-add remains available as an advanced option. Up to 25 ASE services are supported. The token must permit listing and reading the services; a lifetime token cannot grant access its account does not have.

After discovery, /logs-setup staff_role:@Staff checks all saved services automatically. Source paths are reused when already configured, or chosen when Nitrado exposes exactly one log file. If the API exposes no source or several possible files, that server needs an explicit file selection; the bot does not guess. The staff role is still chosen in Discord so channels are private to the correct people. You still need the separate Discord bot token in .env to start the bot.

Thirty-eight offline tests pass, including token-only multiple-service discovery, Xbox/UWP fallback, rejecting non-ASE accounts without saving, the one-field form, and checking every discovered service during log setup. Authenticated discovery has not been tested against a live account.

Extends the supplied Service-Discord-Bot-v3.2.zip. Keeps its Windows INSTALL.bat / START-BOT.bat workflow, ticket panels, giveaways, welcome tools, reviews and invite history.

This is an installable preview, not a verified production integration. Thirty-eight offline tests pass. The public population provider has been checked live against Xbox/Windows 10 and PlayStation ASE browser feeds and found eight Froakie Solo's servers. No Discord login or authenticated Nitrado request has been performed. Steam population search is not included.

## Automatic staff-only log channels (4.5 fix)

Run `/nitrado setup` with your lifetime token, then `/logs-setup staff_role:@Staff`. The bot checks every saved service. You do not need to supply service IDs. If a token exists but saved IDs are empty, setup attempts discovery again. Without a token it returns an explicit setup error rather than creating only transcripts and claiming completion.

The bot creates **🛡️ STAFF LOGS** with **🎫・ticket-transcripts**, plus **🛡️ ARK LOGS • SERVICE_ID** for each server with:

- **📋・server-logs** — complete configured source log.
- **⚔️・kill-logs** — parsed kills plus raw lines containing killed/died.
- **📊・kd-logs** — tracked kill/death totals when a kill line is parsed successfully.
- **🛠️・admin-logs** — admin/cheat keyword matches.
- **🚪・join-leave-logs** — join/leave/connect keyword matches.

All five game channels are created and assigned destinations even if recent history has no matching events. This fixes the previous history gate. Unsupported spoof, alt, account-sharing, tribe and cross-guild-ban detection channels are not created.

Log discovery first reuses a configured path, then checks the paths exposed by the game API, then searches the file-browser bookmarks and known ARK/ShooterGame/Saved/Logs directories. It prefers ShooterGame.log and recent files, excludes installer/restart logs, and bounds the directory search. `file:FULL_LOG_PATH` remains an optional override. This build tails one selected game file per service; events absent from that file cannot be reconstructed. It does not automatically change Nitrado server settings or bypass token permissions.

Setup checks file stat and log-read access. With a readable source it saves all destination IDs and enables the existing worker, preserving the cursor for the same path. New sources start at EOF: historical events are not replayed. Kills, KD, admin and joins are routed to their own saved channels, while every line goes to server-logs. A worker test ingests sample events and checks delivery to each destination, including KD totals.

If discovery/read access fails, channels are still created privately, but each game channel receives a visible **Log source not connected** notice and the setup report includes the error. An old worker for that service is disabled rather than left sending to stale destinations. These channels cannot receive game events until access/logging is fixed and setup is rerun. Channel creation is not reported as a working connection.

Permissions explicitly deny @everyone visibility, allow the selected staff role to view/read history, and allow the bot to post. Staff channels are read-only. Discord administrators and the server owner can always view them. @everyone cannot be selected as staff. Reruns reuse the bot's saved resource IDs and repair private overwrites. Existing unrelated channels are not adopted or deleted.

The bot needs Manage Channels, View Channels, Send Messages, Embed Links, Attach Files and Read Message History. Actual Nitrado access, source contents and production ARK formats have not been validated with the user's token. KD still requires the configured kill parser to match; raw kill forwarding does not falsely increment KD. Admin/join filters remain keyword-based. No live account credentials are bundled or requested in chat.

## Updating without disconnecting

This version converts feature modules into discord.py extensions. Install it once by stopping the old bot, replacing ALL the bot/*.py files (including new files), preserving .env and data, and starting again. This initial migration requires one restart.

For future feature updates, copy updated feature source files into the running installation, then use:

```
/reload module:population
/reload module:general
/reload module:ark_feed
/reload module:all
```

Only the Discord application owner or its authorized developer team can run /reload and /sync-commands. Discord server Administrator alone does not authorize code reloads. These commands do not download files or accept arbitrary code; they reload allowlisted local files already placed by the operator.

/reload validates Python syntax before unloading anything. Each feature reload uses discord.py's extension rollback if loading fails. Reloading all features is sequential: if one fails, earlier successful updates remain active and later features are skipped. Slash definitions synchronize by default; use sync_commands:false for changes that do not alter command names/options. If Discord slash sync fails after a successful reload, retry /sync-commands. Changes can take time to appear in Discord clients.

The Discord connection stays online. The affected feature can pause briefly and an in-flight request can fail; this is not a guarantee of uninterrupted processing. The log worker is cancelled and awaited before its replacement starts, and SQLite cursors/statistics are retained. Giveaway background completion already in progress is allowed to finish. Persistent ticket/giveaway button handlers are replaced; reopen any transient editor or setup form after reloading its module. Invite cache state and the Nitrado API client/configuration lock are retained.

main.py, extensions.py, maintenance.py, nitrado_api.py, nitrado_config.py, db.py, common.py, ticket_media.py and dependency changes require a restart. Reloading one feature does not reload its shared imports. Back up data before schema changes; extension rollback does not undo database migrations or external actions.

## Install or upgrade

1. Install Python 3.12 on Windows.
2. Extract this ZIP. For an upgrade, stop the old bot first and back up its entire data folder and .env. Replace bot code and installer files, preserving .env and data. Keep only one bot process running.
3. Run INSTALL.bat. It creates .venv and installs the pinned dependencies, as in v3.2.
4. Edit .env locally to set DISCORD_TOKEN. Nitrado credentials can now be entered through Discord after starting the bot. Editing NITRADO_TOKEN and comma-separated NITRADO_SERVICE_IDS in .env remains an alternative.
5. Enable Server Members Intent and Message Content Intent in the Discord Developer Portal. Invite with bot and applications.commands scopes. Enable the bot's needed permissions: View Channels, Send Messages, Embed Links, Attach Files, Read Message History, Add Reactions, Create Polls, Create Instant Invite, Manage Server (invite tracking), Manage Channels, Manage Messages, Manage Roles, Manage Nicknames, Kick Members, Ban Members and Moderate Members. Position the bot role above members and roles it manages.
6. Run START-BOT.bat. Slash commands register globally; Discord may take time to display changes. The inherited optional GUILD_ID setting clears old guild-scoped commands; it does not restrict access to that guild.
7. Run /nitrado setup as a Discord administrator. The private form asks only for your lifetime token, discovers accessible ASE services automatically, verifies them before saving, preserves unrelated .env settings, and uses the changes immediately. It selects a default if needed. Then run /nitrado auth or /nitrado serverlist.

Use /nitrado service-add ids:123,456 to add more IDs with the saved token. Duplicates are ignored; up to 25 IDs are supported. Use /nitrado service-remove service:123 to remove one, stop its tracking feeds and retain its statistics. /nitrado bind selects the default for commands that omit service. Rerun /nitrado setup with a new token to rotate credentials; leaving the token blank preserves the saved one. A failed validation or .env write preserves the existing configuration.

The token is submitted through a Discord modal, not a public message or a slash-command argument. It is never prefilled or echoed. The form transmits the token through Discord and saves it in plaintext in the host .env, as requested; protect access to that file. Only the administrator who opened the form can submit it, and administrator permission is rechecked on submission.

All Discord administrators in every server this bot joins can manage the service IDs allowed in this bot installation. Use a dedicated installation for each independent community.

## General commands

| Request | Command |
|---|---|
| Kick / ban / unban | /kick, /ban, /unban user_id |
| Mute / timeout | /mute member minutes, /timeout member minutes; minutes:0 removes timeout |
| Rename | /rename member nickname; omit nickname to reset |
| Lock / unlock | /lock, /unlock; optional channel |
| Poll | /poll question answers; separate 2–10 answers with a vertical bar; hours and multiple optional |
| Server info | /server-info |
| Purge / clear | /purge amount member, /clear amount |
| AFK | /afk reason; next ordinary message clears it |
| Warn | /warn member reason, /warnings member, /unwarn warning_id |
| Give / remove role | /role member role, /delrole member role |
| Who is | /who-is member |
| Giveaways | Original /giveaway start, end, reroll, cancel, list |
| Invites | Original /invites, /invited-by, /invite-setup; new /invite-leaderboard, /invite-create, /invite-links |
| Credits (v4.6) | /credit give, remove, view, leaderboard, daily, pay |
| Mystery boxes / wheel (v4.6) | /mysterybox and /wheel: give, remove, view, buy, open/spin, options, option-add/remove/clear, leaderboard |
| Prizes, links, hype (v4.6) | /economy, /prizes, /link, /nametag, /hype — see README_FIRST.txt |

Moderation commands enforce Discord permissions and member/role hierarchy. Lock changes the @everyone overwrite and saves its previous messaging values for unlock. Role-specific allows and administrators can still send. Purge scans the requested number of recent messages; with a member filter, it may delete fewer. Polls use Discord's native poll system and survive bot restarts.

Credits are server-local virtual points. Daily grants 100 once every 24 hours by default (/economy daily). Transfers, purchases and their log entries commit atomically, and balances can never go negative. Staff give/remove replaces the old administrator adjust. There is no cash value or payment processor.

Invite tracking retains the original attribution model: unique joins observed while online; ambiguous uses are uncredited, and rejoins do not grant new unique invites. The leaderboard ranks members still present. Bot-generated invite links store the requesting member as the local credited inviter. Historical joins before installation cannot be reconstructed.

## Tickets and transcripts

The existing ticket setup commands remain. Use /ticket config, /ticket settings log_channel, /add ticket-option and /ticket post or /ticket panel-edit. See README_FIRST.txt for the original setup details.

On close, the bot now saves a UTF-8 transcript under data/transcripts before deleting the channel. It includes message text, author IDs, attachment URLs and embed metadata. If a configured log channel cannot receive the transcript, closing stops and the ticket remains open. If no log channel is configured, the transcript stays local. /ticket transcript also remains available.

Transcripts are text exports, not HTML archives. Attachment bytes are not downloaded; their Discord links may expire. Back up the data folder, including transcripts. Configure a private staff log channel to avoid exposing ticket contents.

## Nitrado ARK: Survival Evolved

| Request | Command / behavior |
|---|---|
| Token / service ID setup | /nitrado setup opens a private form and saves to host .env |
| Multiple services | /nitrado service-add ids, /nitrado service-remove service |
| Lifetime token auth | /nitrado auth validates the saved configuration |
| Bind default service | /nitrado bind service |
| Stop / restart | /nitrado manage action; status confirms current state separately |
| Server status / configured servers | /nitrado status, /nitrado serverlist |
| Ban / unban by name | /nitrado ban name, /nitrado unban name |
| Add/remove/list admins | /nitrado admin-add, admin-remove, admin-list |
| Find player | /nitrado find-player name; searches configured service IDs |
| Kick | /nitrado kick name; only if Nitrado advertises kick for that player |
| Players online | /nitrado players; uses Nitrado's explicit online field |
| Whitelist | /nitrado whitelist action:list/add/remove name |
| Recent logs | /nitrado log-files, /nitrado logs file kind:all/kills/admin/joins |
| Continuous feed | /ark-log-setup; /ark-log-status; /ark-log-stop |
| KD | /kd name, /kd-leaderboard |
| Playtime | /playtime name; estimated observed online time |
| Keyword population | /pop keyword; Xbox/W10 and PlayStation browser feeds, described below |

Management is administrator-only. Most commands accept optional service to override the bound default, but only saved service IDs are accepted. Setup can save multiple IDs, and tracking runs independently for every service configured with /ark-log-setup service:ID. Saving credentials alone does not start a log feed: choose its source file and destination channel using that command. Player-list support is checked through the Nitrado capabilities endpoint. These are API integrations, not a guarantee that Xbox/Windows 10 ASE exposes every action. Unsupported capabilities return an explicit error. Names must resolve to exactly one ID from the service player list, or the existing ban/admin/whitelist for removals. Unavailable, duplicate, or renamed names cannot safely be guessed.

Stop/restart requests report acceptance, not completed execution. There is no force-install, reinstall, wipe, or binary-update command. Use the Nitrado panel for game updates. Do not assume an accepted request completed if the network times out; check /nitrado status first.

## Continuous logs, KD and playtime

1. Enable the ARK log options needed on the server through Nitrado. Logging availability is platform-specific.
2. Use /nitrado log-files to locate a readable log path. If none are exposed, inspect the Nitrado file browser. This bot does not invent a log path.
3. Run /ark-log-setup channel:#all-logs file:FULL_PATH. Optionally choose kills_channel, admin_channel and joins_channel. One source file per service per Discord server is supported.
4. Tracking starts at the current end of file. New lines are posted as text attachments, in batches up to 100 lines. Offset and incomplete-line state survive restarts. Parsed events and their source positions commit together, so ordinary replay does not double-count KD.
5. Default interval is 30 seconds. Set ARK_LOG_POLL_SECONDS=1 in .env and restart for one-second checks. Each check needs at least a file-stat request and, when changed, file-seek and download requests. Rate limits, API latency, game log flushing and sequential services prevent a guaranteed one-second detection time. Errors trigger exponential backoff; inspect /ark-log-status and the console.

The default parser matches exactly `Alice killed Bob`, the format described in this chat. It does not claim to recognize a production ARK log without a sample. Timestamp prefixes, level/tribe fields and different wording require /ark-kill-pattern. That command takes a regex with named killer and victim groups plus a matching example. For example:

```
^(?P<killer>.+?) killed (?P<victim>.+?)$
```

Use a simple anchored pattern; complex backtracking regexes can block Python. KD is the count of matching lines only. The parser cannot distinguish a tame/dinosaur from a human if the log text does not distinguish them. Names are not verified player identities; changed names have separate totals. Suicide lines with identical names are ignored. Admin and join routing uses keyword matching and is approximate. No retroactive kill import or automatic detection of the real server log format is included.

Playtime samples available online-player IDs about once a minute while the feed is enabled. It counts intervals observed online at both samples, excluding gaps over 90 seconds, restarts and failed player queries. It is an estimate, not lifetime playtime. If console ASE does not expose player identities/online state, the bot cannot calculate reliable playtime from population alone.

File truncation is detected and starts a new cursor generation. Replacement with an equal/larger file, or switching to a newly rotated log filename, needs manual reconfiguration. Discord delivery is retried; a crash after posting but before acknowledgement can produce a duplicate attachment, while stored kill counts stay deduplicated for ordinary cursor replay. Raw event history is retained in SQLite; monitor disk usage. A server-side delay in writing logs cannot be removed by polling faster.

## /pop fix and coverage

The old code used Nitrado's /toplist and required fields its current responses do not include (is_online and slots_used). That discarded all returned records. The live toplist also did not contain the user's Froakie example. The new population.py extension uses ARK's actual ASE unofficial browser feeds:

- https://arkdedicated.com/xbox/cache/unofficialserverlist.json
- https://arkdedicated.com/ps4/cache/unofficialserverlist.json

The new /pop keyword:froakie was verified live and found eight Froakie Solo's entries with map and player counts. It uses Name, NumPlayers, MaxPlayers, MapName and SearchTags from the real response. Empty servers remain searchable. Missing player counts display as unknown, rather than zero. Matching ignores case, spacing and punctuation, so "froakie solos" can match "FROAKIE SOLO'S".

/pop defaults to searching both feeds. Optional platform choices: all, xbox, xw10 and playstation. xw10 selects Xbox entries explicitly advertising Windows Store crossplay (crossplayallowuwp). No Nitrado token or configured service IDs are needed. There is no arbitrary first-20-pages limit. Results show up to 20 entries in an embed, total reported population, and a text file containing every match.

Feeds cache for 60 seconds. On a refresh failure, cached data up to ten minutes old is labelled as cached, and its fetch timestamp remains visible. If only one platform fails, results from the other platform are returned with an explicit notice. Failure of every source produces an availability error, not a false "server not found" result. Feed data is a source snapshot and may lag the game.

Steam search remains unsupported and is stated in the command footer. Console unofficial browser feeds are not a guaranteed directory of all servers or all hosts. A missing result is not proof that a server is offline. No ASA-only provider is substituted.

## Validation

Run `python -m unittest discover -s tests -v` from this folder with dependencies installed. Thirty-eight tests cover full cog/command registration and serialization, atomic credit transfers and insufficient-funds rollback, daily cooldown, exact-name ambiguity, service allowlisting, unsupported capabilities, member hierarchy, split log lines/replay, conservative parsing and transcript failure preserving the ticket. Setup checks cover .env persistence/reload, preserving unrelated settings, write-failure rollback, numeric ID parsing/deduplication, validating multiple IDs before saving, credential rejection, form permissions and removing a service without stopping other services. Other checks exercise repeated reloads without duplicate workers/views, preserved cursors and invite cache, rejected syntax before unload, runtime-load rollback, owner-only reloads, actual browser-response field names, zero-player matches, unknown player counts and partial platform outages. Six channel-provisioning tests check explicit private overwrites, @everyone rejection, event-dependent channel selection, idempotency, repairing public overwrites, preserving the cursor, unreadable-source refusal, and transcript-only setup without Nitrado. Python source compilation also passes.

Validated live without credentials: public Xbox/Windows 10 and PlayStation feeds, and the actual population provider's Froakie search. Not validated live: Discord slash sync and permissions, live gateway continuity during reload, native poll delivery, persistent buttons after an actual reconnect, Nitrado token scopes, console endpoint capabilities, signed log downloads, or actual ASE log parsing. No credentials are included in the ZIP.

Primary references consulted:
- https://doc.nitrado.net/ — Nitrado service control, file access and player-management capability APIs.
- https://discordpy.readthedocs.io/en/stable/interactions/api.html — slash commands, permissions and interactions.
- https://server.nitrado.net/guides/ark-admin-log/ — ARK admin logging setup and log availability.
- https://discordpy.readthedocs.io/en/stable/ext/commands/api.html — extension loading/reloading and rollback.

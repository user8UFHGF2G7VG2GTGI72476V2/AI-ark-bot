import base64, mimetypes
import discord
from discord import app_commands
from discord.ext import commands
from discord.http import Route
from common import admin_check

class ProfileCog(commands.Cog):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name="set-profile",description="Change the bot appearance in this server only")
    @admin_check()
    async def set_profile(self,i:discord.Interaction,name:str=None,profile_picture:discord.Attachment=None,banner:discord.Attachment=None):
        await i.response.defer(ephemeral=True,thinking=True)
        payload={"bio": ""}
        if name:payload["nick"]=name[:32]
        async def data_uri(att):
            data=await att.read()
            mime=att.content_type or mimetypes.guess_type(att.filename)[0] or "image/png"
            return f"data:{mime};base64,{base64.b64encode(data).decode()}"
        if profile_picture:payload["avatar"]=await data_uri(profile_picture)
        if banner:payload["banner"]=await data_uri(banner)
        try:
            route=Route("PATCH","/guilds/{guild_id}/members/@me",guild_id=i.guild.id)
            await self.bot.http.request(route,json=payload,reason=f"Profile changed by {i.user}")
            await i.followup.send("✅ Updated for this server only.",ephemeral=True)
        except Exception as e:
            await i.followup.send(f"❌ Discord rejected the update: `{e}`",ephemeral=True)



async def setup(bot):
    await bot.add_cog(ProfileCog(bot))

import sqlite3, json
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)
DB = DATA / "fent_discord_manager.sqlite3"

@contextmanager
def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    try:
        with c:
            yield c
    finally:
        c.close()

def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS settings(
          guild_id INTEGER NOT NULL,
          key TEXT NOT NULL,
          value TEXT NOT NULL,
          PRIMARY KEY(guild_id,key)
        );

        CREATE TABLE IF NOT EXISTS tickets(
          channel_id INTEGER PRIMARY KEY,
          guild_id INTEGER NOT NULL,
          opener_id INTEGER NOT NULL,
          kind TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'open',
          claimed_by INTEGER,
          opened_at INTEGER NOT NULL,
          closed_at INTEGER
        );

        CREATE TABLE IF NOT EXISTS ticket_pay_logs(
          channel_id INTEGER PRIMARY KEY,
          guild_id INTEGER NOT NULL,
          staff_id INTEGER NOT NULL,
          kind TEXT NOT NULL,
          amount REAL NOT NULL DEFAULT 0,
          logged_at INTEGER NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_ticket_pay_logs_guild_staff
          ON ticket_pay_logs(guild_id, staff_id);

        CREATE TABLE IF NOT EXISTS rr_panels(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          channel_id INTEGER NOT NULL,
          message_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          description TEXT,
          color TEXT NOT NULL DEFAULT '5865F2',
          UNIQUE(guild_id,message_id)
        );

        CREATE TABLE IF NOT EXISTS rr_items(
          panel_id INTEGER NOT NULL,
          emoji TEXT NOT NULL,
          role_id INTEGER NOT NULL,
          PRIMARY KEY(panel_id,emoji),
          FOREIGN KEY(panel_id) REFERENCES rr_panels(id) ON DELETE CASCADE
        );
        """)

def get_setting(guild_id, key, default=None):
    with conn() as c:
        r = c.execute("SELECT value FROM settings WHERE guild_id=? AND key=?", (int(guild_id), str(key))).fetchone()
    if not r:
        return default
    try:
        return json.loads(r["value"])
    except Exception:
        return r["value"]

def set_setting(guild_id, key, value):
    raw = json.dumps(value, ensure_ascii=False)
    with conn() as c:
        c.execute(
            """INSERT INTO settings(guild_id,key,value) VALUES(?,?,?)
               ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value""",
            (int(guild_id), str(key), raw),
        )

def del_setting(guild_id, key):
    with conn() as c:
        c.execute("DELETE FROM settings WHERE guild_id=? AND key=?", (int(guild_id), str(key)))

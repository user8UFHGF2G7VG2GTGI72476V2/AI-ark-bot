"""Persistent log tailing and conservative kill statistics.

Default format is exactly the user-provided '<name> killed <name>'. Real server
formats can be configured per service without modifying source code.
"""
import asyncio
import hashlib
import io
import logging
import os
import re
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import emb
from nitrado_api import NitradoError, resolve_name, service_ids

log=logging.getLogger(__name__)
DEFAULT_KILL=r'^(?P<killer>[^\r\n]{1,100}?) killed (?P<victim>[^\r\n]{1,100}?)$'


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS ark_feed(guild_id INTEGER,service TEXT,path TEXT,channel_id INTEGER,kill_pattern TEXT NOT NULL,offset INTEGER DEFAULT 0,generation INTEGER DEFAULT 0,pending BLOB DEFAULT X'',ready INTEGER DEFAULT 0,PRIMARY KEY(guild_id,service));
        CREATE TABLE IF NOT EXISTS ark_events(id TEXT PRIMARY KEY,guild_id INTEGER,service TEXT,line TEXT,killer TEXT,victim TEXT,created INTEGER,delivered INTEGER DEFAULT 0);
        CREATE INDEX IF NOT EXISTS ark_events_stats ON ark_events(guild_id,service,killer,victim);
        CREATE TABLE IF NOT EXISTS ark_playtime(guild_id INTEGER,service TEXT,player_id TEXT,name TEXT,seconds INTEGER DEFAULT 0,last_seen INTEGER,PRIMARY KEY(guild_id,service,player_id));
        ''')


def parse_kill(line,pattern=DEFAULT_KILL):
    match=re.fullmatch(pattern,line.strip())
    if not match: return None
    killer=match.group('killer').strip()
    victim=match.group('victim').strip()
    if not killer or not victim or killer.casefold()==victim.casefold(): return None
    return killer,victim


def ingest(row,data,new_offset):
    """Commit cursor and events together; incomplete lines wait for the next read."""
    pending=bytes(row['pending'] or b'')
    combined=pending+data
    parts=combined.split(b'\n')
    remainder=parts.pop()
    start=int(row['offset'])-len(pending)
    now=int(time.time())
    with db.conn() as c:
        current=c.execute('SELECT path,generation,ready FROM ark_feed WHERE guild_id=? AND service=?',(row['guild_id'],row['service'])).fetchone()
        if not current or not current['ready'] or current['path']!=row['path'] or current['generation']!=row['generation']:
            return
        for part in parts:
            line=part.decode('utf-8',errors='replace').rstrip('\r')
            key=f"{row['guild_id']}:{row['service']}:{row['path']}:{row['generation']}:{start}"
            event_id=hashlib.sha256(key.encode()).hexdigest()
            kill=parse_kill(line,row['kill_pattern'])
            if line:
                c.execute('INSERT OR IGNORE INTO ark_events(id,guild_id,service,line,killer,victim,created) VALUES(?,?,?,?,?,?,?)',(event_id,row['guild_id'],row['service'],line,kill[0] if kill else None,kill[1] if kill else None,now))
            start+=len(part)+1
        # Cap an unterminated line rather than letting a malformed file grow RAM indefinitely.
        if len(remainder)>65536: remainder=b''
        c.execute('UPDATE ark_feed SET offset=?,pending=? WHERE guild_id=? AND service=?',(new_offset,remainder,row['guild_id'],row['service']))


class FeedCog(commands.Cog):
    def __init__(self,bot,api):
        self.bot=bot
        self.api=api
        self.next_poll={}
        self.failures={}
        self.last_sample={}
        init_tables()
        try: self.interval=max(1,min(300,int(os.getenv('ARK_LOG_POLL_SECONDS','30'))))
        except ValueError: self.interval=30

    async def cog_load(self): self.poller.start()
    async def cog_unload(self):
        task=self.poller.get_task()
        self.poller.cancel()
        if task:
            await asyncio.gather(task,return_exceptions=True)

    async def interaction_check(self,i):
        if not i.guild: raise NitradoError('Use this inside a server.')
        return True

    def configure_feed(self,gid,sid,path,channel_id,routes,size,preserve=False):
        with db.conn() as c:
            old=c.execute('SELECT path FROM ark_feed WHERE guild_id=? AND service=?',(gid,sid)).fetchone()
            if preserve and old and old['path']==path:
                c.execute('UPDATE ark_feed SET channel_id=?,ready=1 WHERE guild_id=? AND service=?',(channel_id,gid,sid))
            else:
                c.execute('INSERT INTO ark_feed(guild_id,service,path,channel_id,kill_pattern,offset,ready) VALUES(?,?,?,?,?,?,1) ON CONFLICT(guild_id,service) DO UPDATE SET path=excluded.path,channel_id=excluded.channel_id,offset=excluded.offset,pending=X\'\',generation=ark_feed.generation+1,ready=1',(gid,sid,path,channel_id,DEFAULT_KILL,size))
        db.set_setting(gid,f'ark_routes:{sid}',routes)

    @app_commands.command(name='ark-log-setup',description='Start a continuous ARK log feed and kill tracking')
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_feed(self,i:discord.Interaction,channel:discord.TextChannel,file:app_commands.Range[str,1,500],service:str=None,kills_channel:discord.TextChannel=None,admin_channel:discord.TextChannel=None,joins_channel:discord.TextChannel=None):
        sid=await self.api.service(i.guild_id,service)
        if not file.lower().endswith(('.log','.txt')): raise NitradoError('Choose a log/text path from /nitrado log-files.')
        await i.response.defer(ephemeral=True)
        file=await self.api.resolve_path(sid,file)
        # Start at current EOF: avoid replaying a whole historical file into Discord.
        size=await self.file_size(sid,file)
        self.configure_feed(i.guild_id,sid,file,channel.id,{kind:ch.id for kind,ch in (('kills',kills_channel),('admin',admin_channel),('joins',joins_channel)) if ch},size)
        await i.followup.send(f'Log feed enabled in {channel.mention}; starts with new lines. Interval: {self.interval}s. Default kill format: `name killed name`. KD counts matching lines only. Playtime is observed online time while tracking runs.',ephemeral=True)

    @app_commands.command(name='ark-log-stop',description='Stop this service log feed and online-time sampling')
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(administrator=True)
    async def stop_feed(self,i:discord.Interaction,service:str=None):
        sid=await self.api.service(i.guild_id,service)
        with db.conn() as c: c.execute('UPDATE ark_feed SET ready=0 WHERE guild_id=? AND service=?',(i.guild_id,sid))
        await i.response.send_message('Tracking stopped; saved statistics are retained.',ephemeral=True)

    @app_commands.command(name='ark-kill-pattern',description='Set a kill regex with named killer and victim groups')
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(administrator=True)
    async def kill_pattern(self,i:discord.Interaction,pattern:app_commands.Range[str,1,500],example:app_commands.Range[str,1,1000],service:str=None):
        sid=await self.api.service(i.guild_id,service)
        try:
            compiled=re.compile(pattern)
            if not {'killer','victim'}<=compiled.groupindex.keys(): raise ValueError()
            result=parse_kill(example,pattern)
            if not result: raise ValueError()
        except (re.error,ValueError):
            raise NitradoError('Pattern must match the example and include (?P<killer>...) and (?P<victim>...) groups.')
        with db.conn() as c:
            count=c.execute('UPDATE ark_feed SET kill_pattern=? WHERE guild_id=? AND service=?',(pattern,i.guild_id,sid)).rowcount
        if not count: raise NitradoError('Run /ark-log-setup first.')
        await i.response.send_message(f'Pattern saved. Example: killer={result[0]}, victim={result[1]}. Only future lines use this pattern.',ephemeral=True)

    @app_commands.command(name='ark-log-status',description='Show feed health, backlog, parser, and poll interval')
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(administrator=True)
    async def feed_status(self,i:discord.Interaction,service:str=None):
        sid=await self.api.service(i.guild_id,service)
        with db.conn() as c:
            row=c.execute('SELECT * FROM ark_feed WHERE guild_id=? AND service=?',(i.guild_id,sid)).fetchone()
            backlog=c.execute('SELECT COUNT(*) FROM ark_events WHERE guild_id=? AND service=? AND delivered=0',(i.guild_id,sid)).fetchone()[0]
        if not row: raise NitradoError('No feed configured. Run /ark-log-setup.')
        key=(i.guild_id,sid)
        await i.response.send_message(f"Enabled: {bool(row['ready'])}\nFile: {row['path']}\nChannel: <#{row['channel_id']}>\nCursor: {row['offset']} bytes\nDelivery backlog: {backlog} lines\nInterval: {self.interval}s\nConsecutive failures: {self.failures.get(key,0)}\nKill pattern: `{row['kill_pattern']}`",ephemeral=True)

    @app_commands.command(name='kd',description='Show KD from matching tracked kill log lines')
    @app_commands.guild_only()
    async def kd(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        sid=await self.api.service(i.guild_id,service)
        with db.conn() as c:
            kills=c.execute('SELECT COUNT(*) FROM ark_events WHERE guild_id=? AND service=? AND lower(killer)=lower(?)',(i.guild_id,sid,name)).fetchone()[0]
            deaths=c.execute('SELECT COUNT(*) FROM ark_events WHERE guild_id=? AND service=? AND lower(victim)=lower(?)',(i.guild_id,sid,name)).fetchone()[0]
        await i.response.send_message(embed=emb(f'KD: {discord.utils.escape_markdown(name)}',f'Kills: {kills}\nDeaths: {deaths}\nKD: {kills/deaths:.2f}' if deaths else f'Kills: {kills}\nDeaths: 0\nKD: N/A (no recorded deaths)') .set_footer(text='Matching log lines since setup only. Names are not verified identities; renamed players have separate totals.'))

    @app_commands.command(name='kd-leaderboard',description='Top 20 names by tracked kills')
    @app_commands.guild_only()
    async def kd_leaderboard(self,i:discord.Interaction,service:str=None):
        sid=await self.api.service(i.guild_id,service)
        with db.conn() as c:
            rows=c.execute('SELECT lower(killer) name,COUNT(*) kills FROM ark_events WHERE guild_id=? AND service=? AND killer IS NOT NULL GROUP BY lower(killer) ORDER BY kills DESC,name LIMIT 20',(i.guild_id,sid)).fetchall()
        await i.response.send_message(embed=emb('Tracked kills','\n'.join(f"{n}. {discord.utils.escape_markdown(r['name'])} — {r['kills']}" for n,r in enumerate(rows,1)) or 'No matching kills recorded.').set_footer(text='Counts matching kill lines, not verified lifetime PvP kills.'))

    @app_commands.command(name='playtime',description='Show estimated online time observed while tracking is running')
    @app_commands.guild_only()
    async def playtime(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        sid=await self.api.service(i.guild_id,service)
        with db.conn() as c:
            try: rows=c.execute('SELECT player_id,name,seconds FROM pt_time WHERE service=?',(sid,)).fetchall()
            except Exception: rows=[]
            if not rows: rows=c.execute('SELECT * FROM ark_playtime WHERE guild_id=? AND service=?',(i.guild_id,sid)).fetchall()
        player=resolve_name([dict(r, id=r['player_id']) for r in rows],name)
        await i.response.send_message(f"{discord.utils.escape_markdown(player['name'])}: approximately {player['seconds']/3600:.2f} hours observed online. Excludes bot downtime and failed/unsupported player queries; not lifetime playtime.")

    async def file_size(self,sid,path):
        return await self.api.file_size(sid,path)

    async def read_chunk(self,sid,path,offset,length):
        data=await self.api.request('GET',f'/services/{sid}/gameservers/file_server/seek',params={'file':path,'offset':offset,'length':length,'mode':'raw'})
        return await self.api.fetch_signed(data.get('token'),keep_last=length,max_bytes=length,raw=True)

    async def sample_playtime(self,row):
        key=(row['guild_id'],row['service'])
        now=int(time.time())
        if now-self.last_sample.get(key,0)<60: return
        self.last_sample[key]=now
        try: players=await self.api.players(row['service'])
        except NitradoError:
            # Drop open sessions on failure, so a later successful query cannot count an outage.
            with db.conn() as c: c.execute('UPDATE ark_playtime SET last_seen=NULL WHERE guild_id=? AND service=?',key)
            return
        online=[p for p in players if p.get('id') and str(p.get('online','')).lower() in ('true','1')]
        ids={str(p['id']) for p in online}
        with db.conn() as c:
            previous=c.execute('SELECT player_id,last_seen FROM ark_playtime WHERE guild_id=? AND service=?',key).fetchall()
            for old in previous:
                if old['player_id'] not in ids: c.execute('UPDATE ark_playtime SET last_seen=NULL WHERE guild_id=? AND service=? AND player_id=?',(*key,old['player_id']))
            for player in online:
                c.execute('INSERT INTO ark_playtime(guild_id,service,player_id,name,last_seen) VALUES(?,?,?,?,?) ON CONFLICT(guild_id,service,player_id) DO UPDATE SET name=excluded.name,seconds=seconds+CASE WHEN last_seen IS NOT NULL AND excluded.last_seen-last_seen BETWEEN 0 AND 90 THEN excluded.last_seen-last_seen ELSE 0 END,last_seen=excluded.last_seen',(*key,str(player['id']),player.get('name','Unknown'),now))

    async def step(self,row):
        size=await self.file_size(row['service'],row['path'])
        if size<row['offset']:
            with db.conn() as c:
                c.execute('UPDATE ark_feed SET offset=0,pending=X\'\',generation=generation+1 WHERE guild_id=? AND service=?',(row['guild_id'],row['service']))
                row=dict(c.execute('SELECT * FROM ark_feed WHERE guild_id=? AND service=?',(row['guild_id'],row['service'])).fetchone())
        if size>row['offset']:
            data=await self.read_chunk(row['service'],row['path'],row['offset'],min(size-row['offset'],131072))
            ingest(row,data,row['offset']+len(data))
        channel=self.bot.get_channel(row['channel_id'])
        if channel:
            with db.conn() as c:
                events=c.execute('SELECT id,line,killer,victim FROM ark_events WHERE guild_id=? AND service=? AND delivered=0 ORDER BY created,rowid LIMIT 100',(row['guild_id'],row['service'])).fetchall()
            if events:
                content='\n'.join(e['line'] for e in events)
                await channel.send(f"ARK log feed — service {row['service']}",file=discord.File(io.BytesIO(content.encode()),filename='ark-log.txt'),allowed_mentions=discord.AllowedMentions.none())
                routes=db.get_setting(row['guild_id'],f"ark_routes:{row['service']}",{})
                for kind,cid in routes.items():
                    if cid==row['channel_id']: continue
                    destination=self.bot.get_channel(cid)
                    if destination is None: raise NitradoError('A configured log destination is unavailable.')
                    words={'admin':('admin','cheat'),'joins':('joined','left this ark','connected','disconnected')}
                    if kind=='kd':
                        summaries=[]
                        with db.conn() as c:
                            for event in events:
                                if event['killer'] is None: continue
                                totals=[]
                                for name in (event['killer'],event['victim']):
                                    kills=c.execute('SELECT COUNT(*) FROM ark_events WHERE guild_id=? AND service=? AND lower(killer)=lower(?)',(row['guild_id'],row['service'],name)).fetchone()[0]
                                    deaths=c.execute('SELECT COUNT(*) FROM ark_events WHERE guild_id=? AND service=? AND lower(victim)=lower(?)',(row['guild_id'],row['service'],name)).fetchone()[0]
                                    totals.append(f'{name} K/D: {kills}/{deaths}')
                                summaries.append(f"{event['killer']} killed {event['victim']} | Current tracked totals: {' | '.join(totals)}")
                        if summaries:
                            await destination.send(f"ARK tracked KD — service {row['service']} · matching log lines only",file=discord.File(io.BytesIO('\n'.join(summaries).encode()),filename='kd.txt'),allowed_mentions=discord.AllowedMentions.none())
                        continue
                    selected=[e['line'] for e in events if (e['killer'] is not None or bool(re.search(r'\b(?:killed|died)\b',e['line'],re.I)) if kind=='kills' else any(word in e['line'].casefold() for word in words.get(kind,())))]
                    if selected:
                        await destination.send(f"ARK {kind} feed — service {row['service']}",file=discord.File(io.BytesIO('\n'.join(selected).encode()),filename=f'{kind}.txt'),allowed_mentions=discord.AllowedMentions.none())
                with db.conn() as c: c.executemany('UPDATE ark_events SET delivered=1 WHERE id=?',[(e['id'],) for e in events])
        await self.sample_playtime(row)

    @tasks.loop(seconds=1)
    async def poller(self):
        with db.conn() as c: rows=c.execute('SELECT * FROM ark_feed WHERE ready=1').fetchall()
        for record in rows:
            row=dict(record)
            key=(row['guild_id'],row['service'])
            if row['service'] not in service_ids() or time.monotonic()<self.next_poll.get(key,0): continue
            try:
                await self.step(row)
                self.failures[key]=0
                self.next_poll[key]=time.monotonic()+self.interval
            except Exception as exc:
                count=self.failures.get(key,0)+1
                self.failures[key]=count
                self.next_poll[key]=time.monotonic()+min(300, max(self.interval,5)*2**min(count,6))
                # Never print signed URLs or tokens from HTTP exception text.
                log.warning('ARK feed failure service=%s type=%s; backing off',row['service'],type(exc).__name__)

    @poller.before_loop
    async def before_poller(self):
        await self.bot.wait_until_ready()
        with db.conn() as c: c.execute('UPDATE ark_playtime SET last_seen=NULL')


async def setup(bot):
    await bot.add_cog(FeedCog(bot,bot.nitrado_api))

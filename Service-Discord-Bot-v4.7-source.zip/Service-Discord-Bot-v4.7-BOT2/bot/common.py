import os
import re
from datetime import datetime
from zoneinfo import ZoneInfo
import discord
from discord import app_commands
import db

BRAND = "Service Manager"
VERSION = "4.7.0"
COLOR = 0x5865F2

def emb(title, description="", color=COLOR):
    e = discord.Embed(title=title, description=description or None, color=color)
    return e

def color_int(value, default=0x5865F2):
    if value is None:
        return default
    s = str(value).strip().lstrip("#")
    if not re.fullmatch(r"[0-9A-Fa-f]{6}", s):
        raise ValueError("Use a 6-digit HEX color such as #5865F2.")
    return int(s, 16)

def staff_role(guild):
    rid = int(db.get_setting(guild.id, "staff_role_id", 0) or 0)
    return guild.get_role(rid) if rid else None

def admin_check():
    async def predicate(i: discord.Interaction):
        if not i.guild:
            raise app_commands.CheckFailure("Use this inside a Discord server.")
        if i.user.id == i.guild.owner_id or i.user.guild_permissions.administrator:
            return True
        raise app_commands.CheckFailure("Administrator permission is required.")
    return app_commands.check(predicate)

def staff_check():
    async def predicate(i: discord.Interaction):
        if not i.guild:
            raise app_commands.CheckFailure("Use this inside a Discord server.")
        if i.user.id == i.guild.owner_id or i.user.guild_permissions.administrator:
            return True
        role = staff_role(i.guild)
        if role and isinstance(i.user, discord.Member) and role in i.user.roles:
            return True
        raise app_commands.CheckFailure("Staff permission is required.")
    return app_commands.check(predicate)

def format_placeholders(text, member):
    if not text:
        return ""
    return (str(text)
            .replace("{user}", member.display_name)
            .replace("{mention}", member.mention)
            .replace("{server}", member.guild.name)
            .replace("{member_count}", str(member.guild.member_count or 0)))


# ---------------- economy / hype helpers (from Fent Discord Manager v1.2) ----------------

def local_tz():
    try:
        return ZoneInfo(os.getenv("TIMEZONE", "America/New_York").strip() or "America/New_York")
    except Exception:
        return ZoneInfo("America/New_York")

DATE_FORMATS = [
    "%Y-%m-%d %H:%M", "%Y-%m-%d %I:%M%p", "%Y-%m-%d %I%p", "%Y-%m-%d",
    "%m/%d/%Y %H:%M", "%m/%d/%Y %I:%M%p", "%m/%d/%Y %I%p", "%m/%d/%Y",
    "%m/%d %H:%M", "%m/%d %I:%M%p", "%m/%d %I%p", "%m/%d",
]

def parse_when(text):
    """Parse a date/time typed by staff (TIMEZONE in .env). Returns a unix timestamp or raises ValueError."""
    raw = " ".join(str(text or "").upper().replace(" AM", "AM").replace(" PM", "PM").split())
    tz = local_tz()
    now = datetime.now(tz)
    for fmt in DATE_FORMATS:
        try:
            dt = datetime.strptime(raw, fmt)
        except ValueError:
            continue
        dt = dt.replace(tzinfo=tz)
        if "%Y" not in fmt:
            dt = dt.replace(year=now.year)
            if (now - dt).days > 2:
                dt = dt.replace(year=now.year + 1)
        return int(dt.timestamp())
    raise ValueError("I couldn't read that date. Examples: `10/03 6:00PM`, `10/03/2026 18:00`, `2026-10-03 18:00`.")

def economy_staff_role(guild):
    rid = int(db.get_setting(guild.id, "economy_staff_role_id", 0) or 0)
    return guild.get_role(rid) if rid else None

def is_economy_staff(member):
    """Owner/admins always. Otherwise the role picked with /economy staff-role (falls back to the ticket staff role)."""
    if not isinstance(member, discord.Member):
        return False
    if member.id == member.guild.owner_id or member.guild_permissions.administrator:
        return True
    role = economy_staff_role(member.guild) or staff_role(member.guild)
    return bool(role and role in member.roles)

def economy_staff_check():
    async def predicate(i: discord.Interaction):
        if not i.guild:
            raise app_commands.CheckFailure("Use this inside a Discord server.")
        if is_economy_staff(i.user):
            return True
        role = economy_staff_role(i.guild) or staff_role(i.guild)
        raise app_commands.CheckFailure(f"Only {role.mention if role else 'staff'} can use this.")
    return app_commands.check(predicate)

async def send_to_setting_channel(guild, key, *args, **kwargs):
    cid = int(db.get_setting(guild.id, key, 0) or 0)
    ch = guild.get_channel(cid) if cid else None
    if isinstance(ch, (discord.TextChannel, discord.Thread)):
        try:
            return await ch.send(*args, **kwargs)
        except Exception as e:
            print(f"Send warning ({key}): {type(e).__name__}")
    return None

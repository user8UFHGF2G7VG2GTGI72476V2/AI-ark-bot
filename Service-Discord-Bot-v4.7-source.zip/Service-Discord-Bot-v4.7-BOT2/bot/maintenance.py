import ast
import asyncio
import importlib
import importlib.util
from pathlib import Path
import discord
from discord import app_commands
from discord.ext import commands
from extensions import FEATURE_EXTENSIONS


class MaintenanceCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot
        self.reload_lock=asyncio.Lock()

    async def owner(self,i):
        if not await self.bot.is_owner(i.user):
            raise app_commands.CheckFailure('Only the Discord application owner or its authorized developer team can reload bot code.')

    async def reload_features(self,names):
        if not names or any(name not in FEATURE_EXTENSIONS for name in names):
            raise ValueError('Choose an allowed feature module.')
        root=Path(__file__).resolve().parent
        # Validate every requested source before unloading anything.
        for name in names:
            path=root/f'{name}.py'
            ast.parse(path.read_text(encoding='utf-8-sig'),filename=str(path))
        for name in names:
            # Avoid timestamp/size-based stale bytecode when files are replaced quickly.
            cached=Path(importlib.util.cache_from_source(str(root/f'{name}.py')))
            cached.unlink(missing_ok=True)
        importlib.invalidate_caches()
        completed=[]
        for name in names:
            try:
                await self.bot.reload_extension(name)
            except Exception as exc:
                return completed,name,type(exc).__name__
            completed.append(name)
        return completed,None,None

    @app_commands.command(name='reload',description='Bot owner: apply updated feature files without disconnecting')
    @app_commands.guild_only()
    @app_commands.choices(module=[app_commands.Choice(name=name,value=name) for name in ('all',*FEATURE_EXTENSIONS)])
    async def reload(self,i:discord.Interaction,module:app_commands.Choice[str],sync_commands:bool=True):
        await self.owner(i)
        if self.reload_lock.locked():
            return await i.response.send_message('Another reload is running. Try again after it finishes.',ephemeral=True)
        await i.response.defer(ephemeral=True)
        async with self.reload_lock:
            names=list(FEATURE_EXTENSIONS) if module.value=='all' else [module.value]
            try: completed,failed,error=await self.reload_features(names)
            except (SyntaxError,OSError,ValueError) as exc:
                await i.followup.send(f'Source validation failed ({type(exc).__name__}); no features were reloaded. Fix the local files and retry.',ephemeral=True)
                return
            message=f"Reloaded: {', '.join(completed) or 'none'}."
            if failed:
                message+=f' Reload of {failed} failed ({error}); discord.py attempted to restore its previous extension. Remaining modules were skipped.'
            if sync_commands and completed:
                try:
                    await self.bot.tree.sync()
                    message+=' Slash command definitions synced.'
                except discord.HTTPException:
                    message+=' Code is active, but slash sync failed. Retry /sync-commands.'
            await i.followup.send(message,ephemeral=True)

    @app_commands.command(name='sync-commands',description='Bot owner: synchronize global slash command definitions')
    @app_commands.guild_only()
    async def sync_commands(self,i:discord.Interaction):
        await self.owner(i)
        await i.response.defer(ephemeral=True)
        async with self.reload_lock:
            result=await self.bot.tree.sync()
        await i.followup.send(f'Synced {len(result)} global command definitions.',ephemeral=True)


async def setup(bot):
    await bot.add_cog(MaintenanceCog(bot))

"""Notifiers: pretty embeds posted when something happens on your Nitrado servers.

Sources
  log     -> watches the server log lines the bot already reads through your Nitrado
             lifetime token (/logs-setup or /ark-log-setup must be running). A rule is a
             pattern; text it captures fills the embed, e.g. "{color} OSD has spawned on {map}!".
  status  -> posts when a server goes online / offline / restarting (no log feed needed).
  manual  -> staff post it themselves with /notifier send (fills a short form).

Presets are starting points. Check what your log actually says with /nitrado logs and
adjust a rule with /notifier pattern if needed.
"""
import asyncio
import re
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import admin_check, color_int
from nitrado_api import NitradoError, service_ids
from ticket_media import clean_url, media_url, media_files, cache_media, store_image
import ark_services

NUM = r'-?\d{1,3}(?:\.\d+)?'
COORDS = rf'(?:.*?(?P<lat>{NUM})\s*[,/ ]\s*(?P<lon>{NUM}))?'
PRESETS = {
    'osd': dict(label='Orbital Supply Drop (OSD)', source='log', color='8A2BE2', fields='Lat={lat}|Lon={lon}',
                title='{Color} OSD has spawned on {map}!',
                pattern=rf'(?i)\b(?P<color>white|green|blue|purple|yellow|red|cyan|orange|gold)\s+(?:orbital\s+supply\s+drop|osd)\b{COORDS}'),
    'element_node': dict(label='Element Node', source='log', color='9B1B6E', fields='Lat={lat}|Lon={lon}',
                         title='A {size} Element Node has spawned on {map}!',
                         pattern=rf'(?i)\b(?P<size>\d+\s?k)\s+element\s+node\b{COORDS}'),
    'asteroid': dict(label='Asteroid (Genesis 2)', source='log', color='2E8B57', fields='Primary resources={primary}|Secondary Resources={secondary}',
                     title='New asteroid of {primary} available on {map}!',
                     pattern=r'(?i)\basteroid\b(?:\s+of)?\s+(?P<primary>[A-Za-z][A-Za-z ,]{1,40}?)(?:\s*[/|]\s*(?P<secondary>[A-Za-z][A-Za-z ,]{1,40}))?\s*(?:available|spawned|$)'),
    'join': dict(label='Player joined', source='log', color='2ECC71', fields='', title='🟢 {player} joined {server}',
                 pattern=r'(?P<player>[^:\r\n]{1,60}?) joined this ARK'),
    'leave': dict(label='Player left', source='log', color='E74C3C', fields='', title='🔴 {player} left {server}',
                  pattern=r'(?P<player>[^:\r\n]{1,60}?) left this ARK'),
    'dino_death': dict(label='Tribe dino killed', source='log', color='7F8C8D', fields='Server={server}',
                       title="💀 {dino} was killed", pattern=r"(?i)Your '(?P<dino>[^']{1,100})' was killed"),
    'status': dict(label='Server online / offline', source='status', color='5865F2', fields='Players={players}',
                   title='{status_emoji} {server} is {status}', pattern=''),
    'custom': dict(label='Custom log pattern', source='log', color='8A2BE2', fields='', title='{line}', pattern=''),
    'manual': dict(label='Manual (staff post it with /notifier send)', source='manual', color='8A2BE2', fields='Lat={lat}|Lon={lon}',
                   title='{Color} OSD has spawned on {map}!', pattern=''),
}
STATUS_TEXT = {
    'started': ('🟢', 'online'), 'stopped': ('🔴', 'offline'), 'stopping': ('🟠', 'shutting down'), 'restarting': ('🟡', 'restarting'),
    'suspended': ('⛔', 'suspended'), 'guardian_locked': ('🔒', 'locked'), 'gs_installation': ('🛠️', 'installing'),
    'backup_restore': ('♻️', 'restoring a backup'), 'backup_creation': ('💾', 'making a backup'), 'chunkfix': ('🛠️', 'under maintenance'),
}
ANSI = [(0xDC322F, 31), (0x859900, 32), (0xB58900, 33), (0x268BD2, 34), (0xD33682, 35), (0x2AA198, 36), (0xEEEEEE, 37), (0x888888, 30)]


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS notifiers(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          preset TEXT NOT NULL DEFAULT 'custom',
          source TEXT NOT NULL DEFAULT 'log',
          channel_id INTEGER NOT NULL,
          service TEXT,
          pattern TEXT NOT NULL DEFAULT '',
          title TEXT NOT NULL DEFAULT '',
          description TEXT NOT NULL DEFAULT '',
          fields TEXT NOT NULL DEFAULT '',
          color TEXT NOT NULL DEFAULT '8A2BE2',
          image TEXT NOT NULL DEFAULT '',
          image_file TEXT,
          ping_role_id INTEGER,
          cooldown INTEGER NOT NULL DEFAULT 0,
          enabled INTEGER NOT NULL DEFAULT 1,
          last_fired INTEGER NOT NULL DEFAULT 0,
          UNIQUE(guild_id,name)
        );
        ''')


def rows(gid=None, source=None, enabled_only=False):
    sql, args = 'SELECT * FROM notifiers WHERE 1=1', []
    if gid is not None: sql += ' AND guild_id=?'; args.append(gid)
    if source: sql += ' AND source=?'; args.append(source)
    if enabled_only: sql += ' AND enabled=1'
    with db.conn() as c:
        return [dict(r) for r in c.execute(sql + ' ORDER BY id', args).fetchall()]


def get(gid, name):
    with db.conn() as c:
        r = c.execute('SELECT * FROM notifiers WHERE guild_id=? AND lower(name)=lower(?)', (gid, name)).fetchone()
    return dict(r) if r else None


def update(nid, **values):
    if not values:
        return
    with db.conn() as c:
        c.execute('UPDATE notifiers SET ' + ','.join(f'{k}=?' for k in values) + ' WHERE id=?', (*values.values(), nid))


def placeholders(text):
    return list(dict.fromkeys(m.casefold() for m in re.findall(r'\{(\w+)\}', text or '')))


def fill(text, values):
    def sub(m):
        key = m.group(1)
        value = values.get(key.casefold())
        if value in (None, ''):
            return '—'
        value = str(value).strip()
        if key[:1].isupper():
            value = value[:1].upper() + value[1:]
        return value
    return re.sub(r'\{(\w+)\}', sub, text or '')


def ansi_code(color):
    r, g, b = (color >> 16) & 255, (color >> 8) & 255, color & 255
    return min(ANSI, key=lambda p: (((p[0] >> 16) & 255) - r) ** 2 + (((p[0] >> 8) & 255) - g) ** 2 + ((p[0] & 255) - b) ** 2)[1]


def compile_pattern(pattern):
    try:
        return re.compile(pattern)
    except re.error as e:
        raise ValueError(f'That pattern is not valid: {e}') from None


def match_line(rule, line):
    if not rule['pattern']:
        return None
    m = compile_pattern(rule['pattern']).search(line)
    if not m:
        return None
    return {k.casefold(): v for k, v in m.groupdict().items() if v is not None}


def base_values(sid, line=''):
    values = {'map': ark_services.map_name(sid) if sid else 'Unknown map', 'server': ark_services.name(sid) if sid else 'Server',
              'line': line, 'service': sid or ''}
    info = ark_services.info(sid) if sid else {}
    if info.get('players') is not None:
        values['players'] = f"{info.get('players')}/{info.get('max', '?')}"
    return values


def build(rule, values):
    color = color_int(rule['color'] or '8A2BE2')
    e = discord.Embed(title=fill(rule['title'], values)[:256] or None, description=fill(rule['description'], values)[:4096] or None, color=color)
    code = ansi_code(color)
    for part in [p for p in (rule['fields'] or '').split('|') if '=' in p][:25]:
        label, template = part.split('=', 1)
        value = fill(template, values)
        e.add_field(name=label.strip()[:256] or '​', value=f'```ansi\n\u001b[0;{code}m{value[:900]}\u001b[0m\n```', inline=True)
    image = media_url(rule['guild_id'], {'image': rule.get('image'), 'image_file': rule.get('image_file')}, 'image')
    if image:
        e.set_image(url=image)
    e.timestamp = discord.utils.utcnow()
    return e


def rule_files(rule):
    return media_files(rule['guild_id'], {'image': rule.get('image'), 'image_file': rule.get('image_file')})


async def notifier_ac(i, current):
    current = (current or '').casefold()
    return [app_commands.Choice(name=f"{r['name']} · {PRESETS.get(r['preset'], {}).get('label', r['preset'])}"[:100], value=r['name'])
            for r in rows(i.guild_id) if current in r['name'].casefold()][:25]


class EditModal(discord.ui.Modal):
    def __init__(self, rule):
        super().__init__(title=f"Edit {rule['name']}"[:45], timeout=600)
        self.rule = rule
        def ti(label, value, **kw):
            return discord.ui.TextInput(label=label, default=value or None, required=False, **kw)
        self.t = ti('Title (use {placeholders})', rule['title'], max_length=256)
        self.f = ti('Fields: Label={value}|Label2={value2}', rule['fields'], max_length=1000)
        self.d = ti('Description (optional)', rule['description'], style=discord.TextStyle.paragraph, max_length=2000)
        self.c = ti('Color (HEX)', '#' + rule['color'], max_length=7)
        self.img = ti('Image URL (blank = none, keep "(uploaded)")', '(uploaded)' if rule.get('image_file') else rule.get('image'), max_length=1000)
        for item in (self.t, self.f, self.d, self.c, self.img):
            self.add_item(item)

    async def on_submit(self, i):
        try:
            color = f'{color_int(self.c.value or "8A2BE2"):06X}'
            values = dict(title=self.t.value.strip(), fields=self.f.value.strip(), description=self.d.value.strip(), color=color)
            img = self.img.value.strip()
            await i.response.defer(ephemeral=True)
            if not img:
                values.update(image='', image_file=None)
            elif img != '(uploaded)':
                cached = await cache_media(i.guild_id, {'image': clean_url(img)})
                values.update(image='', image_file=cached.get('image_file'))
        except ValueError as e:
            if i.response.is_done(): return await i.followup.send(f'❌ {e}', ephemeral=True)
            return await i.response.send_message(f'❌ {e}', ephemeral=True)
        update(self.rule['id'], **values)
        rule = get(i.guild_id, self.rule['name'])
        sample = base_values(rule['service'] or (service_ids() or [None])[0])
        for key in placeholders(rule['title'] + rule['fields'] + rule['description']):
            sample.setdefault(key, f'<{key}>')
        await i.followup.send('✅ Saved. Preview:', embed=build(rule, sample), files=rule_files(rule), ephemeral=True)


class SendModal(discord.ui.Modal):
    def __init__(self, rule, keys):
        super().__init__(title=f"Post {rule['name']}"[:45], timeout=600)
        self.rule, self.inputs = rule, {}
        for key in keys[:5]:
            item = discord.ui.TextInput(label=key.title()[:45], required=False, max_length=200,
                                        default=ark_services.map_name(rule['service']) if key == 'map' and rule['service'] else None)
            self.inputs[key] = item
            self.add_item(item)

    async def on_submit(self, i):
        values = base_values(self.rule['service'])
        values.update({k: v.value.strip() for k, v in self.inputs.items() if v.value.strip()})
        cog = i.client.get_cog('NotifierCog')
        ok = await cog.deliver(self.rule, values, force=True) if cog else False
        await i.response.send_message('✅ Posted.' if ok else '❌ I could not post in that channel. Check my permissions.', ephemeral=True)


class NotifierCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api = bot.nitrado_api
        self.last_status = {}
        init_tables()

    async def cog_load(self):
        self.log_loop.start()
        self.status_loop.start()

    async def cog_unload(self):
        for loop in (self.log_loop, self.status_loop):
            task = loop.get_task()
            loop.cancel()
            if task:
                await asyncio.gather(task, return_exceptions=True)

    async def deliver(self, rule, values, force=False):
        now = int(time.time())
        if not force and rule['cooldown'] and now - int(rule['last_fired'] or 0) < rule['cooldown']:
            return False
        guild = self.bot.get_guild(rule['guild_id'])
        channel = guild.get_channel(rule['channel_id']) if guild else None
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            return False
        role = guild.get_role(int(rule['ping_role_id'] or 0)) if rule.get('ping_role_id') else None
        try:
            await channel.send(content=role.mention if role else None, embed=build(rule, values), files=rule_files(rule),
                               allowed_mentions=discord.AllowedMentions(roles=True))
        except discord.HTTPException:
            return False
        update(rule['id'], last_fired=now)
        rule['last_fired'] = now
        return True

    @tasks.loop(seconds=10)
    async def log_loop(self):
        cursor = db.get_setting(0, 'notifier_cursor', None)
        with db.conn() as c:
            try:
                top = c.execute('SELECT COALESCE(MAX(rowid),0) FROM ark_events').fetchone()[0]
            except Exception:
                return  # log feed tables not created yet
            if cursor is None or int(cursor) > top:
                db.set_setting(0, 'notifier_cursor', top)  # start with new lines only
                return
            events = c.execute('SELECT rowid,guild_id,service,line FROM ark_events WHERE rowid>? ORDER BY rowid LIMIT 500', (int(cursor),)).fetchall()
        if not events:
            return
        rules = rows(source='log', enabled_only=True)
        for ev in events:
            for rule in rules:
                if rule['guild_id'] != ev['guild_id'] or (rule['service'] and rule['service'] != ev['service']):
                    continue
                try:
                    found = match_line(rule, ev['line'] or '')
                except ValueError:
                    continue
                if found is None:
                    continue
                values = base_values(ev['service'], ev['line'])
                values.update(found)
                await self.deliver(rule, values)
        db.set_setting(0, 'notifier_cursor', events[-1]['rowid'])

    @log_loop.before_loop
    async def before_log(self):
        await self.bot.wait_until_ready()

    @tasks.loop(seconds=60)
    async def status_loop(self):
        status_rules = rows(source='status', enabled_only=True)
        if not status_rules:
            return
        for sid in service_ids():
            try:
                info = ark_services.remember(sid, await self.api.details(sid))
            except NitradoError:
                continue
            status = info.get('status', 'unknown')
            previous = self.last_status.get(sid)
            self.last_status[sid] = status
            if previous is None or previous == status:
                continue
            emoji, text = STATUS_TEXT.get(status, ('ℹ️', status.replace('_', ' ')))
            values = base_values(sid)
            values.update(status=text, status_emoji=emoji)
            for rule in status_rules:
                if not rule['service'] or rule['service'] == sid:
                    await self.deliver(rule, values)

    @status_loop.before_loop
    async def before_status(self):
        await self.bot.wait_until_ready()

    # ----- commands -----
    notifier = app_commands.Group(name='notifier', description='Server event notifiers (OSD, nodes, joins, status...)', guild_only=True)

    @notifier.command(name='create', description='Admin: make a notifier from a preset')
    @admin_check()
    @app_commands.describe(name='A short name, e.g. osd-ext', channel='Where it posts', preset='What it watches for',
                           server='Only this server (blank = all servers)', pattern='Custom pattern (only for "Custom log pattern")',
                           ping_role='Optional role to ping', cooldown_seconds='Minimum time between posts')
    @app_commands.choices(preset=[app_commands.Choice(name=v['label'], value=k) for k, v in PRESETS.items()])
    @app_commands.autocomplete(server=ark_services.service_autocomplete)
    async def create(self, i: discord.Interaction, name: app_commands.Range[str, 1, 40], channel: discord.TextChannel,
                     preset: app_commands.Choice[str], server: str = None, pattern: app_commands.Range[str, 1, 500] = None,
                     ping_role: discord.Role = None, cooldown_seconds: app_commands.Range[int, 0, 86400] = 0):
        p = dict(PRESETS[preset.value])
        if get(i.guild_id, name):
            return await i.response.send_message('❌ A notifier with that name exists.', ephemeral=True)
        if server and server not in service_ids():
            return await i.response.send_message('❌ Pick a server from the list.', ephemeral=True)
        if pattern:
            try: compile_pattern(pattern)
            except ValueError as e: return await i.response.send_message(f'❌ {e}', ephemeral=True)
            p['pattern'] = pattern
        if preset.value == 'custom' and not p['pattern']:
            return await i.response.send_message('❌ A custom notifier needs a `pattern` (text to look for in the log).', ephemeral=True)
        with db.conn() as c:
            c.execute('''INSERT INTO notifiers(guild_id,name,preset,source,channel_id,service,pattern,title,fields,color,ping_role_id,cooldown)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (i.guild_id, name.strip(), preset.value, p['source'], channel.id, server, p['pattern'],
                                                              p['title'], p['fields'], p['color'], ping_role.id if ping_role else None, cooldown_seconds))
            feeds = c.execute('SELECT COUNT(*) FROM ark_feed WHERE guild_id=? AND ready=1', (i.guild_id,)).fetchone()[0] if p['source'] == 'log' else 1
        notes = {'log': 'It posts when a matching line appears in the server log.',
                 'status': 'It posts when a server changes between online / offline / restarting.',
                 'manual': 'Post it any time with `/notifier send`.'}[p['source']]
        warn = '' if feeds else '\n⚠️ No log feed is running in this server yet — run `/logs-setup` so the bot reads your Nitrado logs.'
        rule = get(i.guild_id, name)
        sample = base_values(server or (service_ids() or [None])[0])
        for key in placeholders(rule['title'] + rule['fields']):
            sample.setdefault(key, f'<{key}>')
        await i.response.send_message(f"✅ Notifier **{name}** → {channel.mention}. {notes}\nChange the look with `/notifier edit`, test it with `/notifier test`.{warn}",
                                      embed=build(rule, sample), ephemeral=True)

    @notifier.command(name='edit', description='Admin: change a notifier\'s title, fields, color and image')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    async def edit(self, i: discord.Interaction, name: str):
        rule = get(i.guild_id, name)
        if not rule:
            return await i.response.send_message('❌ No notifier with that name.', ephemeral=True)
        await i.response.send_modal(EditModal(rule))

    @notifier.command(name='image', description='Admin: upload the picture shown on a notifier')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    async def image(self, i: discord.Interaction, name: str, image: discord.Attachment = None):
        rule = get(i.guild_id, name)
        if not rule:
            return await i.response.send_message('❌ No notifier with that name.', ephemeral=True)
        await i.response.defer(ephemeral=True)
        if image is None:
            update(rule['id'], image='', image_file=None)
            return await i.followup.send('✅ Image removed.', ephemeral=True)
        try:
            update(rule['id'], image='', image_file=store_image(i.guild_id, await image.read()))
        except ValueError as e:
            return await i.followup.send(f'❌ {e}', ephemeral=True)
        await i.followup.send('✅ Image saved.', ephemeral=True)

    @notifier.command(name='pattern', description='Admin: change what log text a notifier looks for')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    @app_commands.describe(pattern='Regex. Name the parts you want: (?P<lat>...) becomes {lat}', example='A real log line to check it against')
    async def pattern(self, i: discord.Interaction, name: str, pattern: app_commands.Range[str, 1, 500], example: str = None):
        rule = get(i.guild_id, name)
        if not rule:
            return await i.response.send_message('❌ No notifier with that name.', ephemeral=True)
        try:
            compile_pattern(pattern)
        except ValueError as e:
            return await i.response.send_message(f'❌ {e}', ephemeral=True)
        rule['pattern'] = pattern
        if example:
            found = match_line(rule, example)
            if found is None:
                return await i.response.send_message('❌ That pattern does not match your example line. Nothing was saved.', ephemeral=True)
        update(rule['id'], pattern=pattern, source='log' if rule['source'] == 'manual' else rule['source'])
        await i.response.send_message('✅ Pattern saved.' + (f" It captured: {', '.join(f'`{k}`={v}' for k, v in found.items()) or 'nothing named'}" if example else ''),
                                      ephemeral=True)

    @notifier.command(name='test', description='Admin: see what a notifier would post for a log line')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    async def test(self, i: discord.Interaction, name: str, line: app_commands.Range[str, 1, 1000] = None):
        rule = get(i.guild_id, name)
        if not rule:
            return await i.response.send_message('❌ No notifier with that name.', ephemeral=True)
        values = base_values(rule['service'] or (service_ids() or [None])[0], line or '')
        if line and rule['source'] == 'log':
            found = match_line(rule, line)
            if found is None:
                return await i.response.send_message('❌ That line would **not** trigger this notifier.', ephemeral=True)
            values.update(found)
        else:
            for key in placeholders(rule['title'] + rule['fields'] + rule['description']):
                values.setdefault(key, f'<{key}>')
        await i.response.send_message('This is what it would post:', embed=build(rule, values), files=rule_files(rule), ephemeral=True)

    @notifier.command(name='send', description='Staff/Admin: post a notifier now and fill in the details yourself')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    async def send(self, i: discord.Interaction, name: str):
        rule = get(i.guild_id, name)
        if not rule:
            return await i.response.send_message('❌ No notifier with that name.', ephemeral=True)
        keys = [k for k in placeholders(rule['title'] + rule['fields'] + rule['description']) if k not in ('server', 'line', 'service')]
        if not keys:
            ok = await self.deliver(rule, base_values(rule['service']), force=True)
            return await i.response.send_message('✅ Posted.' if ok else '❌ Could not post there.', ephemeral=True)
        await i.response.send_modal(SendModal(rule, keys))

    @notifier.command(name='list', description='Show notifiers')
    @admin_check()
    async def list_cmd(self, i: discord.Interaction):
        lines = [f"{'🟢' if r['enabled'] else '⚪'} **{r['name']}** · {PRESETS.get(r['preset'], {}).get('label', r['preset'])} → <#{r['channel_id']}>"
                 + (f" · {ark_services.name(r['service'])}" if r['service'] else ' · all servers') for r in rows(i.guild_id)]
        await i.response.send_message(embed=discord.Embed(title='Notifiers', color=0x8A2BE2, description='\n'.join(lines)[:4000] or 'None yet — `/notifier create`.'),
                                      ephemeral=True)

    @notifier.command(name='toggle', description='Admin: turn a notifier on or off')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    async def toggle(self, i: discord.Interaction, name: str, enabled: bool):
        rule = get(i.guild_id, name)
        if not rule:
            return await i.response.send_message('❌ No notifier with that name.', ephemeral=True)
        update(rule['id'], enabled=1 if enabled else 0)
        await i.response.send_message(f"✅ **{rule['name']}** is {'on' if enabled else 'off'}.", ephemeral=True)

    @notifier.command(name='delete', description='Admin: delete a notifier')
    @admin_check()
    @app_commands.autocomplete(name=notifier_ac)
    async def delete(self, i: discord.Interaction, name: str):
        with db.conn() as c:
            n = c.execute('DELETE FROM notifiers WHERE guild_id=? AND lower(name)=lower(?)', (i.guild_id, name)).rowcount
        await i.response.send_message('✅ Deleted.' if n else '❌ No notifier with that name.', ephemeral=True)


async def setup(bot):
    await bot.add_cog(NotifierCog(bot))

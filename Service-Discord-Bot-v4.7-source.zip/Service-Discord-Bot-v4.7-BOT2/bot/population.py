"""Public ASE population feeds; independent of the Nitrado management token."""
import asyncio
import io
import json
import time
import unicodedata
import aiohttp
import discord
from discord import app_commands
from discord.ext import commands
from common import emb

FEEDS={
    'xbox':'https://arkdedicated.com/xbox/cache/unofficialserverlist.json',
    'playstation':'https://arkdedicated.com/ps4/cache/unofficialserverlist.json',
}


class FeedError(Exception): pass


def normalized(value):
    return ''.join(c for c in unicodedata.normalize('NFKC',str(value)).casefold() if c.isalnum())


def integer(value):
    try: return max(0,int(value))
    except (TypeError,ValueError): return None


def parse_feed(data,platform):
    if not isinstance(data,list): raise FeedError('The browser feed returned an unexpected format.')
    result=[]
    seen=set()
    for item in data:
        if not isinstance(item,dict): continue
        name=item.get('Name') or item.get('SessionName')
        if not isinstance(name,str) or not name.strip(): continue
        key=(item.get('SearchHandle') or item.get('NPSessionId'),item.get('IP'),item.get('Port'),name)
        if key in seen: continue
        seen.add(key)
        tags=item.get('SearchTags') or []
        crossplay=platform=='xbox' and 'crossplayallowuwp' in tags
        result.append({'name':name,'players':integer(item.get('NumPlayers')),'max':integer(item.get('MaxPlayers')),'map':item.get('MapName') or 'Unknown','platform':'Xbox / Windows 10' if crossplay else ('Xbox' if platform=='xbox' else 'PlayStation'),'crossplay':crossplay,'updated':integer(item.get('LastUpdated'))})
    return result


def matching(rows,keyword,platform='all'):
    term=normalized(keyword)
    if not term: raise FeedError('Enter at least one letter or number in the keyword.')
    rows=[r for r in rows if term in normalized(r['name']) and (platform!='xw10' or r['crossplay'])]
    return sorted(rows,key=lambda r:(-(r['players'] if r['players'] is not None else -1),r['name'].casefold()))


class PopulationCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot
        self.session=None
        self.cache={}
        self.locks={key:asyncio.Lock() for key in FEEDS}
        self.retry_after={}

    async def cog_unload(self):
        if self.session: await self.session.close()

    async def fetch(self,platform):
        async with self.locks[platform]:
            cached=self.cache.get(platform)
            if cached and time.monotonic()-cached[0]<60: return cached[1],cached[2],False
            try:
                if time.monotonic()<self.retry_after.get(platform,0): raise FeedError('Browser feed is temporarily rate limited.')
                if self.session is None or self.session.closed:
                    self.session=aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
                async with self.session.get(FEEDS[platform]) as response:
                    if response.status==429:
                        self.retry_after[platform]=time.monotonic()+60
                        raise FeedError('Browser feed is temporarily rate limited.')
                    if response.status!=200: raise FeedError(f'Browser feed returned HTTP {response.status}.')
                    chunks=[]
                    size=0
                    async for chunk in response.content.iter_chunked(65536):
                        size+=len(chunk)
                        if size>16*1024*1024: raise FeedError('Browser feed exceeded the download limit.')
                        chunks.append(chunk)
                    data=json.loads(b''.join(chunks))
                rows=parse_feed(data,platform)
                timestamp=int(time.time())
                self.cache[platform]=(time.monotonic(),rows,timestamp)
                return rows,timestamp,False
            except (aiohttp.ClientError,asyncio.TimeoutError,ValueError,FeedError):
                if cached and time.monotonic()-cached[0]<600: return cached[1],cached[2],True
                raise FeedError(f"{'Xbox / Windows 10' if platform=='xbox' else 'PlayStation'} browser feed is unavailable. Try again shortly.") from None

    async def search(self,keyword,platform='all'):
        sources=list(FEEDS) if platform=='all' else ['xbox' if platform=='xw10' else platform]
        results=await asyncio.gather(*(self.fetch(source) for source in sources),return_exceptions=True)
        rows=[]
        notices=[]
        timestamps=[]
        success=0
        for source,result in zip(sources,results):
            if isinstance(result,BaseException):
                notices.append(str(result) if isinstance(result,FeedError) else f'{source} feed failed.')
                continue
            batch,timestamp,stale=result
            success+=1
            rows.extend(batch)
            timestamps.append(timestamp)
            if stale: notices.append(f'{source}: using a cached feed because refresh failed.')
        if not success: raise FeedError(' '.join(notices))
        return matching(rows,keyword,platform),notices,min(timestamps)

    @app_commands.command(description='Search ASE Xbox/Windows 10 and PlayStation server populations')
    @app_commands.guild_only()
    @app_commands.checks.cooldown(1,10,key=lambda i:(i.guild_id,i.user.id))
    @app_commands.choices(platform=[app_commands.Choice(name=label,value=value) for label,value in [('All supported platforms','all'),('Xbox','xbox'),('Xbox / Windows 10 crossplay','xw10'),('PlayStation','playstation')]])
    async def pop(self,i:discord.Interaction,keyword:app_commands.Range[str,1,100],platform:app_commands.Choice[str]=None):
        await i.response.defer()
        try: rows,notices,timestamp=await self.search(keyword,platform.value if platform else 'all')
        except FeedError as exc:
            await i.followup.send(f'Population search unavailable: {exc}')
            return
        total=sum(r['players'] or 0 for r in rows)
        unknown=sum(r['players'] is None for r in rows)
        heading=f'{len(rows)} matching servers · {total} reported players'
        if unknown: heading+=f' · {unknown} unknown counts'
        lines=[]
        for row in rows[:20]:
            players='?' if row['players'] is None else row['players']
            capacity='?' if row['max'] is None else row['max']
            name=discord.utils.escape_markdown(row['name'])[:130]
            lines.append(f"**{name}**\n{players}/{capacity} · {row['map']} · {row['platform']}")
        detail='\n\n'.join(lines)[:3900] if rows else 'No matching entries in the available server-browser feeds. This does not prove the server is offline. Try a shorter keyword or check the platform.'
        embed=emb(f'Population: {keyword}'[:256],heading+'\n\n'+detail)
        embed.set_footer(text='ASE unofficial browser feeds · cached up to 60 seconds · Steam is not included')
        content=f'Feed fetched <t:{timestamp}:R>.'
        if notices: content+='\n'+'\n'.join(notices)
        kwargs={'embed':embed}
        if rows:
            report='\n'.join(f"{r['name']} | {r['players'] if r['players'] is not None else '?'}/{r['max'] if r['max'] is not None else '?'} | {r['map']} | {r['platform']}" for r in rows)
            kwargs['file']=discord.File(io.BytesIO(report.encode()),filename='population.txt')
        await i.followup.send(content,**kwargs)


async def setup(bot):
    await bot.add_cog(PopulationCog(bot))

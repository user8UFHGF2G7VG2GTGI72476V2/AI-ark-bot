import io, re, time, uuid
from pathlib import Path
from ticket_media import clean_url, media_url, media_files, image_extension, MEDIA_KEYS, cache_media, download_image, store_image
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import emb, color_int, admin_check, staff_check, staff_role

DEFAULT_PANEL = {
    "title": "Ticket Support",
    "description": "Select a ticket type below and our staff team will help you.",
    "color": "5865F2",
    "author_name": "Support",
    "author_icon": "",
    "image": "",
    "thumbnail": "",
    "footer": "Ticket System",
}
DEFAULT_TYPES = [
    {"label":"Support","value":"support","emoji":"🎫","description":"General support"},
    {"label":"Purchase","value":"purchase","emoji":"💳","description":"Purchase or payment support"},
    {"label":"Report","value":"report","emoji":"🚨","description":"Report a member or issue"},
]

def panel_config(guild_id):
    x = db.get_setting(guild_id, "ticket_panel_config", {}) or {}
    out = DEFAULT_PANEL.copy()
    out.update({k:v for k,v in x.items() if k in out or k in {key + "_file" for key in MEDIA_KEYS}})
    return out

def ticket_types(guild_id):
    """Custom ticket options. A new panel starts with NO options; add them with /add ticket-option."""
    x = db.get_setting(guild_id, "ticket_types", None)
    if not isinstance(x, list):
        return []
    if not db.get_setting(guild_id, "ticket_types_custom_v3", False):
        # One-time upgrade: drop the old built-in Support/Purchase/Report entries so the panel is fully custom.
        defaults = {(d["value"], d["label"]) for d in DEFAULT_TYPES}
        x = [t for t in x if not ((t.get("value"), t.get("label")) in defaults and not t.get("category_id"))]
        db.set_setting(guild_id, "ticket_types", x)
        db.set_setting(guild_id, "ticket_types_custom_v3", True)
    return x[:25]

def options_summary(guild_id):
    types = ticket_types(guild_id)
    if not types:
        return "**Ticket options:** none yet — add them with `/add ticket-option` (the dropdown appears once one exists)."
    return "**Ticket options:** " + ", ".join(f"{t.get('emoji') or ''} {t.get('label')}".strip() for t in types)

def build_panel_embed(guild_id, cfg=None):
    cfg = panel_config(guild_id) if cfg is None else cfg
    e = discord.Embed(title=cfg.get("title") or None,
                      description=cfg.get("description") or None,
                      color=color_int(cfg.get("color") or "5865F2"))
    if cfg.get("author_name"):
        e.set_author(name=cfg["author_name"])
        icon = media_url(guild_id, cfg, "author_icon")
        if icon: e.set_author(name=cfg["author_name"], icon_url=icon)
    for key in ("image", "thumbnail"):
        url = media_url(guild_id, cfg, key)
        if url: getattr(e, "set_" + key)(url=url)
    if cfg.get("footer"): e.set_footer(text=cfg["footer"])
    if len(e) > 6000:
        raise ValueError("The embed is too long. Shorten the description or footer (6,000 characters total).")
    return e

async def editor_error(i, error):
    if isinstance(error, discord.Forbidden):
        message = "I need View Channel, Send Messages, Embed Links, and Attach Files in the destination channel."
    elif isinstance(error, discord.HTTPException):
        message = f"Discord rejected the embed: {error.text[:1200]}"
    else:
        message = str(error)[:1200]
    if i.response.is_done():
        await i.followup.send("❌ " + message, ephemeral=True)
    else:
        await i.response.send_message("❌ " + message, ephemeral=True)


def is_admin_member(member):
    return isinstance(member, discord.Member) and (member.id == member.guild.owner_id or member.guild_permissions.administrator)

def is_staff_member(member):
    if not isinstance(member, discord.Member):
        return False
    if is_admin_member(member):
        return True
    role = staff_role(member.guild)
    return bool(role and role in member.roles)

def close_role_ids(guild_id):
    ids = db.get_setting(guild_id, "ticket_close_role_ids", []) or []
    return [int(x) for x in ids if str(x).isdigit()]

def can_close(member):
    """Administrators, or anyone with a role picked via /ticket close-role-add."""
    if is_admin_member(member):
        return True
    if not isinstance(member, discord.Member):
        return False
    allowed = set(close_role_ids(member.guild.id))
    return any(r.id in allowed for r in member.roles)

def ticket_pay_rate(guild_id, kind):
    rates = db.get_setting(guild_id, "ticket_pay_rates", {}) or {}
    try:
        return max(0.0, float(rates.get(str(kind), 0) or 0))
    except (TypeError, ValueError):
        return 0.0

def money_text(value):
    value = float(value or 0)
    return f"{value:.2f}".rstrip("0").rstrip(".")

async def claim_ticket_interaction(i: discord.Interaction):
    if not is_staff_member(i.user):
        return await i.response.send_message("❌ Staff permission is required.", ephemeral=True)
    with db.conn() as c:
        row = c.execute("SELECT * FROM tickets WHERE channel_id=? AND status='open'", (i.channel.id,)).fetchone()
        if not row:
            return await i.response.send_message("❌ This is not an open ticket.", ephemeral=True)
        if row["claimed_by"] and int(row["claimed_by"]) != i.user.id and not is_admin_member(i.user):
            return await i.response.send_message(f"❌ This ticket is already claimed by <@{row['claimed_by']}>.", ephemeral=True)
        c.execute("UPDATE tickets SET claimed_by=? WHERE channel_id=?", (i.user.id, i.channel.id))
    await i.response.send_message(f"✋ Ticket claimed by {i.user.mention}.")

async def log_ticket_pay_interaction(i: discord.Interaction):
    if not is_staff_member(i.user):
        return await i.response.send_message("❌ Staff permission is required.", ephemeral=True)
    with db.conn() as c:
        row = c.execute("SELECT * FROM tickets WHERE channel_id=? AND status='open'", (i.channel.id,)).fetchone()
        if not row:
            return await i.response.send_message("❌ This is not an open ticket.", ephemeral=True)
        if not row["claimed_by"]:
            return await i.response.send_message("❌ Claim the ticket before logging it for admin pay.", ephemeral=True)
        staff_id = int(row["claimed_by"])
        if staff_id != i.user.id and not is_admin_member(i.user):
            return await i.response.send_message(f"❌ Only the staff member who claimed this ticket (<@{staff_id}>) or an administrator can log it.", ephemeral=True)
        amount = ticket_pay_rate(i.guild.id, row["kind"])
        try:
            c.execute(
                "INSERT INTO ticket_pay_logs(channel_id,guild_id,staff_id,kind,amount,logged_at) VALUES(?,?,?,?,?,?)",
                (i.channel.id, i.guild.id, staff_id, row["kind"], amount, int(time.time()))
            )
        except Exception as e:
            if "UNIQUE" in str(e).upper():
                return await i.response.send_message("❌ This ticket has already been logged for admin pay.", ephemeral=True)
            raise
    label = next((x.get("label") for x in ticket_types(i.guild.id) if x.get("value") == row["kind"]), row["kind"])
    await i.response.send_message(f"💰 Logged **{label}** for <@{staff_id}> • Pay: **${money_text(amount)}**")

async def close_ticket_interaction(i: discord.Interaction):
    if not can_close(i.user):
        return await i.response.send_message("❌ You don't have permission to close tickets. An administrator can allow your role with `/ticket close-role-add`.", ephemeral=True)
    if not i.channel.permissions_for(i.guild.me).manage_channels:
        return await i.response.send_message("❌ I need the **Manage Channels** permission to delete this ticket. Give my role that permission (or allow it on the ticket category) and try again.", ephemeral=True)
    with db.conn() as c:
        row = c.execute("SELECT * FROM tickets WHERE channel_id=? AND status='open'", (i.channel.id,)).fetchone()
        if not row:
            return await i.response.send_message("❌ This is not an open ticket.", ephemeral=True)
    await i.response.defer(ephemeral=True)
    # A durable transcript must exist before deleting the channel.
    transcript_dir=Path(db.DATA)/'transcripts'
    transcript_dir.mkdir(parents=True,exist_ok=True)
    transcript_path=transcript_dir/f'{i.guild.id}-{i.channel.id}.txt'
    try:
        with transcript_path.open('w',encoding='utf-8') as output:
            output.write(f'Ticket: {i.channel.name} ({i.channel.id})\nGuild: {i.guild.id}\n')
            async for m in i.channel.history(limit=None, oldest_first=True):
                output.write(f'[{m.created_at.isoformat()}] {m.author} ({m.author.id}): {m.content}\n')
                for attachment in m.attachments:
                    output.write(f'Attachment: {attachment.filename} {attachment.url}\n')
                for embed in m.embeds:
                    output.write(f'Embed: {embed.to_dict()}\n')
    except Exception:
        await i.followup.send('Could not save the transcript. The ticket remains open. Check Read Message History and disk access.',ephemeral=True)
        return
    log_id = int(db.get_setting(i.guild.id, "ticket_log_channel_id", 0) or 0)
    log_ch = i.guild.get_channel(log_id) if log_id else None
    if isinstance(log_ch, discord.TextChannel):
        try:
            f=discord.File(str(transcript_path), filename=f"{i.channel.name}-transcript.txt")
            pay = ticket_pay_rate(i.guild.id, row["kind"])
            claimed = f"<@{row['claimed_by']}>" if row["claimed_by"] else "Unclaimed"
            await log_ch.send(embed=emb("🔒 Ticket Closed", f"Channel: **{i.channel.name}**\nClosed by: {i.user.mention}\nClaimed by: {claimed}\nType: **{row['kind']}**\nConfigured pay: **${money_text(pay)}**"), file=f)
        except Exception:
            await i.followup.send('Transcript saved locally, but delivery to the ticket log channel failed. The ticket remains open so you can fix delivery and retry.',ephemeral=True)
            return
    with db.conn() as c:
        changed=c.execute("UPDATE tickets SET status='closing',closed_at=? WHERE channel_id=? AND status='open'", (int(time.time()), i.channel.id)).rowcount
    if not changed:
        await i.followup.send('This ticket is already closing or closed.',ephemeral=True)
        return
    await i.followup.send("🔒 Transcript saved. Closing...", ephemeral=True)
    try:
        await i.channel.delete(reason=f"Ticket closed by {i.user}")
        with db.conn() as c:
            c.execute("UPDATE tickets SET status='closed' WHERE channel_id=?",(i.channel.id,))
    except discord.HTTPException:
        with db.conn() as c:
            c.execute("UPDATE tickets SET status='open',closed_at=NULL WHERE channel_id=?", (i.channel.id,))
        await i.followup.send("❌ Discord wouldn't let me delete this channel. Make sure my role has **Manage Channels** and sits above the ticket category's permissions.", ephemeral=True)

class TicketActions(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Claim", emoji="✋", style=discord.ButtonStyle.primary, custom_id="fent_ticket_action:claim")
    async def claim_button(self, i: discord.Interaction, button: discord.ui.Button):
        await claim_ticket_interaction(i)

    @discord.ui.button(label="Log Ticket", emoji="💰", style=discord.ButtonStyle.success, custom_id="fent_ticket_action:log")
    async def log_button(self, i: discord.Interaction, button: discord.ui.Button):
        await log_ticket_pay_interaction(i)

    @discord.ui.button(label="Close", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="fent_ticket_action:close")
    async def close_button(self, i: discord.Interaction, button: discord.ui.Button):
        await close_ticket_interaction(i)

async def create_ticket(i: discord.Interaction, kind: str):
    g = i.guild
    types = ticket_types(g.id)
    type_cfg = next((x for x in types if x.get("value") == kind), {})
    cat_id = int(type_cfg.get("category_id") or db.get_setting(g.id, "ticket_category_id", 0) or 0)
    cat = g.get_channel(cat_id) if cat_id else None
    if not isinstance(cat, discord.CategoryChannel):
        cat = discord.utils.get(g.categories, name="🎫 SUPPORT")
        if not cat:
            cat = await g.create_category("🎫 SUPPORT", reason="Fent ticket system")
        db.set_setting(g.id, "ticket_category_id", cat.id)

    staff = staff_role(g)
    overwrites = {
        g.default_role: discord.PermissionOverwrite(view_channel=False),
        i.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, attach_files=True),
        g.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_channels=True, manage_messages=True),
    }
    if staff:
        overwrites[staff] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, attach_files=True)
    for rid in close_role_ids(g.id):
        role = g.get_role(rid)
        if role:
            overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, attach_files=True)

    safe = re.sub(r"[^a-z0-9-]", "", i.user.name.lower().replace(" ", "-"))[:35] or str(i.user.id)
    label = next((x.get("label") for x in types if x.get("value") == kind), kind.replace("-", " ").title())
    ch = await g.create_text_channel(f"{kind}-{safe}"[:95], category=cat, overwrites=overwrites, reason="Fent ticket")
    with db.conn() as c:
        c.execute(
            "INSERT OR REPLACE INTO tickets(channel_id,guild_id,opener_id,kind,status,opened_at) VALUES(?,?,?,?,?,?)",
            (ch.id, g.id, i.user.id, kind, "open", int(time.time()))
        )

    mention = i.user.mention + (f" {staff.mention}" if staff else "")
    e = emb(f"🎫 {label}", "A staff member will be with you shortly.")
    e.add_field(name="Opened By", value=i.user.mention, inline=True)
    e.add_field(name="Type", value=label, inline=True)
    await ch.send(mention, embed=e, view=TicketActions())
    return ch

class TicketSelect(discord.ui.Select):
    def __init__(self, guild_id):
        options = []
        for x in ticket_types(guild_id)[:25]:
            options.append(discord.SelectOption(
                label=str(x.get("label") or "Ticket")[:100],
                value=str(x.get("value") or "support")[:100],
                description=str(x.get("description") or "Open a ticket")[:100],
                emoji=x.get("emoji") or None
            ))
        super().__init__(
            placeholder="Select a ticket type",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"fent_ticket_select:{guild_id}"
        )
    async def callback(self, i: discord.Interaction):
        # prevent duplicates if desired
        if db.get_setting(i.guild.id, "ticket_one_per_user", True):
            with db.conn() as c:
                r = c.execute(
                    "SELECT channel_id FROM tickets WHERE guild_id=? AND opener_id=? AND status='open' LIMIT 1",
                    (i.guild.id, i.user.id)
                ).fetchone()
            if r:
                existing = i.guild.get_channel(int(r["channel_id"]))
                if existing:
                    return await i.response.send_message(f"❌ You already have an open ticket: {existing.mention}", ephemeral=True)
        ch = await create_ticket(i, self.values[0])
        await i.response.send_message(f"✅ Created {ch.mention}", ephemeral=True)

class TicketPanel(discord.ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=None)
        # No dropdown until at least one custom option exists (Discord requires 1+ options).
        if ticket_types(guild_id):
            self.add_item(TicketSelect(guild_id))

class OptionsPreview(discord.ui.Select):
    """Disabled dropdown in the editor that shows the panel's current options."""
    def __init__(self, guild_id):
        types = ticket_types(guild_id)
        if types:
            options = [discord.SelectOption(label=str(x.get("label") or "Ticket")[:100], value=str(n),
                       description=str(x.get("description") or "Open a ticket")[:100], emoji=x.get("emoji") or None)
                       for n, x in enumerate(types[:25])]
            placeholder = "Select a ticket type"
        else:
            options = [discord.SelectOption(label="No options yet", value="none")]
            placeholder = "No options yet — use /add ticket-option"
        super().__init__(placeholder=placeholder, options=options, disabled=True, row=3)

class TextModal(discord.ui.Modal):
    def __init__(self, view, key, label, style=discord.TextStyle.short, max_length=1000, placeholder="", required=False):
        super().__init__(title=f"Set {label}", timeout=600)
        self.view_ref = view
        self.key = key
        current = str(view.cfg.get(key) or "")
        self.field = discord.ui.TextInput(
            label=label, style=style, max_length=max_length, placeholder=placeholder,
            required=required, default=current[:max_length] if current else None
        )
        self.add_item(self.field)
    async def on_submit(self, i):
        await i.response.defer()
        candidate = self.view_ref.cfg.copy()
        try:
            value = str(self.field.value).strip()
            if self.key in MEDIA_KEYS:
                value = clean_url(value)
                candidate.pop(self.key + "_file", None)
                if value:
                    candidate[self.key + "_file"] = store_image(self.view_ref.guild_id, await download_image(value))
                    value = ""
            if self.key == "color": color_int(value)
            candidate[self.key] = value
            embed = build_panel_embed(self.view_ref.guild_id, candidate)
            await i.edit_original_response(embed=embed, attachments=media_files(self.view_ref.guild_id, candidate), view=self.view_ref)
            self.view_ref.cfg = candidate
        except (ValueError, OSError, discord.HTTPException) as error:
            await editor_error(i, error)

    async def on_error(self, i, error):
        await editor_error(i, error)


class AuthorModal(discord.ui.Modal):
    def __init__(self, view):
        super().__init__(title="Set Author", timeout=600)
        self.view_ref = view
        self.name = discord.ui.TextInput(label="Author Name", max_length=256, required=False, default=view.cfg.get("author_name") or None)
        self.icon = discord.ui.TextInput(label="Author Icon URL", max_length=4000, required=False, default=view.cfg.get("author_icon") or None, placeholder="https://...")
        self.add_item(self.name); self.add_item(self.icon)
    async def on_submit(self, i):
        candidate = self.view_ref.cfg.copy()
        try:
            candidate["author_name"] = str(self.name.value).strip()
            candidate["author_icon"] = clean_url(self.icon.value)
            if candidate["author_icon"]:
                candidate.pop("author_icon_file", None)
            await i.response.edit_message(embed=build_panel_embed(self.view_ref.guild_id, candidate), attachments=media_files(self.view_ref.guild_id, candidate), view=self.view_ref)
            self.view_ref.cfg = candidate
        except (ValueError, discord.HTTPException) as error:
            await editor_error(i, error)


class TicketEditor(discord.ui.View):
    def __init__(self, guild_id, target_channel_id):
        super().__init__(timeout=900)
        self.guild_id = guild_id
        self.target_channel_id = target_channel_id
        self.cfg = panel_config(guild_id)
        try: self.add_item(OptionsPreview(guild_id))
        except Exception: pass

    def preview(self):
        return build_panel_embed(self.guild_id, self.cfg)

    async def on_error(self, interaction, error, item):
        await editor_error(interaction, error)

    @discord.ui.button(label="Author", style=discord.ButtonStyle.primary, row=0)
    async def author(self, i, b): await i.response.send_modal(AuthorModal(self))
    @discord.ui.button(label="Title", style=discord.ButtonStyle.primary, row=0)
    async def title(self, i, b): await i.response.send_modal(TextModal(self,"title","Title",max_length=256))
    @discord.ui.button(label="Description", style=discord.ButtonStyle.primary, row=0)
    async def description(self, i, b): await i.response.send_modal(TextModal(self,"description","Description",style=discord.TextStyle.paragraph,max_length=4000,required=True))
    @discord.ui.button(label="Color", style=discord.ButtonStyle.primary, row=0)
    async def color(self, i, b): await i.response.send_modal(TextModal(self,"color","HEX Color",max_length=7,placeholder="#5865F2"))
    @discord.ui.button(label="Banner / Image", style=discord.ButtonStyle.primary, row=1)
    async def image(self, i, b): await i.response.send_modal(TextModal(self,"image","Banner / Image URL",max_length=4000,placeholder="https://..."))
    @discord.ui.button(label="Thumbnail", style=discord.ButtonStyle.primary, row=1)
    async def thumbnail(self, i, b): await i.response.send_modal(TextModal(self,"thumbnail","Thumbnail URL",max_length=4000,placeholder="https://..."))
    @discord.ui.button(label="Footer", style=discord.ButtonStyle.primary, row=1)
    async def footer(self, i, b): await i.response.send_modal(TextModal(self,"footer","Footer",max_length=2048))
    @discord.ui.button(label="Save + Post", style=discord.ButtonStyle.success, row=2)
    async def done(self, i, b):
        await i.response.defer()
        try:
            self.cfg = await cache_media(self.guild_id, self.cfg)
            embed = self.preview()
            ch = i.guild.get_channel(int(self.target_channel_id))
            if not isinstance(ch, discord.TextChannel):
                raise ValueError("Target channel no longer exists.")
            permissions = ch.permissions_for(i.guild.me)
            if not all((permissions.view_channel, permissions.send_messages, permissions.embed_links)):
                raise ValueError("Enable View Channel, Send Messages, and Embed Links for me in the destination channel.")
            if any(self.cfg.get(key + "_file") for key in MEDIA_KEYS) and not permissions.attach_files:
                raise ValueError("Enable Attach Files for me in the destination channel.")
            mid = int(db.get_setting(self.guild_id, "ticket_panel_message_id", 0) or 0)
            old_ch = int(db.get_setting(self.guild_id, "ticket_panel_channel_id", 0) or 0)
            msg = None
            if mid and old_ch == ch.id:
                try: msg = await ch.fetch_message(mid)
                except discord.NotFound: pass
            if msg:
                await msg.edit(embed=embed, attachments=media_files(self.guild_id, self.cfg), view=TicketPanel(self.guild_id))
            else:
                msg = await ch.send(embed=embed, files=media_files(self.guild_id, self.cfg), view=TicketPanel(self.guild_id))
            db.set_setting(self.guild_id, "ticket_panel_config", self.cfg)
            db.set_setting(self.guild_id, "ticket_panel_message_id", msg.id)
            db.set_setting(self.guild_id, "ticket_panel_channel_id", ch.id)
            for item in self.children: item.disabled = True
            note = "" if ticket_types(self.guild_id) else "\nNo ticket options yet — add them with `/add ticket-option` and the dropdown will appear on the panel."
            await i.edit_original_response(content=f"✅ Saved and posted in {ch.mention}.{note}", embed=embed, attachments=media_files(self.guild_id, self.cfg), view=self)
        except (ValueError, OSError, discord.HTTPException) as error:
            await editor_error(i, error)


class TicketGroup(app_commands.Group):
    def __init__(self, bot):
        super().__init__(name="ticket", description="Ticket system")
        self.bot = bot

    @app_commands.command(name="config", description="Set ticket category and staff role")
    @admin_check()
    async def config(self, i: discord.Interaction, category: discord.CategoryChannel, staff_role_value: discord.Role):
        db.set_setting(i.guild.id, "ticket_category_id", category.id)
        db.set_setting(i.guild.id, "staff_role_id", staff_role_value.id)
        await i.response.send_message(f"✅ Tickets: **{category.name}** • Staff: {staff_role_value.mention}", ephemeral=True)

    @app_commands.command(name="panel-edit", description="Open the visual ticket panel editor")
    @admin_check()
    async def panel_edit(self, i: discord.Interaction, channel: discord.TextChannel=None):
        await i.response.defer(ephemeral=True)
        channel = channel or i.channel
        view = TicketEditor(i.guild.id, channel.id)
        try:
            view.cfg = await cache_media(i.guild.id, view.cfg)
            await i.followup.send(
                "Ticket media editor v2.1 — paste an image link in Banner / Image or Thumbnail. "
                "The bot downloads it and attaches it to the embed. **Save + Post** publishes the panel.\n"
                + options_summary(i.guild.id),
                embed=view.preview(), files=media_files(i.guild.id, view.cfg), view=view, ephemeral=True
            )
        except (ValueError, OSError, discord.HTTPException) as error:
            # An expired saved URL must not lock the user out of the editor.
            for key in MEDIA_KEYS:
                if not view.cfg.get(key + "_file"): view.cfg[key] = ""
            await i.followup.send(
                f"One saved image could not load: {str(error)[:500]}\nReplace it below, then Save + Post. (Editor v2.1)",
                embed=view.preview(), files=media_files(i.guild.id, view.cfg), view=view, ephemeral=True
            )

    @app_commands.command(name="post", description="Post the saved ticket panel")
    @admin_check()
    async def post(self, i: discord.Interaction, channel: discord.TextChannel=None):
        channel = channel or i.channel
        await i.response.defer(ephemeral=True)
        cfg = await cache_media(i.guild.id, panel_config(i.guild.id))
        msg = await channel.send(embed=build_panel_embed(i.guild.id, cfg), files=media_files(i.guild.id, cfg), view=TicketPanel(i.guild.id))
        db.set_setting(i.guild.id, "ticket_panel_config", cfg)
        db.set_setting(i.guild.id, "ticket_panel_message_id", msg.id)
        db.set_setting(i.guild.id, "ticket_panel_channel_id", channel.id)
        await i.followup.send(f"✅ Ticket panel posted in {channel.mention}.", ephemeral=True)

    @app_commands.command(name="media", description="Upload a ticket banner, thumbnail, or author icon directly")
    @admin_check()
    @app_commands.choices(slot=[app_commands.Choice(name="Banner / Image", value="image"), app_commands.Choice(name="Thumbnail", value="thumbnail"), app_commands.Choice(name="Author Icon", value="author_icon")])
    async def media(self, i: discord.Interaction, slot: app_commands.Choice[str], image: discord.Attachment):
        await i.response.defer(ephemeral=True)
        try:
            if image.size > 2 * 1024 * 1024:
                raise ValueError("Use an image smaller than 2 MB.")
            data = await image.read()
            ext = image_extension(data)
            folder = db.DATA / "ticket_media" / str(i.guild.id)
            folder.mkdir(parents=True, exist_ok=True)
            filename = uuid.uuid4().hex + "." + ext
            (folder / filename).write_bytes(data)
            cfg = panel_config(i.guild.id)
            cfg[slot.value] = ""
            cfg[slot.value + "_file"] = filename
            if slot.value == "author_icon" and not cfg.get("author_name"):
                cfg["author_name"] = "Support"
            await i.followup.send("✅ Image saved. Reopen /ticket panel-edit and press Save + Post to update your panel, or use /ticket post. Close any older editor first.", embed=build_panel_embed(i.guild.id, cfg), files=media_files(i.guild.id, cfg), ephemeral=True)
            db.set_setting(i.guild.id, "ticket_panel_config", cfg)
        except (ValueError, OSError, discord.HTTPException) as error:
            await editor_error(i, error)

    @app_commands.command(name="type-add", description="Add or update a ticket type")
    @admin_check()
    async def type_add(self, i: discord.Interaction, label: str, value: str, description: str="Open a ticket", emoji: str="🎫", category: discord.CategoryChannel=None):
        value = re.sub(r"[^a-z0-9-]", "-", value.lower().strip()).strip("-")[:50]
        if not value:
            return await i.response.send_message("❌ Invalid value.", ephemeral=True)
        types = ticket_types(i.guild.id)
        item = {"label":label[:100],"value":value,"description":description[:100],"emoji":emoji[:50] if emoji else "","category_id":category.id if category else None}
        found = False
        for n,x in enumerate(types):
            if x.get("value") == value:
                types[n] = item; found = True; break
        if not found:
            if len(types) >= 25:
                return await i.response.send_message("❌ Discord allows 25 dropdown options max.", ephemeral=True)
            types.append(item)
        db.set_setting(i.guild.id, "ticket_types", types)
        await i.response.send_message(f"✅ {'Updated' if found else 'Added'} **{label}**. Repost the panel to refresh it.", ephemeral=True)

    @app_commands.command(name="type-remove", description="Remove a ticket type")
    @admin_check()
    async def type_remove(self, i: discord.Interaction, value: str):
        types = ticket_types(i.guild.id)
        new = [x for x in types if str(x.get("value")).lower() != value.lower()]
        if len(new) == len(types):
            return await i.response.send_message("❌ Ticket type not found.", ephemeral=True)
        db.set_setting(i.guild.id, "ticket_types", new)
        await refresh_panel(i.guild)
        await i.response.send_message("✅ Removed.", ephemeral=True)

    @app_commands.command(name="types", description="Show ticket types")
    async def types(self, i: discord.Interaction):
        if not ticket_types(i.guild.id):
            return await i.response.send_message("No ticket options yet. Add them with `/add ticket-option`.", ephemeral=True)
        lines = [f"{x.get('emoji','')} **{x.get('label')}** — `{x.get('value')}`\n{x.get('description','')}" for x in ticket_types(i.guild.id)]
        await i.response.send_message(embed=emb("🎫 Ticket Types", "\n\n".join(lines)), ephemeral=True)

    @app_commands.command(name="open", description="Open a ticket")
    async def open(self, i: discord.Interaction, kind: str):
        if not any(x.get("value") == kind for x in ticket_types(i.guild.id)):
            return await i.response.send_message("❌ Unknown ticket option. Use `/ticket types` to see them.", ephemeral=True)
        ch = await create_ticket(i, kind)
        await i.response.send_message(f"✅ Created {ch.mention}", ephemeral=True)

    @app_commands.command(name="claim", description="Staff: claim this ticket")
    @staff_check()
    async def claim(self, i: discord.Interaction):
        await claim_ticket_interaction(i)

    @app_commands.command(name="add", description="Staff: add someone to this ticket")
    @staff_check()
    async def add(self, i: discord.Interaction, user: discord.Member):
        await i.channel.set_permissions(user, view_channel=True, send_messages=True, read_message_history=True)
        await i.response.send_message(f"✅ Added {user.mention}.", ephemeral=True)

    @app_commands.command(name="remove", description="Staff: remove someone from this ticket")
    @staff_check()
    async def remove(self, i: discord.Interaction, user: discord.Member):
        await i.channel.set_permissions(user, overwrite=None)
        await i.response.send_message(f"✅ Removed {user.mention}.", ephemeral=True)

    @app_commands.command(name="transcript", description="Staff: export ticket transcript")
    @staff_check()
    async def transcript(self, i: discord.Interaction):
        await i.response.defer(ephemeral=True)
        lines = []
        async for m in i.channel.history(limit=None, oldest_first=True):
            lines.append(f"[{m.created_at.isoformat()}] {m.author}: {m.content}")
        f = discord.File(io.BytesIO("\n".join(lines).encode("utf-8")), filename=f"{i.channel.name}-transcript.txt")
        await i.followup.send(f"✅ Transcript: **{len(lines)} messages**", file=f, ephemeral=True)

    @app_commands.command(name="close", description="Close this ticket (admins and allowed roles)")
    async def close(self, i: discord.Interaction):
        await close_ticket_interaction(i)

    @app_commands.command(name="close-role-add", description="Let a role close tickets (and see new tickets)")
    @admin_check()
    async def close_role_add(self, i: discord.Interaction, role: discord.Role):
        ids = close_role_ids(i.guild.id)
        if role.id not in ids:
            ids.append(role.id)
            db.set_setting(i.guild.id, "ticket_close_role_ids", ids)
        added = 0
        with db.conn() as c:
            rows = c.execute("SELECT channel_id FROM tickets WHERE guild_id=? AND status='open'", (i.guild.id,)).fetchall()
        await i.response.defer(ephemeral=True)
        for r in rows:
            ch = i.guild.get_channel(int(r["channel_id"]))
            if isinstance(ch, discord.TextChannel):
                try:
                    await ch.set_permissions(role, view_channel=True, send_messages=True, read_message_history=True, attach_files=True)
                    added += 1
                except discord.HTTPException:
                    pass
        await i.followup.send(f"✅ {role.mention} can now close tickets. Added to **{added}** open ticket(s); new tickets include it automatically.", ephemeral=True)

    @app_commands.command(name="close-role-remove", description="Stop a role from closing tickets")
    @admin_check()
    async def close_role_remove(self, i: discord.Interaction, role: discord.Role):
        ids = close_role_ids(i.guild.id)
        if role.id not in ids:
            return await i.response.send_message(f"❌ {role.mention} isn't on the close list.", ephemeral=True)
        db.set_setting(i.guild.id, "ticket_close_role_ids", [x for x in ids if x != role.id])
        await i.response.send_message(f"✅ {role.mention} can no longer close tickets.", ephemeral=True)

    @app_commands.command(name="close-roles", description="Show which roles can close tickets")
    @admin_check()
    async def close_roles(self, i: discord.Interaction):
        ids = close_role_ids(i.guild.id)
        text = "\n".join(f"<@&{x}>" for x in ids) or "None — only members with Administrator permission can close."
        await i.response.send_message(embed=emb("🔒 Roles that can close tickets", text), ephemeral=True)

    @app_commands.command(name="log-pay", description="Staff: log the claimed ticket for admin pay")
    @staff_check()
    async def log_pay(self, i: discord.Interaction):
        await log_ticket_pay_interaction(i)

    @app_commands.command(name="pay-set", description="Set admin pay for a ticket type")
    @admin_check()
    async def pay_set(self, i: discord.Interaction, ticket_type: str, amount: app_commands.Range[float, 0, 1000000]):
        kinds = {str(x.get("value")) for x in ticket_types(i.guild.id)}
        if ticket_type not in kinds:
            return await i.response.send_message("❌ Unknown ticket type. Use `/ticket types` to see the values.", ephemeral=True)
        rates = db.get_setting(i.guild.id, "ticket_pay_rates", {}) or {}
        rates[ticket_type] = float(amount)
        db.set_setting(i.guild.id, "ticket_pay_rates", rates)
        await i.response.send_message(f"✅ **{ticket_type}** admin pay set to **${money_text(amount)}** per logged ticket.", ephemeral=True)

    @app_commands.command(name="pay-rates", description="Show configured admin pay per ticket type")
    @admin_check()
    async def pay_rates(self, i: discord.Interaction):
        lines=[]
        for x in ticket_types(i.guild.id):
            lines.append(f"{x.get('emoji','')} **{x.get('label','Ticket')}** (`{x.get('value')}`): **${money_text(ticket_pay_rate(i.guild.id, x.get('value')))}**")
        await i.response.send_message(embed=emb("💰 Ticket Admin Pay", "\n".join(lines)), ephemeral=True)

    @app_commands.command(name="pay-stats", description="Show logged ticket pay for a staff member")
    @admin_check()
    async def pay_stats(self, i: discord.Interaction, member: discord.Member=None):
        member = member or i.user
        with db.conn() as c:
            rows = c.execute("SELECT kind, COUNT(*) AS n, SUM(amount) AS total FROM ticket_pay_logs WHERE guild_id=? AND staff_id=? GROUP BY kind ORDER BY kind", (i.guild.id, member.id)).fetchall()
        if not rows:
            return await i.response.send_message(f"No paid ticket logs for {member.mention} yet.", ephemeral=True)
        total=sum(float(r['total'] or 0) for r in rows)
        count=sum(int(r['n'] or 0) for r in rows)
        lines=[f"**{r['kind']}**: {r['n']} tickets • ${money_text(r['total'])}" for r in rows]
        lines.append(f"\n**Total:** {count} tickets • **${money_text(total)}**")
        await i.response.send_message(embed=emb(f"💰 Pay Stats — {member.display_name}", "\n".join(lines)), ephemeral=True)

    @app_commands.command(name="settings", description="Ticket settings")
    @admin_check()
    async def settings(self, i: discord.Interaction, log_channel: discord.TextChannel=None, one_ticket_per_user: bool=True):
        if log_channel:
            db.set_setting(i.guild.id, "ticket_log_channel_id", log_channel.id)
        db.set_setting(i.guild.id, "ticket_one_per_user", bool(one_ticket_per_user))
        await i.response.send_message("✅ Ticket settings updated.", ephemeral=True)

class AddGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="add", description="Add panel options (ticket options, information)", guild_only=True)

    @app_commands.command(name="ticket-option", description="Add an option to the ticket dropdown and refresh its panel")
    @admin_check()
    @app_commands.describe(emoji="Emoji shown beside the option", name="Option name, such as Design or Refund", category="Discord category where these tickets will be created", description="Small text under the option (optional)")
    async def ticket_option(self, i: discord.Interaction, emoji: app_commands.Range[str, 1, 100], name: app_commands.Range[str, 1, 100], category: discord.CategoryChannel, description: app_commands.Range[str, 1, 100]=None):
        name = name.strip()
        emoji = emoji.strip()
        if not name or not emoji:
            return await i.response.send_message("Enter an option name and an emoji.", ephemeral=True)
        types = ticket_types(i.guild.id)
        if any(str(item.get("label", "")).casefold() == name.casefold() for item in types):
            return await i.response.send_message("An option with that name already exists. Choose another name.", ephemeral=True)
        if len(types) >= 25:
            return await i.response.send_message("The panel already has 25 options. Remove one with /ticket type-remove first.", ephemeral=True)
        parsed = discord.PartialEmoji.from_str(emoji)
        if not parsed.id and not any(ord(char) >= 0x2000 or char in "0123456789#*" and "\u20e3" in emoji for char in emoji):
            return await i.response.send_message("Use an emoji such as 🎨, or a custom emoji like <:name:123456789012345678>.", ephemeral=True)
        value = re.sub(r"[^a-z0-9-]", "-", name.lower()).strip("-")[:40] or "option"
        if any(item.get("value") == value for item in types):
            value += "-" + uuid.uuid4().hex[:8]
        types.append(dict(label=name, value=value, description=(description or "").strip()[:100] or "Open a " + name[:85] + " ticket", emoji=str(parsed), category_id=category.id))
        # Save before constructing the dropdown so its callback sees the new option.
        db.set_setting(i.guild.id, "ticket_types", types)
        await i.response.defer(ephemeral=True)
        cid = int(db.get_setting(i.guild.id, "ticket_panel_channel_id", 0) or 0)
        mid = int(db.get_setting(i.guild.id, "ticket_panel_message_id", 0) or 0)
        channel = i.guild.get_channel(cid)
        if not channel or not mid:
            return await i.followup.send(f"✅ Added **{name}**. Tickets will open in **{category.name}**. Use /ticket post to publish your panel.", ephemeral=True)
        try:
            message = await channel.fetch_message(mid)
            # Change only the dropdown: preserve all existing embed media.
            await message.edit(view=TicketPanel(i.guild.id))
        except discord.HTTPException:
            return await i.followup.send(f"✅ Saved **{name}**, but I could not refresh the panel. Check my channel permissions, then use /ticket post.", ephemeral=True)
        await i.followup.send(f"✅ Added {emoji} **{name}** to the ticket panel. Tickets will open in **{category.name}**.", ephemeral=True)


async def refresh_panel(guild):
    """Re-render the dropdown on the posted panel (adds/removes it as options change). Returns True on success."""
    cid = int(db.get_setting(guild.id, "ticket_panel_channel_id", 0) or 0)
    mid = int(db.get_setting(guild.id, "ticket_panel_message_id", 0) or 0)
    channel = guild.get_channel(cid)
    if not channel or not mid:
        return False
    try:
        message = await channel.fetch_message(mid)
        await message.edit(view=TicketPanel(guild.id))
        return True
    except discord.HTTPException:
        return False

async def option_autocomplete(i: discord.Interaction, current: str):
    return [app_commands.Choice(name=f"{x.get('label')}"[:100], value=str(x.get("value")))
            for x in ticket_types(i.guild.id) if current.lower() in str(x.get("label", "")).lower()][:25]

class RemoveGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="remove", description="Remove panel options (ticket options, information)", guild_only=True)

    @app_commands.command(name="ticket-option", description="Remove an option from the ticket dropdown and refresh its panel")
    @admin_check()
    @app_commands.describe(option="The ticket option to remove")
    @app_commands.autocomplete(option=option_autocomplete)
    async def ticket_option(self, i: discord.Interaction, option: str):
        types = ticket_types(i.guild.id)
        gone = [x for x in types if str(x.get("value")) == option or str(x.get("label", "")).casefold() == option.casefold()]
        if not gone:
            return await i.response.send_message("❌ That ticket option doesn't exist.", ephemeral=True)
        db.set_setting(i.guild.id, "ticket_types", [x for x in types if x not in gone])
        await i.response.defer(ephemeral=True)
        await refresh_panel(i.guild)
        await i.followup.send(f"✅ Removed **{gone[0].get('label')}** from the ticket panel.", ephemeral=True)

class TicketCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.group = TicketGroup(bot)
        bot.tree.add_command(self.group)
        self.add_group = AddGroup()
        bot.tree.add_command(self.add_group)
        self.remove_group = RemoveGroup()
        bot.tree.add_command(self.remove_group)
        # Other features (e.g. /add information from embeds.py) plug into these groups.
        extras = getattr(bot, "extra_group_commands", {}) or {}
        for name, group in (("add", self.add_group), ("remove", self.remove_group)):
            for cmd in extras.get(name, {}).values():
                if group.get_command(cmd.name) is None:
                    group.add_command(cmd)
        self.views=[]

    def restore_views(self):
        for view in list(self.bot.persistent_views):
            if type(view).__module__==__name__: view.stop()
        for view in self.views: view.stop()
        self.views=[]
        view=TicketActions()
        self.bot.add_view(view)
        self.views.append(view)
        for guild in self.bot.guilds:
            mid=int(db.get_setting(guild.id,'ticket_panel_message_id',0) or 0)
            if mid:
                view=TicketPanel(guild.id)
                if view.children:
                    self.bot.add_view(view,message_id=mid)
                    self.views.append(view)

    async def cog_load(self):
        self.restore_views()

    async def cog_unload(self):
        for view in self.views: view.stop()
        self.bot.tree.remove_command("add", type=discord.AppCommandType.chat_input)
        self.bot.tree.remove_command("remove", type=discord.AppCommandType.chat_input)
        try: self.bot.tree.remove_command("ticket", type=discord.AppCommandType.chat_input)
        except Exception: pass

async def setup(bot):
    await bot.add_cog(TicketCog(bot))

"""Discover ASE services visible to a lifetime token, including UWP/Xbox."""
from nitrado_api import NitradoError


def ase_game(game):
    name=str(game or '').casefold().replace(' ','')
    return (name=='ark' or name.startswith(('arkse','arkxb','arkps','arkuwp','arkwin','ark:survivalevolved'))) and not any(part in name for part in ('ascended','arksa','mobile'))


async def discover_services(api,token):
    candidates={}
    notes=[]
    successful=0
    for endpoint in ('/services','/uwp/services/list'):
        try:
            body=await api.request('GET',endpoint,token_override=token)
            rows=body.get('services')
            if not isinstance(rows,list): raise NitradoError('Unexpected service-list response.')
            successful+=1
            for row in rows:
                if not isinstance(row,dict) or row.get('type')!='gameserver': continue
                sid=str(row.get('id',''))
                if sid.isascii() and sid.isdecimal() and int(sid)>0: candidates[str(int(sid))]=row
        except NitradoError:
            notes.append(f'{endpoint}: unavailable for this token; discovery may be incomplete.')
    if not successful: raise NitradoError('Could not list services. Check that your lifetime token has service-list access. Nothing was saved.')
    if len(candidates)>100: raise NitradoError('Too many services to inspect in one setup. Use /nitrado service-add to select IDs instead.')
    services={}
    for sid in candidates:
        try:
            data=await api.request('GET',f'/services/{sid}/gameservers',token_override=token)
            details=data.get('gameserver')
            if isinstance(details,dict) and ase_game(details.get('game')):
                services[sid]=details
        except NitradoError:
            notes.append(f'Service {sid}: details unavailable; skipped.')
        if len(services)>25: raise NitradoError('More than 25 ASE servers found. Use /nitrado service-add to select up to 25 IDs.')
    if not services:
        raise NitradoError('No accessible ARK: Survival Evolved servers were found for this token. Check the token account and permissions. Nothing was saved.')
    return services,notes


def log_candidates(details):
    files=details.get('game_specific',{}).get('log_files',[])
    if isinstance(files,dict): files=list(files.values())
    result=[]
    for entry in files if isinstance(files,list) else []:
        path=entry if isinstance(entry,str) else entry.get('path') if isinstance(entry,dict) else None
        if path and path.lower().endswith('.log') and path not in result: result.append(path)
    return result

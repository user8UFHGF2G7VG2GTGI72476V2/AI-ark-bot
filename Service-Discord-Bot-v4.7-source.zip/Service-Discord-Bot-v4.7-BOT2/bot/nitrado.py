"""Nitrado integration, with capabilities checked against each configured service."""
import asyncio
import io
import json
import os
import time
from urllib.parse import quote, urlparse
import aiohttp
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import emb
from nitrado_config import parse_service_ids, save_config

from nitrado_api import Client, NitradoError, service_ids, resolve_name
from nitrado_discovery import discover_services, log_candidates
import ark_services

TOKEN_PAGE=os.getenv('NITRADO_TOKEN_URL','https://server.nitrado.net/en-US/developer/tokens')


class SetupModal(discord.ui.Modal,title='Nitrado setup'):
    token=discord.ui.TextInput(label='Lifetime token (blank keeps saved token)',required=False,max_length=2000)

    def __init__(self,group,user_id,guild_id):
        super().__init__(timeout=300)
        self.group=group
        self.user_id=user_id
        self.guild_id=guild_id

    async def interaction_check(self,i):
        if i.user.id!=self.user_id or i.guild_id!=self.guild_id or not i.user.guild_permissions.administrator:
            await i.response.send_message('Only the administrator who opened this form can submit it.',ephemeral=True)
            return False
        return True

    async def on_submit(self,i):
        await self.group.configure(i,'',str(self.token.value).strip() or None)

    async def on_error(self,i,error):
        message=str(error) if isinstance(error,(NitradoError,ValueError)) else 'Setup failed. The token is not displayed. Check host file permissions and try again.'
        if i.response.is_done(): await i.followup.send(message,ephemeral=True)
        else: await i.response.send_message(message,ephemeral=True)


class NitradoGroup(app_commands.Group):
    def __init__(self,cog):
        super().__init__(name='nitrado',description='ARK Nitrado server management',guild_only=True,default_permissions=discord.Permissions(administrator=True))
        self.cog=cog
        self.api=cog.api

    async def interaction_check(self,i):
        if not i.guild or not i.user.guild_permissions.administrator:
            raise NitradoError('Discord Administrator permission is required for Nitrado management.')
        return True

    async def sid(self,i,service):
        return await self.api.service(i.guild_id,service)

    async def configure(self,i,raw_ids='',new_token=None):
        automatic=not raw_ids.strip()
        if not automatic:
            try: additions=parse_service_ids(raw_ids)
            except ValueError as exc: raise NitradoError(str(exc)) from None
        await i.response.defer(ephemeral=True)
        async with self.cog.config_lock:
            token=new_token if new_token is not None else os.getenv('NITRADO_TOKEN','').strip()
            if not token: raise NitradoError('Run /nitrado setup and enter a Nitrado lifetime token.')
            if any(char.isspace() for char in token): raise NitradoError('The token must not contain spaces or new lines.')
            notes=[]
            discovered={}
            if automatic:
                discovered,notes=await discover_services(self.api,token)
                ids=list(discovered)
            else:
                ids=list(dict.fromkeys(service_ids()+additions))
                if len(ids)>25: raise NitradoError('A maximum of 25 service IDs is supported per installation.')
                for sid in ids:
                    details=await self.api.request('GET',f'/services/{sid}/gameservers',token_override=token)
                    if not details.get('gameserver'): raise NitradoError(f'Service {sid} did not return gameserver details; nothing was saved.')
            try: save_config(token,ids)
            except OSError: raise NitradoError('Could not write .env on the bot host. Configuration was not changed.') from None
            current=str(db.get_setting(i.guild_id,'nitrado_service',''))
            if current not in ids: db.set_setting(i.guild_id,'nitrado_service',ids[0] if automatic else additions[0])
            for sid,details in discovered.items():
                paths=log_candidates(details)
                db.set_setting(i.guild_id,f'ark_discovered_logs:{sid}',paths)
                ark_services.remember(sid,details)
        message=f"Verified and saved {len(ids)} service ID(s) to .env: {', '.join(ids)}. Changes are active now; no restart needed. Token is never echoed."
        if automatic: message+='\nYour ASE servers were discovered automatically. Run /logs-setup staff_role:@Staff to create private log channels. No service IDs are needed; each discovered server is checked.'
        else: message+=' Use /nitrado serverlist to check status.'
        if notes: message+='\n'+'\n'.join(notes)
        await i.followup.send(message[:1900],ephemeral=True)

    @app_commands.command(description='Enter only a lifetime token; discover and save your ASE servers automatically')
    async def setup(self,i:discord.Interaction):
        await i.response.send_modal(SetupModal(self,i.user.id,i.guild_id))

    @app_commands.command(description='Rediscover all accessible ASE servers using the saved lifetime token')
    async def refresh(self,i:discord.Interaction):
        await self.configure(i)

    @app_commands.command(name='service-add',description='Validate and add more service IDs without replacing existing IDs')
    async def service_add(self,i:discord.Interaction,ids:app_commands.Range[str,1,1000]):
        await self.configure(i,ids)

    @app_commands.command(name='service-remove',description='Remove one configured service ID and stop its tracking feeds')
    async def service_remove(self,i:discord.Interaction,service:str):
        await i.response.defer(ephemeral=True)
        async with self.cog.config_lock:
            ids=service_ids()
            if service not in ids: raise NitradoError('That service ID is not configured.')
            ids.remove(service)
            try: save_config(os.getenv('NITRADO_TOKEN',''),ids)
            except OSError: raise NitradoError('Could not write .env. Configuration was not changed.') from None
            with db.conn() as c:
                c.execute('UPDATE ark_feed SET ready=0 WHERE service=?',(service,))
                rows=c.execute("SELECT guild_id,value FROM settings WHERE key='nitrado_service'").fetchall()
            for row in rows:
                if str(json.loads(row['value']))==service:
                    if ids: db.set_setting(row['guild_id'],'nitrado_service',ids[0])
                    else: db.del_setting(row['guild_id'],'nitrado_service')
        await i.followup.send(f"Removed {service}. Its feeds are stopped; recorded statistics are retained. Remaining IDs: {', '.join(ids) or 'none'}.",ephemeral=True)

    @app_commands.command(description='Bind this Discord server to an allowed Nitrado service ID')
    async def bind(self,i:discord.Interaction,service:str):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        await self.api.details(sid)
        db.set_setting(i.guild_id,'nitrado_service',sid)
        await i.followup.send(f'Default service set to {sid}.',ephemeral=True)

    @app_commands.command(description='Validate the lifetime token and show service capabilities')
    async def auth(self,i:discord.Interaction,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        details=await self.api.details(sid)
        try:
            caps=await self.api.request('GET',f'/services/{sid}/gameservers/games/players/lists')
            capability_text=f"Available player lists: {', '.join(caps.get('player_lists',[])) or 'None'}. Player ID type: {caps.get('player_id_type','unknown')}."
        except NitradoError:
            capability_text='Service access works; player-management capabilities could not be retrieved.'
        await i.followup.send(f"Authorized service {sid}. Status: {details.get('status','unknown')}.\n{capability_text}\nToken is read from .env only.",ephemeral=True)

    @app_commands.command(description='Show status for all service IDs configured on this bot')
    async def serverlist(self,i:discord.Interaction):
        await i.response.defer(ephemeral=True)
        lines=[]
        for sid in service_ids():
            try:
                g=await self.api.details(sid)
                q=g.get('query',{})
                lines.append(f"{sid}: {q.get('server_name',g.get('game','ARK'))} — {g.get('status','unknown')} — {q.get('player_current','?')}/{q.get('player_max','?')}")
            except NitradoError as e: lines.append(f'{sid}: {e}')
        await i.followup.send(file=discord.File(io.BytesIO(('\n'.join(lines) or 'No service IDs configured.').encode()),filename='servers.txt'),ephemeral=True)

    @app_commands.command(description='Request a server stop or restart')
    @app_commands.choices(action=[app_commands.Choice(name='Stop',value='stop'),app_commands.Choice(name='Restart / start',value='restart')])
    async def manage(self,i:discord.Interaction,action:app_commands.Choice[str],service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        await self.api.request('POST',f'/services/{sid}/gameservers/{action.value}',payload={'message':f'Discord request by {i.user.id}'})
        await i.followup.send(f'Nitrado accepted the {action.value} request for {sid}. Use /nitrado status to check completion.',ephemeral=True)

    @app_commands.command(description='Show server status and population')
    async def status(self,i:discord.Interaction,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        g=await self.api.details(sid)
        q=g.get('query',{})
        await i.followup.send(embed=emb(f'Service {sid}',f"Status: {g.get('status','unknown')}\nName: {q.get('server_name','Unavailable')}\nPlayers: {q.get('player_current','?')}/{q.get('player_max','?')}\nGame: {g.get('game','Unknown')}"),ephemeral=True)

    @app_commands.command(description='Show online players when the platform exposes them')
    async def players(self,i:discord.Interaction,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        rows=await self.api.players(sid)
        online=[p for p in rows if str(p.get('online','')).casefold() in ('true','1')]
        await self.send_rows(i,online,'online-players')

    async def send_rows(self,i,rows,label):
        text='\n'.join(f"{p.get('name','Unknown')} | {p.get('id','Unknown')}" for p in rows) or 'No entries returned.'
        await i.followup.send(file=discord.File(io.BytesIO(text.encode()),filename=label+'.txt'),ephemeral=True)

    @app_commands.command(name='find-player',description='Find an exact gamertag or ingame name across configured services')
    async def find_player(self,i:discord.Interaction,name:app_commands.Range[str,1,100]):
        await i.response.defer(ephemeral=True)
        found=[]
        for sid in service_ids():
            try:
                rows=await self.api.players(sid)
                matches=[p for p in rows if any(str(p.get(k,'')).casefold()==name.casefold() for k in ('name','gamertag','ingame_name'))]
                found.extend(f"{sid}: {p.get('name')} | {p.get('id')} | online={p.get('online','unknown')}" for p in matches)
            except NitradoError as e: found.append(f'{sid}: {e}')
        await i.followup.send(file=discord.File(io.BytesIO(('\n'.join(found) or 'No matching names returned.').encode()),filename='player-search.txt'),ephemeral=True)

    async def change_list(self,i,kind,name,remove,service):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        current=await self.api.lists(sid,kind)
        # Resolve by name, never guess a platform ID or send a fuzzy match.
        rows=current if remove else await self.api.players(sid)
        player=resolve_name(rows,name)
        await self.api.request('DELETE' if remove else 'POST',f'/services/{sid}/gameservers/games/{kind}',payload={'identifier':[str(player['id'])]})
        await i.followup.send(f"Nitrado confirmed {kind} {'removal' if remove else 'addition'} for {player.get('name',name)} ({player['id']}).",ephemeral=True)

    @app_commands.command(description='Ban a player by exact gamertag or ingame name')
    async def ban(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        await self.change_list(i,'banlist',name,False,service)

    @app_commands.command(description='Unban a player by exact name in the ban list')
    async def unban(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        await self.change_list(i,'banlist',name,True,service)

    @app_commands.command(name='admin-add',description='Add an admin by exact gamertag or ingame name')
    async def admin_add(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        await self.change_list(i,'adminlist',name,False,service)

    @app_commands.command(name='admin-remove',description='Remove an admin by exact name')
    async def admin_remove(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        await self.change_list(i,'adminlist',name,True,service)

    @app_commands.command(name='admin-list',description='Show the service admin list')
    async def admin_list(self,i:discord.Interaction,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        await self.send_rows(i,await self.api.lists(sid,'adminlist'),'admins')

    @app_commands.command(description='Show or change the whitelist using exact player names')
    @app_commands.choices(action=[app_commands.Choice(name=x,value=x) for x in ('list','add','remove')])
    async def whitelist(self,i:discord.Interaction,action:app_commands.Choice[str],name:app_commands.Range[str,1,100]=None,service:str=None):
        if action.value!='list':
            if not name: raise NitradoError('A gamertag or ingame name is required.')
            return await self.change_list(i,'whitelist',name,action.value=='remove',service)
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        await self.send_rows(i,await self.api.lists(sid,'whitelist'),'whitelist')

    @app_commands.command(description='Kick an exact player name if Nitrado advertises the kick action')
    async def kick(self,i:discord.Interaction,name:app_commands.Range[str,1,100],service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        player=resolve_name(await self.api.players(sid),name)
        try:
            await self.api.request('POST',f'/services/{sid}/gameservers/command',payload={'command':f"KickPlayer {player['id']}"})
            return await i.followup.send(f"Sent KickPlayer for {player.get('name',name)} to the server.",ephemeral=True)
        except NitradoError as e:
            command_error=str(e)
        path=f"/services/{sid}/gameservers/games/players/{quote(str(player['id']),safe='')}"
        try: caps=await self.api.request('GET',path)
        except NitradoError as e: raise NitradoError(f'KickPlayer command: {command_error} | Nitrado kick: {e} | Try /nitrado ban then /nitrado unban instead.') from None
        actions=caps.get('player_actions',[])
        if not isinstance(actions,list) or not any(a=='kick' or isinstance(a,dict) and a.get('type')=='kick' for a in actions):
            raise NitradoError(f'KickPlayer command: {command_error} | Nitrado does not offer a kick for this player/platform.')
        await self.api.request('GET',path,params={'type':'kick'})
        await i.followup.send('Nitrado accepted the player kick.',ephemeral=True)

    @app_commands.command(name='files',description='List a folder on the server (default: the map save folder)')
    @app_commands.describe(folder='Folder inside the game folder, e.g. ShooterGame/Saved/SavedArks (blank = save folder)')
    async def files(self,i:discord.Interaction,folder:str=None,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        root=await self.api.game_root(sid)
        target=folder.strip() if folder else 'ShooterGame/Saved/SavedArks'
        if not target.startswith('/'): target=f"{root}/{target.strip('/')}"
        entries=await self.api.list_dir(sid,target)
        rows=sorted(entries,key=lambda e:(str(e.get('type'))!='dir',-int(e.get('modified_at') or 0)))
        lines=[]
        for e in rows[:60]:
            is_dir=str(e.get('type'))=='dir'
            size='' if is_dir else '%.1f MB' % (int(e.get('size') or 0)/1048576)
            when='  ·  <t:%d:R>' % int(e['modified_at']) if e.get('modified_at') else ''
            lines.append(('📁 ' if is_dir else '📄 ')+str(e.get('name') or e.get('path'))+'  '+size+when)
        text='\n'.join(lines)
        if not text:
            raw=json.dumps(getattr(self.api,'last_list_raw',None),default=str)[:700]
            text=f'Folder looks empty. Nitrado answered: `{raw}`'
        await i.followup.send(f"**{target}**\n{text}"[:1990],ephemeral=True)

    @app_commands.command(name='save-download',description='Download the newest map save (.ark) into the bot data folder')
    async def save_download(self,i:discord.Interaction,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True,thinking=True)
        root=await self.api.game_root(sid)
        folder=f'{root}/ShooterGame/Saved/SavedArks'
        entries=[e for e in await self.api.list_dir(sid,folder) if str(e.get('name') or e.get('path','')).lower().endswith('.ark')]
        if not entries: raise NitradoError(f'No .ark save file found in {folder}. Try /nitrado files to look around.')
        newest=max(entries,key=lambda e:int(e.get('modified_at') or 0))
        name=str(newest.get('name') or str(newest.get('path')).rsplit('/',1)[-1])
        path=str(newest.get('path') or f'{folder}/{name}')
        out=db.DATA/'saves'; out.mkdir(parents=True,exist_ok=True)
        dest=out/f'{sid}-{name}'
        size=await self.api.download_to(sid,path,dest)
        await i.followup.send(f"✅ Downloaded **{name}** ({size/1048576:.1f} MB) to `data/saves/{dest.name}`. Tell Claude it's there.",ephemeral=True)

    @app_commands.command(name='log-files',description='List log files exposed by this service')
    async def log_files(self,i:discord.Interaction,service:str=None):
        sid=await self.sid(i,service)
        await i.response.defer(ephemeral=True)
        g=await self.api.details(sid)
        files=g.get('game_specific',{}).get('log_files',[])
        await i.followup.send(file=discord.File(io.BytesIO(json.dumps(files,indent=2).encode()),filename='log-files.json'),ephemeral=True)

    @app_commands.command(description='Export the latest 128 KiB of a service log')
    @app_commands.choices(kind=[app_commands.Choice(name=x,value=x) for x in ('all','kills','admin','joins')])
    async def logs(self,i:discord.Interaction,file:app_commands.Range[str,1,500],kind:app_commands.Choice[str],service:str=None):
        sid=await self.sid(i,service)
        if not file.lower().endswith(('.log','.txt')): raise NitradoError('Choose a log or text file path from /nitrado log-files.')
        await i.response.defer(ephemeral=True)
        text=await self.api.log_tail(sid,file)
        words={'kills':('was killed','died','killed by'),'admin':('admin','cheat'),'joins':('joined','left this ark','connected','disconnected')}
        if kind.value!='all': text='\n'.join(line for line in text.splitlines() if any(w in line.casefold() for w in words[kind.value]))
        await i.followup.send('Recent log tail. Category filters are text matches; this is not a verified KD feed.',file=discord.File(io.BytesIO((text or 'No matching log lines.').encode()),filename=f'{kind.value}-log.txt'),ephemeral=True)


class LinkNitradoView(discord.ui.View):
    def __init__(self,group,user_id,guild_id):
        super().__init__(timeout=600)
        self.group,self.user_id,self.guild_id=group,user_id,guild_id
        self.add_item(discord.ui.Button(label='1. Get my token',emoji='🔑',url=TOKEN_PAGE))

    async def interaction_check(self,i):
        if i.user.id!=self.user_id:
            await i.response.send_message('Only the admin who ran /linknitrado can use this.',ephemeral=True)
            return False
        return True

    @discord.ui.button(label='2. Paste token',emoji='📋',style=discord.ButtonStyle.success)
    async def paste(self,i,_):
        await i.response.send_modal(SetupModal(self.group,self.user_id,self.guild_id))


class NitradoCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot
        self.api=getattr(bot,"nitrado_api",None) or Client()
        bot.nitrado_api=self.api
        self.config_lock=getattr(bot,'nitrado_config_lock',None) or asyncio.Lock()
        bot.nitrado_config_lock=self.config_lock
        self.group=NitradoGroup(self)
        bot.tree.add_command(self.group)

    async def cog_unload(self):
        self.bot.tree.remove_command('nitrado')

    @app_commands.command(name='linknitrado',description='Link your Nitrado account: paste one token and every ASE server is found')
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    async def linknitrado(self,i:discord.Interaction):
        if not i.user.guild_permissions.administrator:
            raise NitradoError('Discord Administrator permission is required.')
        linked=service_ids()
        current=''
        if linked:
            current='\n\n**Already linked:** '+', '.join(f'{ark_services.name(s)} ({s})' for s in linked)[:900]+'\nPasting a token again re-scans and replaces this list.'
        e=discord.Embed(title='Link Nitrado',color=0x8A2BE2,description=(
            '**1.** Press **Get my token** → log in to Nitrado → **Long-life token** → create one (tick every permission / "service").\n'
            '**2.** Copy it, press **Paste token** and paste it in.\n'
            '**3.** Done — every ARK: Survival Evolved server on that account (Xbox / Windows 10 / PC) is found automatically.\n\n'
            '-# The token is saved only in the bot\'s .env file on your PC and is never shown in Discord.'+current))
        await i.response.send_message(embed=e,view=LinkNitradoView(self.group,i.user.id,i.guild_id),ephemeral=True)


async def setup(bot):
    await bot.add_cog(NitradoCog(bot))

"""Atomic, comment-preserving updates to the host .env file."""
import os
from pathlib import Path
import re
import tempfile
from dotenv import set_key

ENV_PATH=Path(__file__).resolve().parent.parent/'.env'


def parse_service_ids(raw):
    parts=[part for part in re.split(r'[,;\s]+',raw.strip()) if part]
    if not parts or any(not re.fullmatch(r'[0-9]{1,20}',part) or int(part)==0 for part in parts):
        raise ValueError('Enter numeric service IDs separated by commas, spaces, or new lines.')
    result=list(dict.fromkeys(str(int(part)) for part in parts))
    if len(result)>25: raise ValueError('Use up to 25 service IDs in one bot installation.')
    return result


def save_config(token,ids,path=None):
    target=Path(path) if path is not None else ENV_PATH
    updates={'NITRADO_TOKEN':token,'NITRADO_SERVICE_IDS':','.join(ids)}
    temp_path=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=target.parent,prefix='.nitrado-',suffix='.tmp',delete=False) as temporary:
            temp_path=Path(temporary.name)
            if target.exists(): temporary.write(target.read_text(encoding='utf-8'))
        for key,value in updates.items(): set_key(str(temp_path),key,value,quote_mode='always')
        os.replace(temp_path,target)
    finally:
        if temp_path is not None and temp_path.exists(): temp_path.unlink()
    # Update the running process only after a successful durable-file replacement.
    os.environ.update(updates)

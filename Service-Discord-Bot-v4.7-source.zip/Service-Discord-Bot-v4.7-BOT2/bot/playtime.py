"""Playtime tracking across every linked Nitrado server, grouped into clusters.

Every PLAYTIME_POLL_SECONDS (default 60) the bot asks Nitrado who is online on each server
and adds the time since the last check. The Playtime Leaderboard panel (/embed create
type:Playtime) shows the top 3 for a chosen cluster, and the leading *linked* player in each
cluster automatically gets that cluster's record-holder role.
"""
import asyncio
import json
import os
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import admin_check
from nitrado_api import NitradoError, service_ids
import ark_services
from ark_services import fmt_duration, norm_tag

MEDALS = ['🥇', '🥈', '🥉']


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS pt_time(
          service TEXT NOT NULL,
          player_id TEXT NOT NULL,
          name TEXT NOT NULL,
          seconds INTEGER NOT NULL DEFAULT 0,
          last_seen INTEGER,
          PRIMARY KEY(service,player_id)
        );
        CREATE TABLE IF NOT EXISTS pt_clusters(
          guild_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          services TEXT NOT NULL DEFAULT '[]',
          role_id INTEGER,
          holder_id INTEGER,
          PRIMARY KEY(guild_id,name)
        );
        ''')


def poll_seconds():
    try:
        return max(30, min(600, int(os.getenv('PLAYTIME_POLL_SECONDS', '60'))))
    except ValueError:
        return 60


def record_sample(service, online, now, gap_limit):
    """online: list of (player_id, name). Adds time only for back-to-back sightings."""
    ids = {str(pid) for pid, _ in online}
    with db.conn() as c:
        for row in c.execute('SELECT player_id FROM pt_time WHERE service=? AND last_seen IS NOT NULL', (service,)).fetchall():
            if row['player_id'] not in ids:
                c.execute('UPDATE pt_time SET last_seen=NULL WHERE service=? AND player_id=?', (service, row['player_id']))
        for pid, name in online:
            c.execute('''INSERT INTO pt_time(service,player_id,name,seconds,last_seen) VALUES(?,?,?,0,?)
                         ON CONFLICT(service,player_id) DO UPDATE SET name=excluded.name,
                         seconds=seconds+CASE WHEN last_seen IS NOT NULL AND excluded.last_seen-last_seen BETWEEN 0 AND ? THEN excluded.last_seen-last_seen ELSE 0 END,
                         last_seen=excluded.last_seen''', (service, str(pid), name, now, gap_limit))


def drop_sessions(service):
    with db.conn() as c:
        c.execute('UPDATE pt_time SET last_seen=NULL WHERE service=?', (service,))


def clusters(gid):
    with db.conn() as c:
        rows = c.execute('SELECT * FROM pt_clusters WHERE guild_id=? ORDER BY name', (gid,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try: d['services'] = [str(s) for s in json.loads(d['services'] or '[]')]
        except ValueError: d['services'] = []
        out.append(d)
    return out


def get_cluster(gid, name):
    return next((c for c in clusters(gid) if c['name'].casefold() == str(name).casefold()), None)


def board_options(gid):
    rows = clusters(gid)
    if not rows:
        return [discord.SelectOption(label='All servers', value='*', emoji='🏆')]
    return [discord.SelectOption(label=c['name'][:100], value=c['name'][:100], emoji='🏆',
                                 description=(', '.join(ark_services.map_name(s) for s in c['services'])[:100] or None)) for c in rows[:25]]


def ranking(gid, cluster_name):
    if cluster_name == '*':
        services = service_ids()
    else:
        cluster = get_cluster(gid, cluster_name)
        services = cluster['services'] if cluster else []
    if not services:
        return []
    marks = ','.join('?' * len(services))
    with db.conn() as c:
        rows = c.execute(f'SELECT name,seconds,last_seen FROM pt_time WHERE service IN ({marks})', services).fetchall()
    totals = {}
    for r in rows:
        key = norm_tag(r['name'])
        if not key:
            continue
        t = totals.setdefault(key, {'name': r['name'], 'seconds': 0, 'online': False})
        t['seconds'] += int(r['seconds'] or 0)
        t['online'] = t['online'] or r['last_seen'] is not None
    return sorted(totals.values(), key=lambda t: (-t['seconds'], t['name'].casefold()))


def verified_links():
    try:
        with db.conn() as c:
            rows = c.execute('SELECT user_id,gamertag FROM xbox_links WHERE verified=1').fetchall()
    except Exception:
        return {}
    return {norm_tag(r['gamertag']): r['user_id'] for r in rows}


def board_embed(guild, cluster_name, viewer_id=None, limit=3, color=0x8A2BE2):
    rows = ranking(guild.id, cluster_name)
    links = verified_links()
    title = 'All servers' if cluster_name == '*' else cluster_name
    lines = []
    for n, r in enumerate(rows[:limit]):
        badge = MEDALS[n] if n < 3 else f'`#{n + 1}`'
        uid = links.get(norm_tag(r['name']))
        who = f' · <@{uid}>' if uid and guild.get_member(uid) else ''
        live = ' 🟢' if r['online'] else ''
        lines.append(f"{badge} **{discord.utils.escape_markdown(r['name'])}**{live} — `{fmt_duration(r['seconds'])}`{who}")
    e = discord.Embed(title=f'🏆 {title} — Playtime', color=color,
                      description='\n'.join(lines) or 'No playtime recorded yet. It starts counting as soon as players are online.')
    cluster = get_cluster(guild.id, cluster_name) if cluster_name != '*' else None
    if cluster and cluster.get('role_id') and guild.get_role(cluster['role_id']):
        e.add_field(name='Record Holder role', value=f"<@&{cluster['role_id']}> goes to the top **linked** player.", inline=False)
    if viewer_id:
        mine = next((tag for tag, uid in links.items() if uid == viewer_id), None)
        if mine:
            pos = next((n for n, r in enumerate(rows) if norm_tag(r['name']) == mine), None)
            e.add_field(name='You', value=f"#{pos + 1} · `{fmt_duration(rows[pos]['seconds'])}`" if pos is not None else 'No time recorded on this cluster yet.', inline=False)
        else:
            e.add_field(name='You', value='Link your gamertag to see your rank and win roles.', inline=False)
    e.set_footer(text=f'Updates every {poll_seconds()}s · 🟢 = online now')
    return e


def cluster_services(gid, cluster_name):
    if cluster_name == '*':
        return service_ids()
    cluster = get_cluster(gid, cluster_name)
    return cluster['services'] if cluster else []


def _who(guild, links, name):
    uid = links.get(norm_tag(name))
    return f' · <@{uid}>' if uid and guild.get_member(uid) else ''


def leaderboard_embed(guild, cluster_name, viewer_id=None, mode='overview', color=0x8A2BE2):
    """One leaderboard for a cluster: playtime + kills + KD."""
    if mode == 'playtime':
        return board_embed(guild, cluster_name, viewer_id, 10, color)
    import kd
    title = 'All servers' if cluster_name == '*' else cluster_name
    links = verified_links()
    kd_rows = kd.kd_ranking(cluster_services(guild.id, cluster_name))
    if mode in ('kills', 'kd'):
        rows = [r for r in kd_rows if r['kills'] > 0]
        if mode == 'kd':
            rows = sorted([r for r in rows if r['kills'] >= 3], key=lambda r: (-r['kd'], -r['kills']))
        lines = [f"{MEDALS[n] if n < 3 else f'`#{n + 1}`'} **{discord.utils.escape_markdown(r['name'])}** — {kd.fmt_kd(r)}{_who(guild, links, r['name'])}"
                 for n, r in enumerate(rows[:10])]
        e = discord.Embed(title=f"{'⚔️' if mode == 'kills' else '📊'} {title} — {'Top Killers' if mode == 'kills' else 'Best KD (3+ kills)'}",
                          description='\n'.join(lines) or ('Nobody has 3+ kills yet.' if mode == 'kd' else 'No PvP kills recorded yet.'), color=color)
    else:
        pt = ranking(guild.id, cluster_name)
        pt_lines = [f"{MEDALS[n]} **{discord.utils.escape_markdown(r['name'])}**{' 🟢' if r['online'] else ''} — `{fmt_duration(r['seconds'])}`{_who(guild, links, r['name'])}"
                    for n, r in enumerate(pt[:3])]
        killers = [r for r in kd_rows if r['kills'] > 0]
        kd_lines = [f"{MEDALS[n]} **{discord.utils.escape_markdown(r['name'])}** — {kd.fmt_kd(r)}{_who(guild, links, r['name'])}"
                    for n, r in enumerate(killers[:3])]
        e = discord.Embed(title=f'🏆 {title} — Leaderboard', color=color)
        e.add_field(name='⏱️ Playtime', value='\n'.join(pt_lines) or 'No playtime yet.', inline=False)
        e.add_field(name='⚔️ Top Killers', value='\n'.join(kd_lines) or 'No PvP kills yet.', inline=False)
        cluster = get_cluster(guild.id, cluster_name) if cluster_name != '*' else None
        roles = []
        if cluster and cluster.get('role_id') and guild.get_role(cluster['role_id']): roles.append(f"⏱️ <@&{cluster['role_id']}>")
        if cluster and cluster.get('kd_role_id') and guild.get_role(cluster['kd_role_id']): roles.append(f"⚔️ <@&{cluster['kd_role_id']}>")
        if roles:
            e.add_field(name='Record Holder roles', value=' · '.join(roles) + '\nGo to the top **linked** player.', inline=False)
        if viewer_id:
            mine = next((tag for tag, uid in links.items() if uid == viewer_id), None)
            if mine:
                p = next((r for r in pt if norm_tag(r['name']) == mine), None)
                k = next((r for r in kd_rows if norm_tag(r['name']) == mine), None)
                you = [f"⏱️ `{fmt_duration(p['seconds'])}`" if p else '⏱️ no time yet', kd.fmt_kd(k) if k else '⚔️ no kills/deaths yet']
                e.add_field(name='You', value='\n'.join(you), inline=False)
            else:
                e.add_field(name='You', value='Link your gamertag to see your stats and win roles.', inline=False)
    e.set_footer(text='Use the buttons for the full top 10 · kills come from every server in this cluster')
    return e


class LeaderboardView(discord.ui.View):
    def __init__(self, guild, cluster_name, viewer_id, color):
        super().__init__(timeout=600)
        self.guild, self.cluster, self.viewer, self.color = guild, cluster_name, viewer_id, color

    async def show(self, i, mode):
        await i.response.edit_message(embed=leaderboard_embed(self.guild, self.cluster, self.viewer, mode, self.color), view=self)

    @discord.ui.button(label='Overview', emoji='🏆', style=discord.ButtonStyle.secondary)
    async def overview(self, i, _): await self.show(i, 'overview')

    @discord.ui.button(label='Playtime', emoji='⏱️', style=discord.ButtonStyle.secondary)
    async def playtime(self, i, _): await self.show(i, 'playtime')

    @discord.ui.button(label='Kills', emoji='⚔️', style=discord.ButtonStyle.secondary)
    async def kills(self, i, _): await self.show(i, 'kills')

    @discord.ui.button(label='KD', emoji='📊', style=discord.ButtonStyle.secondary)
    async def kd(self, i, _): await self.show(i, 'kd')


class BoardSelect(discord.ui.DynamicItem[discord.ui.Select], template=r'pt:board'):
    def __init__(self):
        super().__init__(discord.ui.Select(custom_id='pt:board', options=[discord.SelectOption(label='All servers', value='*')]))

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls()

    async def callback(self, i: discord.Interaction):
        values = (i.data or {}).get('values') or ['*']
        color = 0x8A2BE2
        embed_cog = i.client.get_cog('EmbedCog')
        row = None
        if embed_cog and i.message:
            import embeds
            with db.conn() as c:
                r = c.execute('SELECT id FROM embeds WHERE message_id=?', (i.message.id,)).fetchone()
            row = embeds.get_embed(r['id']) if r else None
            if row:
                try: color = int(str(row['data'].get('color') or '8A2BE2').lstrip('#'), 16)
                except ValueError: pass
        await i.response.send_message(embed=leaderboard_embed(i.guild, values[0], i.user.id, 'overview', color),
                                      view=LeaderboardView(i.guild, values[0], i.user.id, color), ephemeral=True)
        if row:
            try: await i.message.edit(view=embed_cog.build_view(i.guild, row))
            except discord.HTTPException: pass


async def cluster_ac(i, current):
    current = (current or '').casefold()
    return [app_commands.Choice(name=c['name'][:100], value=c['name'][:100]) for c in clusters(i.guild_id) if current in c['name'].casefold()][:25]


class PlaytimeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api = bot.nitrado_api
        init_tables()

    async def cog_load(self):
        self.bot.add_dynamic_items(BoardSelect)
        self.sampler.change_interval(seconds=poll_seconds())
        self.sampler.start()
        self.rewards.start()

    async def cog_unload(self):
        self.bot.remove_dynamic_items(BoardSelect)
        for loop in (self.sampler, self.rewards):
            task = loop.get_task()
            loop.cancel()
            if task:
                await asyncio.gather(task, return_exceptions=True)

    @tasks.loop(seconds=60)
    async def sampler(self):
        sids = service_ids()
        gap = poll_seconds() * 3

        async def one(sid):
            await ark_services.refresh(self.api, sid)
            try:
                players = await self.api.players(sid)
            except NitradoError:
                drop_sessions(sid)
                return
            online = [(p['id'], p.get('name') or p.get('gamertag') or str(p['id'])) for p in players if p.get('id') and ark_services.is_online(p)]
            record_sample(sid, online, int(time.time()), gap)
        await asyncio.gather(*(one(s) for s in sids), return_exceptions=True)

    @sampler.before_loop
    async def before_sampler(self):
        await self.bot.wait_until_ready()
        with db.conn() as c:
            c.execute('UPDATE pt_time SET last_seen=NULL')  # never count bot downtime

    @tasks.loop(minutes=10)
    async def rewards(self):
        for guild in self.bot.guilds:
            try:
                await self.apply_rewards(guild)
            except Exception as e:
                print(f'Playtime rewards warning ({guild.id}): {type(e).__name__}')

    @rewards.before_loop
    async def before_rewards(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(90)

    async def apply_rewards(self, guild):
        links = verified_links()
        for cluster in clusters(guild.id):
            role = guild.get_role(int(cluster.get('role_id') or 0))
            if not role or role >= guild.me.top_role:
                continue
            holder = None
            for r in ranking(guild.id, cluster['name']):
                uid = links.get(norm_tag(r['name']))
                member = guild.get_member(uid) if uid else None
                if member and r['seconds'] > 0:
                    holder = (member, r)
                    break
            for member in list(role.members):
                if not holder or member.id != holder[0].id:
                    try: await member.remove_roles(role, reason=f'No longer playtime leader of {cluster["name"]}')
                    except discord.HTTPException: pass
            if holder and role not in holder[0].roles:
                try:
                    await holder[0].add_roles(role, reason=f'Playtime leader of {cluster["name"]}')
                except discord.HTTPException:
                    continue
                if holder[0].id != cluster.get('holder_id'):
                    ch = guild.get_channel(int(db.get_setting(guild.id, 'playtime_announce_channel_id', 0) or 0))
                    if ch:
                        try:
                            await ch.send(embed=discord.Embed(color=0xF1C40F, title='👑 New Playtime Record Holder',
                                                              description=f"{holder[0].mention} (**{discord.utils.escape_markdown(holder[1]['name'])}**) now leads "
                                                                          f"**{cluster['name']}** with `{fmt_duration(holder[1]['seconds'])}` and earned {role.mention}!"),
                                          allowed_mentions=discord.AllowedMentions(users=True))
                        except discord.HTTPException:
                            pass
            with db.conn() as c:
                c.execute('UPDATE pt_clusters SET holder_id=? WHERE guild_id=? AND name=?', (holder[0].id if holder else None, guild.id, cluster['name']))
            await self.apply_kd_reward(guild, cluster, links)

    async def apply_kd_reward(self, guild, cluster, links):
        role = guild.get_role(int(cluster.get('kd_role_id') or 0))
        if not role or role >= guild.me.top_role:
            return
        import kd
        holder = None
        for r in kd.kd_ranking(cluster['services']):
            uid = links.get(norm_tag(r['name']))
            member = guild.get_member(uid) if uid else None
            if member and r['kills'] > 0:
                holder = (member, r)
                break
        for member in list(role.members):
            if not holder or member.id != holder[0].id:
                try: await member.remove_roles(role, reason=f'No longer top killer of {cluster["name"]}')
                except discord.HTTPException: pass
        if holder and role not in holder[0].roles:
            try:
                await holder[0].add_roles(role, reason=f'Top killer of {cluster["name"]}')
            except discord.HTTPException:
                return
            if holder[0].id != cluster.get('kd_holder_id'):
                ch = guild.get_channel(int(db.get_setting(guild.id, 'playtime_announce_channel_id', 0) or 0))
                if ch:
                    try:
                        await ch.send(embed=discord.Embed(color=0xE74C3C, title='⚔️ New Top Killer',
                                                          description=f"{holder[0].mention} (**{discord.utils.escape_markdown(holder[1]['name'])}**) leads "
                                                                      f"**{cluster['name']}** with `{holder[1]['kills']}` kills and earned {role.mention}!"),
                                      allowed_mentions=discord.AllowedMentions(users=True))
                    except discord.HTTPException:
                        pass
        with db.conn() as c:
            c.execute('UPDATE pt_clusters SET kd_holder_id=? WHERE guild_id=? AND name=?', (holder[0].id if holder else None, guild.id, cluster['name']))

    async def refresh_panels(self, guild):
        cog = self.bot.get_cog('EmbedCog')
        if cog:
            await cog.refresh_kind(guild, 'playtime')

    # ----- /cluster -----
    cluster = app_commands.Group(name='cluster', description='Server clusters for the playtime leaderboard', guild_only=True)

    @cluster.command(name='create', description='Admin: make a cluster (a group of servers) for the leaderboard')
    @admin_check()
    @app_commands.describe(name='e.g. Duos, 3 Man, PvE', role='Optional "Playtime Record Holder" role for the top linked player')
    async def create(self, i: discord.Interaction, name: app_commands.Range[str, 1, 60], role: discord.Role = None):
        if get_cluster(i.guild_id, name):
            return await i.response.send_message('❌ That cluster already exists.', ephemeral=True)
        if len(clusters(i.guild_id)) >= 25:
            return await i.response.send_message('❌ 25 clusters is the maximum.', ephemeral=True)
        if role and (role.is_default() or role >= i.guild.me.top_role):
            return await i.response.send_message('❌ Pick a role below my highest role.', ephemeral=True)
        with db.conn() as c:
            c.execute('INSERT INTO pt_clusters(guild_id,name,services,role_id) VALUES(?,?,?,?)', (i.guild_id, name.strip(), '[]', role.id if role else None))
        await i.response.send_message(f'✅ Cluster **{name}** created. Add servers with `/cluster add-server`.', ephemeral=True)
        await self.refresh_panels(i.guild)

    @cluster.command(name='add-server', description='Admin: add a Nitrado server to a cluster')
    @admin_check()
    @app_commands.autocomplete(cluster=cluster_ac, server=ark_services.service_autocomplete)
    async def add_server(self, i: discord.Interaction, cluster: str, server: str):
        c_row = get_cluster(i.guild_id, cluster)
        if not c_row:
            return await i.response.send_message('❌ No cluster with that name.', ephemeral=True)
        if server not in service_ids():
            return await i.response.send_message('❌ Pick a server from the list (run `/linknitrado` first if it is empty).', ephemeral=True)
        services = list(dict.fromkeys(c_row['services'] + [server]))
        with db.conn() as c:
            c.execute('UPDATE pt_clusters SET services=? WHERE guild_id=? AND name=?', (json.dumps(services), i.guild_id, c_row['name']))
        await i.response.send_message(f"✅ Added **{ark_services.name(server)}** ({ark_services.map_name(server)}) to **{c_row['name']}**.", ephemeral=True)
        await self.refresh_panels(i.guild)

    @cluster.command(name='remove-server', description='Admin: take a server out of a cluster')
    @admin_check()
    @app_commands.autocomplete(cluster=cluster_ac, server=ark_services.service_autocomplete)
    async def remove_server(self, i: discord.Interaction, cluster: str, server: str):
        c_row = get_cluster(i.guild_id, cluster)
        if not c_row or server not in c_row['services']:
            return await i.response.send_message('❌ That server is not in that cluster.', ephemeral=True)
        services = [s for s in c_row['services'] if s != server]
        with db.conn() as c:
            c.execute('UPDATE pt_clusters SET services=? WHERE guild_id=? AND name=?', (json.dumps(services), i.guild_id, c_row['name']))
        await i.response.send_message('✅ Removed.', ephemeral=True)
        await self.refresh_panels(i.guild)

    @cluster.command(name='role', description='Admin: set (or clear) the record-holder role for a cluster')
    @admin_check()
    @app_commands.autocomplete(cluster=cluster_ac)
    async def role(self, i: discord.Interaction, cluster: str, role: discord.Role = None):
        c_row = get_cluster(i.guild_id, cluster)
        if not c_row:
            return await i.response.send_message('❌ No cluster with that name.', ephemeral=True)
        if role and (role.is_default() or role >= i.guild.me.top_role):
            return await i.response.send_message('❌ Pick a role below my highest role.', ephemeral=True)
        with db.conn() as c:
            c.execute('UPDATE pt_clusters SET role_id=? WHERE guild_id=? AND name=?', (role.id if role else None, i.guild_id, c_row['name']))
        await i.response.send_message(f"✅ Record holder role for **{c_row['name']}**: {role.mention if role else 'none'}. Roles update every 10 minutes.", ephemeral=True)

    @cluster.command(name='kd-role', description='Admin: set (or clear) the Top Killer role for a cluster')
    @admin_check()
    @app_commands.autocomplete(cluster=cluster_ac)
    async def kd_role(self, i: discord.Interaction, cluster: str, role: discord.Role = None):
        c_row = get_cluster(i.guild_id, cluster)
        if not c_row:
            return await i.response.send_message('❌ No cluster with that name.', ephemeral=True)
        if role and (role.is_default() or role >= i.guild.me.top_role):
            return await i.response.send_message('❌ Pick a role below my highest role.', ephemeral=True)
        import kd
        kd.init_tables()
        with db.conn() as c:
            c.execute('UPDATE pt_clusters SET kd_role_id=? WHERE guild_id=? AND name=?', (role.id if role else None, i.guild_id, c_row['name']))
        await i.response.send_message(f"✅ Top Killer role for **{c_row['name']}**: {role.mention if role else 'none'}. Updates every 10 minutes.", ephemeral=True)

    @cluster.command(name='delete', description='Admin: delete a cluster (playtime is kept)')
    @admin_check()
    @app_commands.autocomplete(cluster=cluster_ac)
    async def delete(self, i: discord.Interaction, cluster: str):
        with db.conn() as c:
            n = c.execute('DELETE FROM pt_clusters WHERE guild_id=? AND lower(name)=lower(?)', (i.guild_id, cluster)).rowcount
        await i.response.send_message('✅ Deleted.' if n else '❌ No cluster with that name.', ephemeral=True)
        await self.refresh_panels(i.guild)

    @cluster.command(name='list', description='Show clusters, their servers and roles')
    async def list_cmd(self, i: discord.Interaction):
        rows = clusters(i.guild_id)
        lines = []
        for c_row in rows:
            servers = ', '.join(f'{ark_services.name(s)} ({ark_services.map_name(s)})' for s in c_row['services']) or '*no servers yet*'
            role = f" · <@&{c_row['role_id']}>" if c_row.get('role_id') else ''
            lines.append(f"**{c_row['name']}**{role}\n{servers}")
        await i.response.send_message(embed=discord.Embed(title='Clusters', color=0x8A2BE2, description='\n\n'.join(lines)[:4000] or
                                                          'No clusters yet — the leaderboard shows **All servers**. Make one with `/cluster create`.'), ephemeral=True)

    @cluster.command(name='top', description='Show the top 10 playtime for a cluster')
    @app_commands.autocomplete(cluster=cluster_ac)
    async def top(self, i: discord.Interaction, cluster: str = None):
        name = cluster or '*'
        if name != '*' and not get_cluster(i.guild_id, name):
            return await i.response.send_message('❌ No cluster with that name.', ephemeral=True)
        await i.response.send_message(embed=board_embed(i.guild, name, None, 10), allowed_mentions=discord.AllowedMentions.none())

    @cluster.command(name='announce-channel', description='Admin: where to announce new record holders (blank = off)')
    @admin_check()
    async def announce(self, i: discord.Interaction, channel: discord.TextChannel = None):
        if channel: db.set_setting(i.guild_id, 'playtime_announce_channel_id', channel.id)
        else: db.del_setting(i.guild_id, 'playtime_announce_channel_id')
        await i.response.send_message(f"✅ Announcements: {channel.mention if channel else 'off'}.", ephemeral=True)

    @cluster.command(name='reset-playtime', description='Admin: wipe recorded playtime (e.g. after a server wipe)')
    @admin_check()
    @app_commands.autocomplete(cluster=cluster_ac)
    @app_commands.describe(cluster='Leave empty to wipe ALL servers', confirm='Type RESET to confirm')
    async def reset(self, i: discord.Interaction, confirm: str, cluster: str = None):
        if confirm != 'RESET':
            return await i.response.send_message('Type `RESET` in the confirm box to wipe playtime.', ephemeral=True)
        services = service_ids() if not cluster else (get_cluster(i.guild_id, cluster) or {}).get('services', [])
        if not services:
            return await i.response.send_message('❌ Nothing to reset.', ephemeral=True)
        with db.conn() as c:
            c.execute(f"DELETE FROM pt_time WHERE service IN ({','.join('?' * len(services))})", services)
        await i.response.send_message(f"✅ Playtime wiped for {'all servers' if not cluster else cluster}.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(PlaytimeCog(bot))

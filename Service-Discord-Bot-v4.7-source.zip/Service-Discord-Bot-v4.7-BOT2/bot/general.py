"""Guild moderation and utilities. Persistent state lives in the existing SQLite DB."""
import io
import time
from datetime import timedelta
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import emb


def permission(**perms):
    return app_commands.checks.has_permissions(**perms)


def target_check(i, member):
    if member.id in (i.user.id, i.client.user.id, i.guild.owner_id):
        raise app_commands.CheckFailure("You cannot target yourself, the bot, or the server owner.")
    if i.user.id != i.guild.owner_id and member.top_role >= i.user.top_role:
        raise app_commands.CheckFailure("That member's role is equal to or above yours.")
    if member.top_role >= i.guild.me.top_role:
        raise app_commands.CheckFailure("Move my role above that member's role.")


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS warnings(id INTEGER PRIMARY KEY, guild_id INTEGER, user_id INTEGER, staff_id INTEGER, reason TEXT, created INTEGER);
        CREATE TABLE IF NOT EXISTS afk(guild_id INTEGER, user_id INTEGER, reason TEXT, created INTEGER, PRIMARY KEY(guild_id,user_id));
        CREATE TABLE IF NOT EXISTS wallets(guild_id INTEGER, user_id INTEGER, balance INTEGER NOT NULL DEFAULT 0 CHECK(balance>=0), daily INTEGER DEFAULT 0, PRIMARY KEY(guild_id,user_id));
        CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, guild_id INTEGER, actor INTEGER, source INTEGER, destination INTEGER, amount INTEGER, kind TEXT, created INTEGER);
        ''')


class GeneralCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.afk_notice = {}
        init_tables()

    async def interaction_check(self, i):
        if not i.guild:
            raise app_commands.CheckFailure("Use this in a server.")
        return True

    @app_commands.command(description="Kick a Discord member")
    @app_commands.guild_only()
    @permission(kick_members=True)
    async def kick(self, i: discord.Interaction, member: discord.Member, reason: app_commands.Range[str,1,400]="No reason supplied"):
        target_check(i, member)
        await i.response.defer(ephemeral=True)
        await member.kick(reason=f"{i.user}: {reason}")
        await i.followup.send(f"Kicked {member}. {reason}", ephemeral=True)

    @app_commands.command(description="Ban a Discord member")
    @app_commands.guild_only()
    @permission(ban_members=True)
    async def ban(self, i: discord.Interaction, member: discord.Member, reason: app_commands.Range[str,1,400]="No reason supplied"):
        target_check(i, member)
        await i.response.defer(ephemeral=True)
        await member.ban(reason=f"{i.user}: {reason}", delete_message_seconds=0)
        await i.followup.send(f"Banned {member}. {reason}", ephemeral=True)

    @app_commands.command(description="Remove a Discord ban by user ID")
    @app_commands.guild_only()
    @permission(ban_members=True)
    async def unban(self, i: discord.Interaction, user_id: str):
        if not user_id.isdecimal():
            raise app_commands.CheckFailure("Enter a numeric Discord user ID.")
        await i.response.defer(ephemeral=True)
        await i.guild.unban(discord.Object(id=int(user_id)), reason=f"Unbanned by {i.user}")
        await i.followup.send("Unbanned.", ephemeral=True)

    @app_commands.command(description="Timeout a member (0 minutes removes the timeout)")
    @app_commands.guild_only()
    @permission(moderate_members=True)
    async def timeout(self, i: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int,0,40320], reason: app_commands.Range[str,1,400]="No reason supplied"):
        target_check(i, member)
        if member.guild_permissions.administrator:
            raise app_commands.CheckFailure("Discord does not allow timing out administrators.")
        await i.response.defer(ephemeral=True)
        await member.timeout(timedelta(minutes=minutes) if minutes else None, reason=f"{i.user}: {reason}")
        await i.followup.send(f"Timeout {'removed' if not minutes else f'set for {minutes} minutes'}.", ephemeral=True)

    @app_commands.command(description="Mute a member using Discord timeout")
    @app_commands.guild_only()
    @permission(moderate_members=True)
    async def mute(self, i: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int,1,40320], reason: app_commands.Range[str,1,400]="No reason supplied"):
        await self.timeout.callback(self, i, member, minutes, reason)

    @app_commands.command(description="Change a member's nickname; omit nickname to reset")
    @app_commands.guild_only()
    @permission(manage_nicknames=True)
    async def rename(self, i: discord.Interaction, member: discord.Member, nickname: app_commands.Range[str,1,32]=None):
        target_check(i, member)
        await i.response.defer(ephemeral=True)
        await member.edit(nick=nickname, reason=f"Renamed by {i.user}")
        await i.followup.send("Nickname updated.", ephemeral=True)

    async def channel_lock(self, i, channel, locked):
        channel = channel or i.channel
        if not isinstance(channel, discord.TextChannel):
            raise app_commands.CheckFailure("Choose a text channel.")
        key=f"channel_lock:{channel.id}"
        saved=db.get_setting(i.guild_id,key)
        overwrite=channel.overwrites_for(i.guild.default_role)
        if locked and saved is not None:
            raise app_commands.CheckFailure("This channel is already locked by the bot.")
        if not locked and saved is None:
            raise app_commands.CheckFailure("No saved lock exists for this channel.")
        await i.response.defer(ephemeral=True)
        if locked:
            db.set_setting(i.guild_id,key,{"send_messages":overwrite.send_messages,"send_messages_in_threads":overwrite.send_messages_in_threads})
            overwrite.send_messages=False
            overwrite.send_messages_in_threads=False
        else:
            overwrite.send_messages=saved['send_messages']
            overwrite.send_messages_in_threads=saved['send_messages_in_threads']
        try:
            await channel.set_permissions(i.guild.default_role, overwrite=overwrite if not overwrite.is_empty() else None, reason=f"Channel {'lock' if locked else 'unlock'} by {i.user}")
        except Exception:
            if locked: db.del_setting(i.guild_id,key)
            raise
        if not locked: db.del_setting(i.guild_id,key)
        await i.followup.send(f"{channel.mention} {'locked' if locked else 'unlocked'}. Role-specific allows and administrators can still send.", ephemeral=True)

    @app_commands.command(description="Deny @everyone messages in a text channel")
    @app_commands.guild_only()
    @permission(manage_channels=True)
    async def lock(self, i: discord.Interaction, channel: discord.TextChannel=None):
        await self.channel_lock(i,channel,True)

    @app_commands.command(description="Restore the permissions saved by /lock")
    @app_commands.guild_only()
    @permission(manage_channels=True)
    async def unlock(self, i: discord.Interaction, channel: discord.TextChannel=None):
        await self.channel_lock(i,channel,False)

    @app_commands.command(description="Delete up to 100 recent messages, optionally from one member")
    @app_commands.guild_only()
    @permission(manage_messages=True)
    async def purge(self, i: discord.Interaction, amount: app_commands.Range[int,1,100], member: discord.Member=None):
        await i.response.defer(ephemeral=True)
        deleted=await i.channel.purge(limit=amount, check=lambda m: member is None or m.author.id==member.id)
        await i.followup.send(f"Deleted {len(deleted)} messages from the last {amount} messages.", ephemeral=True)

    @app_commands.command(description="Clear recent messages (alias for purge)")
    @app_commands.guild_only()
    @permission(manage_messages=True)
    async def clear(self, i: discord.Interaction, amount: app_commands.Range[int,1,100]):
        await self.purge.callback(self,i,amount,None)

    @app_commands.command(description="Create a native Discord poll; separate answers with |")
    @app_commands.guild_only()
    @permission(manage_messages=True)
    async def poll(self, i: discord.Interaction, question: app_commands.Range[str,1,300], answers: app_commands.Range[str,3,550], hours: app_commands.Range[int,1,168]=24, multiple: bool=False):
        options=[s.strip() for s in answers.split('|')]
        if not 2<=len(options)<=10 or any(not s or len(s)>55 for s in options):
            raise app_commands.CheckFailure("Use 2–10 answers separated by |, each 1–55 characters.")
        poll=discord.Poll(question=question,duration=timedelta(hours=hours),multiple=multiple)
        for option in options: poll.add_answer(text=option)
        await i.response.send_message(poll=poll)

    @app_commands.command(name="server-info",description="Show Discord server information")
    @app_commands.guild_only()
    async def server_info(self, i: discord.Interaction):
        g=i.guild
        await i.response.send_message(embed=emb(g.name,f"ID: {g.id}\nOwner: <@{g.owner_id}>\nMembers: {g.member_count}\nChannels: {len(g.channels)}\nRoles: {len(g.roles)}\nCreated: {discord.utils.format_dt(g.created_at)}"))

    @app_commands.command(name="who-is",description="Show a Discord member's profile")
    @app_commands.guild_only()
    async def who_is(self, i: discord.Interaction, member: discord.Member=None):
        m=member or i.user
        e=emb(str(m),f"ID: {m.id}\nNickname: {m.display_name}\nCreated: {discord.utils.format_dt(m.created_at)}\nJoined: {discord.utils.format_dt(m.joined_at) if m.joined_at else 'Unknown'}\nRoles: {', '.join(r.name for r in m.roles[1:])[:1500] or 'None'}")
        e.set_thumbnail(url=m.display_avatar.url)
        await i.response.send_message(embed=e)

    @app_commands.command(description="Mark yourself AFK; your next message clears it")
    @app_commands.guild_only()
    async def afk(self, i: discord.Interaction, reason: app_commands.Range[str,1,200]="Away"):
        with db.conn() as c:
            c.execute('INSERT OR REPLACE INTO afk VALUES(?,?,?,?)',(i.guild_id,i.user.id,reason,int(time.time())))
        await i.response.send_message("AFK set. Your next message clears it.",ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot: return
        with db.conn() as c:
            cleared=c.execute('DELETE FROM afk WHERE guild_id=? AND user_id=?',(message.guild.id,message.author.id)).rowcount
            notices=[]
            for member in message.mentions[:10]:
                row=c.execute('SELECT reason,created FROM afk WHERE guild_id=? AND user_id=?',(message.guild.id,member.id)).fetchone()
                if row: notices.append(f"{member.display_name} is AFK: {row['reason']} (since <t:{row['created']}:R>)")
        key=(message.guild.id,message.author.id)
        if cleared: notices.insert(0,"Welcome back! Your AFK status was cleared.")
        if notices and time.monotonic()-self.afk_notice.get(key,0)>15:
            self.afk_notice[key]=time.monotonic()
            try: await message.channel.send('\n'.join(notices)[:1900],allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException: pass

    @app_commands.command(description="Record a warning for a member")
    @app_commands.guild_only()
    @permission(moderate_members=True)
    async def warn(self, i: discord.Interaction, member: discord.Member, reason: app_commands.Range[str,1,500]):
        target_check(i,member)
        with db.conn() as c:
            cur=c.execute('INSERT INTO warnings(guild_id,user_id,staff_id,reason,created) VALUES(?,?,?,?,?)',(i.guild_id,member.id,i.user.id,reason,int(time.time())))
            warning_id=cur.lastrowid
        await i.response.send_message(f"Warning #{warning_id} recorded for {member}.",ephemeral=True)

    @app_commands.command(description="View a member's warning history")
    @app_commands.guild_only()
    @permission(moderate_members=True)
    async def warnings(self, i: discord.Interaction, member: discord.Member):
        with db.conn() as c:
            rows=c.execute('SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC',(i.guild_id,member.id)).fetchall()
        content='\n'.join(f"#{r['id']} | staff {r['staff_id']} | {r['reason']}" for r in rows) or 'No warnings.'
        await i.response.send_message(file=discord.File(io.BytesIO(content.encode()),filename='warnings.txt'),ephemeral=True)

    @app_commands.command(description="Delete a warning by its ID")
    @app_commands.guild_only()
    @permission(moderate_members=True)
    async def unwarn(self, i: discord.Interaction, warning_id: int):
        with db.conn() as c:
            count=c.execute('DELETE FROM warnings WHERE guild_id=? AND id=?',(i.guild_id,warning_id)).rowcount
        await i.response.send_message('Warning removed.' if count else 'Warning not found.',ephemeral=True)

    async def change_role(self,i,member,role,remove):
        target_check(i,member)
        if role.is_default() or role.managed or role>=i.guild.me.top_role or (i.user.id!=i.guild.owner_id and role>=i.user.top_role):
            raise app_commands.CheckFailure("That role cannot be managed at your or my role position.")
        if not i.user.guild_permissions.administrator and role.permissions.value & ~i.user.guild_permissions.value:
            raise app_commands.CheckFailure("You cannot grant or remove a role with permissions you do not hold.")
        await i.response.defer(ephemeral=True)
        action=member.remove_roles if remove else member.add_roles
        await action(role,reason=f"Role change by {i.user}")
        await i.followup.send('Role removed.' if remove else 'Role added.',ephemeral=True)

    @app_commands.command(description="Give a Discord role to a member")
    @app_commands.guild_only()
    @permission(manage_roles=True)
    async def role(self,i:discord.Interaction,member:discord.Member,role:discord.Role):
        await self.change_role(i,member,role,False)

    @app_commands.command(description="Remove a Discord role from a member")
    @app_commands.guild_only()
    @permission(manage_roles=True)
    async def delrole(self,i:discord.Interaction,member:discord.Member,role:discord.Role):
        await self.change_role(i,member,role,True)


async def setup(bot):
    await bot.add_cog(GeneralCog(bot))

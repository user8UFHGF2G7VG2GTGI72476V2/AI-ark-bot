import os
from pathlib import Path
import discord
from discord.ext import commands
from dotenv import load_dotenv

import db
from common import BRAND, VERSION
from extensions import STARTUP_EXTENSIONS
from discord.http import Route

ROOT=Path(__file__).resolve().parent.parent
load_dotenv(ROOT/".env")

TOKEN=os.getenv("DISCORD_TOKEN","").strip()
GUILD_ID=os.getenv("GUILD_ID","").strip()

class FentDiscordManager(commands.Bot):
    def __init__(self):
        intents=discord.Intents.default()
        intents.members=True
        intents.message_content=True
        intents.invites=True
        super().__init__(command_prefix="!",intents=intents, help_command=None, allowed_mentions=discord.AllowedMentions.none())
        self._views_restored=False

    async def setup_hook(self):
        db.init()
        try:
            await self.http.request(Route("PATCH", "/applications/@me"), json={"description": ""})
        except discord.HTTPException as exc:
            print(f"Could not clear global description: {exc.status}. Clear Description in the Developer Portal.")
        for extension in STARTUP_EXTENSIONS:
            await self.load_extension(extension)
        self.tree.on_error = self.on_app_command_error
        if GUILD_ID:
            guild=discord.Object(id=int(GUILD_ID))
            await self.tree.sync()
            self.tree.clear_commands(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

    async def on_ready(self):
        from tickets import TicketActions
        if not self._views_restored:
            # Persistent ticket action buttons survive bot restarts and keep old/open tickets working.
            ticket_cog=self.get_cog('TicketCog')
            if ticket_cog: ticket_cog.restore_views()
            for g in self.guilds:
                with db.conn() as c:
                    closing=c.execute("SELECT channel_id FROM tickets WHERE guild_id=? AND status='closing'",(g.id,)).fetchall()
                    for row in closing:
                        # Recover interrupted closes without leaving a live channel stuck.
                        status='open' if g.get_channel(row['channel_id']) else 'closed'
                        c.execute('UPDATE tickets SET status=? WHERE channel_id=?',(status,row['channel_id']))
                # Upgrade already-open tickets from older versions so their ticket message gets the new buttons.
                try:
                    with db.conn() as c:
                        open_rows=c.execute("SELECT channel_id FROM tickets WHERE guild_id=? AND status='open'",(g.id,)).fetchall()
                    for row in open_rows:
                        ch=g.get_channel(int(row["channel_id"]))
                        if not isinstance(ch,discord.TextChannel):
                            continue
                        async for msg in ch.history(limit=25,oldest_first=True):
                            if msg.author.id == self.user.id and msg.embeds:
                                await msg.edit(view=TicketActions())
                                break
                except Exception as e:
                    print(f"Ticket button restore warning for {g.id}: {e}")
            self._views_restored=True
        print(f"{BRAND} v{VERSION} logged in as {self.user} ({self.user.id})")
        print(f"Servers: {len(self.guilds)}")
        await self.change_presence(activity=None)
        for guild in self.guilds:
            try:
                await self.http.request(Route("PATCH", "/guilds/{guild_id}/members/@me", guild_id=guild.id), json={"bio": ""})
            except discord.HTTPException as exc:
                print(f"Could not clear server bio in {guild.id}: {exc.status}")

    async def close(self):
        try:
            await super().close()
        finally:
            api=getattr(self,'nitrado_api',None)
            if api: await api.close()

    async def on_app_command_error(self,i,error):
        original=getattr(error,"original",error)
        if isinstance(error,discord.app_commands.CheckFailure) or isinstance(original,discord.app_commands.CheckFailure):
            msg=str(original or error)
        elif isinstance(original,discord.Forbidden):
            msg="Discord denied that action. Check my permissions and role position."
        else:
            msg=f"That action failed ({type(original).__name__}: {str(original)[:300]}). Details saved to data/errors.log."
            print(f"Command failed: {type(original).__name__}: {original}")
            try:
                import traceback, time as _t
                cmd=getattr(getattr(i,'command',None),'qualified_name','?')
                with open(db.DATA/'errors.log','a',encoding='utf-8') as f:
                    f.write(f"\n===== {_t.strftime('%Y-%m-%d %H:%M:%S')} /{cmd} =====\n")
                    f.write(''.join(traceback.format_exception(type(original),original,original.__traceback__)))
            except Exception:
                pass
        try:
            if i.response.is_done(): await i.followup.send(f"❌ {msg[:1800]}",ephemeral=True)
            else: await i.response.send_message(f"❌ {msg[:1800]}",ephemeral=True)
        except Exception:pass

if __name__ == "__main__":
    if not TOKEN or TOKEN == "PASTE_DISCORD_BOT_TOKEN_HERE":
        raise SystemExit("Open .env and add DISCORD_TOKEN, then run START-BOT.bat.")
    FentDiscordManager().run(TOKEN)

"""Draws the prize wheel and renders the spinning-wheel GIF.

Slice size is proportional to each option's weight, so what players see on the
wheel matches their real odds.
"""
import io, math, random
from PIL import Image, ImageDraw, ImageFont

CANVAS = 420          # final GIF size (px)
WHEEL = 390           # wheel diameter (px)
SS = 2                # supersampling for smooth edges
BG = (30, 31, 34, 255)
GOLD = (241, 196, 15, 255)
PALETTE = [
    (231, 76, 60), (230, 126, 34), (241, 196, 15), (46, 204, 113),
    (26, 188, 156), (52, 152, 219), (155, 89, 182), (233, 30, 99),
    (192, 57, 43), (211, 84, 0), (39, 174, 96), (22, 160, 133),
    (41, 128, 185), (142, 68, 173), (243, 156, 18), (127, 140, 141),
]

_FONT_CACHE = {}

def _font(size):
    if size in _FONT_CACHE:
        return _FONT_CACHE[size]
    f = None
    for name in ("arialbd.ttf", "Arial Bold.ttf", "arial.ttf", "DejaVuSans-Bold.ttf",
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                 "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
                 "/System/Library/Fonts/Supplemental/Arial Bold.ttf"):
        try:
            f = ImageFont.truetype(name, size)
            break
        except Exception:
            continue
    if f is None:
        try:
            f = ImageFont.load_default(size=size)
        except TypeError:
            f = ImageFont.load_default()
    _FONT_CACHE[size] = f
    return f

def slice_bounds(weights):
    """Return [(start_deg, end_deg)] measured clockwise from the top pointer."""
    total = float(sum(max(0.0001, float(w)) for w in weights))
    out, a = [], 0.0
    for w in weights:
        span = 360.0 * max(0.0001, float(w)) / total
        out.append((a, a + span))
        a += span
    return out

def _slice_color(idx, count):
    c = PALETTE[idx % len(PALETTE)]
    # avoid the last slice matching the first when wrapping around
    if count > 1 and idx == count - 1 and PALETTE[idx % len(PALETTE)] == PALETTE[0]:
        c = PALETTE[(idx + 3) % len(PALETTE)]
    return c + (255,)

def draw_wheel(names, weights):
    S = WHEEL * SS
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    bounds = slice_bounds(weights)
    for idx, (a0, a1) in enumerate(bounds):
        d.pieslice([0, 0, S - 1, S - 1], start=-90 + a0, end=-90 + a1,
                   fill=_slice_color(idx, len(bounds)), outline=(20, 20, 20, 255), width=2 * SS)

    R = S / 2
    r_in, r_out = R * 0.20, R * 0.93
    max_len = r_out - r_in
    for idx, ((a0, a1), name) in enumerate(zip(bounds, names)):
        span = a1 - a0
        mid = (a0 + a1) / 2
        arc_h = 2 * math.pi * (R * 0.6) * span / 360.0   # slice height at 60% radius
        size = int(min(17 * SS, max(8 * SS, arc_h * 0.55)))
        text = str(name)
        font = _font(size)
        while size > 8 * SS and font.getlength(text) > max_len:
            size -= 1
            font = _font(size)
        while font.getlength(text) > max_len and len(text) > 3:
            text = text[:-2] + "…"
        tw = int(font.getlength(text)) + 8 * SS
        th = size + 10 * SS
        timg = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        ImageDraw.Draw(timg).text((4 * SS, 3 * SS), text, font=font, fill=(255, 255, 255, 255),
                                  stroke_width=max(1, SS + 1), stroke_fill=(0, 0, 0, 255))
        # Text points outward along the radius; flip on the left half so it's never upside down.
        rot = 90 - mid
        if 180 < (mid % 360) < 360:
            rot += 180
        timg = timg.rotate(rot, resample=Image.BICUBIC, expand=True)
        rc = (r_in + r_out) / 2
        cx = R + rc * math.sin(math.radians(mid))
        cy = R - rc * math.cos(math.radians(mid))
        x, y = int(cx - timg.width / 2), int(cy - timg.height / 2)
        if x >= 0 and y >= 0 and x + timg.width <= S and y + timg.height <= S:
            img.alpha_composite(timg, (x, y))
        else:
            img.paste(timg, (x, y), timg)

    d.ellipse([0, 0, S - 1, S - 1], outline=GOLD, width=7 * SS)
    return img.resize((WHEEL, WHEEL), Image.LANCZOS)

def _overlay():
    """Static pointer + hub drawn on top of the rotating wheel."""
    S = CANVAS * SS
    o = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(o)
    c = S / 2
    off = (CANVAS - WHEEL) / 2 * SS
    # pointer at the top, pointing down into the wheel
    tip_y = off + 26 * SS
    d.polygon([(c - 17 * SS, off - 8 * SS), (c + 17 * SS, off - 8 * SS), (c, tip_y)],
              fill=(255, 255, 255, 255), outline=(20, 20, 20, 255))
    d.polygon([(c - 17 * SS, off - 8 * SS), (c + 17 * SS, off - 8 * SS), (c, tip_y)],
              outline=(20, 20, 20, 255), width=3 * SS)
    # hub
    hr = 30 * SS
    d.ellipse([c - hr, c - hr, c + hr, c + hr], fill=(35, 36, 40, 255), outline=GOLD, width=5 * SS)
    f = _font(15 * SS)
    tw = f.getlength("SPIN")
    d.text((c - tw / 2, c - 9 * SS), "SPIN", font=f, fill=GOLD)
    return o.resize((CANVAS, CANVAS), Image.LANCZOS)

def _compose(wheel, angle, overlay):
    canvas = Image.new("RGBA", (CANVAS, CANVAS), BG)
    rot = wheel.rotate(-angle, resample=Image.BICUBIC) if angle else wheel
    off = (CANVAS - WHEEL) // 2
    canvas.alpha_composite(rot, (off, off))
    canvas.alpha_composite(overlay)
    return canvas

def render_preview(names, weights):
    """PNG of the wheel standing still."""
    img = _compose(draw_wheel(names, weights), 0, _overlay())
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG", optimize=True)
    return buf.getvalue()

def render_spin(names, weights, win_index, frames=64, frame_ms=55, hold_ms=60000):
    """Animated GIF that spins and stops with win_index under the pointer.

    Returns (gif_bytes, spin_duration_ms). The last frame is held for a long time so
    Discord doesn't visibly restart the spin.
    """
    wheel = draw_wheel(names, weights)
    overlay = _overlay()
    a0, a1 = slice_bounds(weights)[win_index]
    landing = a0 + (a1 - a0) * random.uniform(0.18, 0.82)
    final = 360.0 * random.randint(5, 7) + (360.0 - landing) % 360.0

    imgs = []
    for k in range(frames):
        t = k / (frames - 1)
        ease = 1 - (1 - t) ** 3.2
        frame = _compose(wheel, final * ease, overlay).convert("RGB")
        imgs.append(frame.quantize(colors=96, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE))
    durations = [frame_ms] * (frames - 1) + [hold_ms]
    buf = io.BytesIO()
    imgs[0].save(buf, "GIF", save_all=True, append_images=imgs[1:], duration=durations,
                 loop=0, optimize=False, disposal=1)
    return buf.getvalue(), frame_ms * (frames - 1)

def pointer_slice(weights, final_angle):
    """Which slice index sits under the pointer after rotating clockwise by final_angle (used by tests)."""
    at = (360.0 - final_angle % 360.0) % 360.0
    for idx, (a0, a1) in enumerate(slice_bounds(weights)):
        if a0 <= at < a1:
            return idx
    return len(weights) - 1

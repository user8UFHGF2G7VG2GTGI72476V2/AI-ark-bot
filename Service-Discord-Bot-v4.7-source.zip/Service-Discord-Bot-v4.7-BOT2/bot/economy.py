"""Credits, Mystery Boxes, Wheel Spins, prize claims, the name-tag reward and gamertag links.

Fused from Fent Discord Manager v1.2 into Service Manager. Replaces the old
/credit balance/daily/pay/adjust/leaderboard commands; old wallet balances are
moved over automatically the first time this version starts.
"""
import asyncio
import io
import random
import time
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import emb, admin_check, economy_staff_check, is_economy_staff, send_to_setting_channel, parse_when
import wheel_render

CURRENCIES = {
    "credits": ("Credits", "💰"),
    "boxes": ("Mystery Boxes", "📦"),
    "spins": ("Wheel Spins", "🎡"),
}

DEFAULT_PRIZES = [
    "3x Blueprints", "2x Breeding Pair", "Medium Pack", "50x Heavy + Tek Turrets",
    "1x ARB Dedi", "3x ARB Dedis", "Tribe Ascension 180", "6hr Pack", "8h Pack",
    "3 Resource Dedis", "3 Dedi Fills", "3 Breeding Pairs", "100 Heavy + Tek Turrets", "12h Pack",
]
POOLS = {"mystery": "Mystery Box", "wheel": "Wheel"}
SHOP = {"spins": ("price_spins", "🎡 Wheel Spin"), "boxes": ("price_boxes", "📦 Mystery Box")}
DAILY_DEFAULT = 100
DAILY_COOLDOWN = 86400

NAMETAG_DEFAULT = {"enabled": False, "tag": "", "credits": 5, "ends_at": 0}

# ======================= database =======================

def init_tables():
    db.init()
    with db.conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS balances(
          guild_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          currency TEXT NOT NULL,
          amount INTEGER NOT NULL DEFAULT 0 CHECK(amount>=0),
          PRIMARY KEY(guild_id,user_id,currency)
        );
        CREATE TABLE IF NOT EXISTS econ_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          actor_id INTEGER,
          currency TEXT NOT NULL,
          delta INTEGER NOT NULL,
          reason TEXT,
          at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS daily_claims(
          guild_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          last_at INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(guild_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS prize_options(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          pool TEXT NOT NULL,
          name TEXT NOT NULL COLLATE NOCASE,
          weight REAL NOT NULL DEFAULT 1,
          UNIQUE(guild_id,pool,name)
        );
        CREATE TABLE IF NOT EXISTS prize_claims(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          source TEXT NOT NULL,
          prize TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          created_at INTEGER NOT NULL,
          delivered_by INTEGER,
          delivered_at INTEGER
        );
        CREATE TABLE IF NOT EXISTS nametag_rewards(
          guild_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          tag TEXT NOT NULL COLLATE NOCASE,
          amount INTEGER NOT NULL,
          awarded_at INTEGER NOT NULL,
          PRIMARY KEY(guild_id,user_id,tag)
        );
        CREATE TABLE IF NOT EXISTS player_links(
          guild_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          gamertag TEXT NOT NULL,
          linked_at INTEGER NOT NULL,
          PRIMARY KEY(guild_id,user_id)
        );
        """)
        migrate_old_wallets(c)

def migrate_old_wallets(c):
    """One-time move of the old /credit wallets (v4.5 and earlier) into the new balances table."""
    if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallets'").fetchone():
        return
    if c.execute("SELECT 1 FROM settings WHERE guild_id=0 AND key='wallets_migrated'").fetchone():
        return
    now = int(time.time())
    for r in c.execute("SELECT guild_id,user_id,balance,daily FROM wallets").fetchall():
        if r["balance"] > 0:
            c.execute("""INSERT INTO balances(guild_id,user_id,currency,amount) VALUES(?,?,'credits',?)
                         ON CONFLICT(guild_id,user_id,currency) DO UPDATE SET amount=amount+excluded.amount""",
                      (r["guild_id"], r["user_id"], r["balance"]))
            _log(c, r["guild_id"], r["user_id"], None, "credits", r["balance"], "moved from old credit wallet", now)
        if r["daily"]:
            c.execute("INSERT OR IGNORE INTO daily_claims(guild_id,user_id,last_at) VALUES(?,?,?)",
                      (r["guild_id"], r["user_id"], r["daily"]))
    c.execute("INSERT OR REPLACE INTO settings(guild_id,key,value) VALUES(0,'wallets_migrated','true')")

def _log(c, gid, uid, actor, cur, delta, reason, at=None):
    c.execute("INSERT INTO econ_log(guild_id,user_id,actor_id,currency,delta,reason,at) VALUES(?,?,?,?,?,?,?)",
              (gid, uid, actor, cur, int(delta), (reason or "")[:300], at or int(time.time())))

def _add(c, gid, uid, cur, amount, actor=None, reason=""):
    c.execute("""INSERT INTO balances(guild_id,user_id,currency,amount) VALUES(?,?,?,?)
                 ON CONFLICT(guild_id,user_id,currency) DO UPDATE SET amount=amount+excluded.amount""",
              (gid, uid, cur, int(amount)))
    _log(c, gid, uid, actor, cur, int(amount), reason)

def _take(c, gid, uid, cur, amount, actor=None, reason=""):
    r = c.execute("UPDATE balances SET amount=amount-? WHERE guild_id=? AND user_id=? AND currency=? AND amount>=?",
                  (int(amount), gid, uid, cur, int(amount)))
    if r.rowcount == 0:
        return False
    _log(c, gid, uid, actor, cur, -int(amount), reason)
    return True

def balance(gid, uid, cur):
    with db.conn() as c:
        r = c.execute("SELECT amount FROM balances WHERE guild_id=? AND user_id=? AND currency=?",
                      (gid, uid, cur)).fetchone()
    return int(r["amount"]) if r else 0

def add(gid, uid, cur, amount, actor=None, reason=""):
    with db.conn() as c:
        _add(c, gid, uid, cur, amount, actor, reason)
    return balance(gid, uid, cur)

def take(gid, uid, cur, amount, actor=None, reason=""):
    """Take exactly `amount`. Returns the new balance, or None if they don't have enough."""
    with db.conn() as c:
        ok = _take(c, gid, uid, cur, amount, actor, reason)
    return balance(gid, uid, cur) if ok else None

def take_up_to(gid, uid, cur, amount, actor=None, reason=""):
    """Staff removal: removes up to `amount` (never below 0). Returns (removed, new_balance)."""
    with db.conn() as c:
        r = c.execute("SELECT amount FROM balances WHERE guild_id=? AND user_id=? AND currency=?", (gid, uid, cur)).fetchone()
        have = int(r["amount"]) if r else 0
        removed = min(have, int(amount))
        if removed > 0:
            _take(c, gid, uid, cur, removed, actor, reason)
    return removed, have - removed

def transfer(gid, src, dst, cur, amount):
    """Atomic member-to-member transfer. Returns False if the sender can't afford it."""
    with db.conn() as c:
        if not _take(c, gid, src, cur, amount, src, f"paid <@{dst}>"):
            return False
        _add(c, gid, dst, cur, amount, src, f"payment from <@{src}>")
    return True

def buy(gid, uid, item, qty, price):
    """Atomic: spend credits, receive spins/boxes. Returns new item balance or None if not enough credits."""
    cost = int(price) * int(qty)
    with db.conn() as c:
        if not _take(c, gid, uid, "credits", cost, uid, f"bought {qty} {item}"):
            return None
        _add(c, gid, uid, item, qty, uid, f"bought for {cost} credits")
    return balance(gid, uid, item)

def claim_daily(gid, uid, amount, now=None):
    """Returns (ok, next_time). Atomic: cooldown and credit grant commit together."""
    now = int(now or time.time())
    with db.conn() as c:
        c.execute("INSERT OR IGNORE INTO daily_claims(guild_id,user_id,last_at) VALUES(?,?,0)", (gid, uid))
        r = c.execute("UPDATE daily_claims SET last_at=? WHERE guild_id=? AND user_id=? AND last_at<=?",
                      (now, gid, uid, now - DAILY_COOLDOWN))
        if r.rowcount == 0:
            last = c.execute("SELECT last_at FROM daily_claims WHERE guild_id=? AND user_id=?", (gid, uid)).fetchone()["last_at"]
            return False, last + DAILY_COOLDOWN
        _add(c, gid, uid, "credits", amount, uid, "daily")
    return True, now + DAILY_COOLDOWN

def leaderboard(gid, cur, limit=10, offset=0):
    with db.conn() as c:
        return c.execute("""SELECT user_id, amount FROM balances WHERE guild_id=? AND currency=? AND amount>0
                            ORDER BY amount DESC, user_id LIMIT ? OFFSET ?""", (gid, cur, limit, offset)).fetchall()

def leaderboard_count(gid, cur):
    with db.conn() as c:
        return c.execute("SELECT COUNT(*) n FROM balances WHERE guild_id=? AND currency=? AND amount>0",
                         (gid, cur)).fetchone()["n"]

def rank_of(gid, uid, cur):
    amt = balance(gid, uid, cur)
    if amt <= 0:
        return None
    with db.conn() as c:
        return c.execute("SELECT COUNT(*) n FROM balances WHERE guild_id=? AND currency=? AND amount>?",
                         (gid, cur, amt)).fetchone()["n"] + 1

def pool_options(gid, pool):
    if not db.get_setting(gid, f"prize_pool_seeded_{pool}", False):
        with db.conn() as c:
            for name in DEFAULT_PRIZES:
                c.execute("INSERT OR IGNORE INTO prize_options(guild_id,pool,name,weight) VALUES(?,?,?,1)", (gid, pool, name))
        db.set_setting(gid, f"prize_pool_seeded_{pool}", True)
    with db.conn() as c:
        return [dict(r) for r in c.execute("SELECT id,name,weight FROM prize_options WHERE guild_id=? AND pool=? ORDER BY id",
                                           (gid, pool)).fetchall()]

def pool_upsert(gid, pool, name, weight):
    pool_options(gid, pool)
    with db.conn() as c:
        existed = c.execute("SELECT 1 FROM prize_options WHERE guild_id=? AND pool=? AND name=?", (gid, pool, name)).fetchone()
        c.execute("""INSERT INTO prize_options(guild_id,pool,name,weight) VALUES(?,?,?,?)
                     ON CONFLICT(guild_id,pool,name) DO UPDATE SET weight=excluded.weight""", (gid, pool, name, weight))
    return bool(existed)

def pool_remove(gid, pool, name):
    pool_options(gid, pool)
    with db.conn() as c:
        return c.execute("DELETE FROM prize_options WHERE guild_id=? AND pool=? AND name=?", (gid, pool, name)).rowcount

def pool_clear(gid, pool):
    pool_options(gid, pool)
    with db.conn() as c:
        return c.execute("DELETE FROM prize_options WHERE guild_id=? AND pool=?", (gid, pool)).rowcount

def odds_text(options):
    total = sum(float(o["weight"]) for o in options) or 1
    lines = []
    for n, o in enumerate(options, 1):
        pct = float(o["weight"]) / total * 100
        lines.append(f"`{n:>2}.` **{o['name']}** — {pct:.1f}% *(weight {float(o['weight']):g})*")
    return "\n".join(lines) or "No options."

def pick(options):
    idx = random.choices(range(len(options)), weights=[max(0.0001, float(o["weight"])) for o in options], k=1)[0]
    return idx, options[idx]

def gamertag_of(gid, uid):
    with db.conn() as c:
        r = c.execute("SELECT gamertag FROM player_links WHERE guild_id=? AND user_id=?", (gid, uid)).fetchone()
    return r["gamertag"] if r else None

def create_claim(gid, uid, source, prize):
    with db.conn() as c:
        cur = c.execute("INSERT INTO prize_claims(guild_id,user_id,source,prize,created_at) VALUES(?,?,?,?,?)",
                        (gid, uid, source, prize, int(time.time())))
        return cur.lastrowid

def price_of(gid, item):
    return int(db.get_setting(gid, SHOP[item][0], 0) or 0)

def daily_amount(gid):
    v = db.get_setting(gid, "daily_credits", None)
    return DAILY_DEFAULT if v is None else int(v)

# ======================= prize claims =======================

def claim_embed(claim_id, member_id, source, prize, gamertag, delivered_by=None):
    delivered = delivered_by is not None
    e = discord.Embed(
        title=f"{'✅ Prize Delivered' if delivered else '🎁 Prize To Deliver'} • #{claim_id}",
        color=0x57F287 if delivered else 0xF1C40F,
        timestamp=discord.utils.utcnow(),
    )
    e.add_field(name="Player", value=f"<@{member_id}>", inline=True)
    e.add_field(name="Gamertag", value=gamertag or "*not linked — ask them or use `/link view`*", inline=True)
    e.add_field(name="From", value=source, inline=True)
    e.add_field(name="Prize", value=f"**{prize}**", inline=False)
    if delivered:
        e.add_field(name="Delivered by", value=f"<@{delivered_by}>", inline=False)
    return e

class DeliverButton(discord.ui.DynamicItem[discord.ui.Button], template=r"prize:deliver:(?P<cid>\d+)"):
    def __init__(self, cid: int):
        super().__init__(discord.ui.Button(label="Mark Delivered", emoji="✅", style=discord.ButtonStyle.success,
                                           custom_id=f"prize:deliver:{cid}"))
        self.cid = cid

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls(int(match["cid"]))

    async def callback(self, i: discord.Interaction):
        if not is_economy_staff(i.user):
            return await i.response.send_message("❌ Only staff can mark prizes delivered.", ephemeral=True)
        with db.conn() as c:
            row = c.execute("SELECT * FROM prize_claims WHERE id=? AND guild_id=?", (self.cid, i.guild.id)).fetchone()
            if not row:
                return await i.response.send_message("❌ Claim not found.", ephemeral=True)
            if row["status"] == "delivered":
                return await i.response.send_message(f"Already delivered by <@{row['delivered_by']}>.", ephemeral=True)
            c.execute("UPDATE prize_claims SET status='delivered',delivered_by=?,delivered_at=? WHERE id=?",
                      (i.user.id, int(time.time()), self.cid))
        await i.response.edit_message(embed=claim_embed(row["id"], row["user_id"], row["source"], row["prize"],
                                                        gamertag_of(row["guild_id"], row["user_id"]), i.user.id),
                                      view=delivered_view(self.cid, i.user.display_name))
        await dm_delivered(i.guild, row["user_id"], row["prize"])

def delivered_view(cid, name):
    v = discord.ui.View(timeout=None)
    v.add_item(discord.ui.Button(label=f"Delivered by {name}"[:80], emoji="✅", style=discord.ButtonStyle.secondary,
                                 disabled=True, custom_id=f"prize:done:{cid}"))
    return v

async def dm_delivered(guild, user_id, prize):
    member = guild.get_member(int(user_id))
    if member:
        try:
            await member.send(embed=emb("🎁 Prize Delivered", f"Your **{prize}** from **{guild.name}** has been delivered in-game. Enjoy!"))
        except Exception:
            pass

async def post_claim(guild, member, source, prize):
    cid = create_claim(guild.id, member.id, source, prize)
    v = discord.ui.View(timeout=None)
    v.add_item(DeliverButton(cid))
    await send_to_setting_channel(guild, "prize_channel_id",
                                  embed=claim_embed(cid, member.id, source, prize, gamertag_of(guild.id, member.id)), view=v)
    return cid

async def econ_log(guild, text, color=0x5865F2):
    e = discord.Embed(description=text, color=color, timestamp=discord.utils.utcnow())
    await send_to_setting_channel(guild, "economy_log_channel_id", embed=e, allowed_mentions=discord.AllowedMentions.none())

# ======================= leaderboard view =======================

class LeaderboardView(discord.ui.View):
    PER = 10

    def __init__(self, guild, cur, viewer_id):
        super().__init__(timeout=300)
        self.guild, self.cur, self.viewer_id, self.page = guild, cur, viewer_id, 0
        self.total = leaderboard_count(guild.id, cur)
        self.pages = max(1, (self.total + self.PER - 1) // self.PER)
        self._sync()

    def _sync(self):
        self.prev.disabled = self.page <= 0
        self.next.disabled = self.page >= self.pages - 1

    def embed(self):
        name, icon = CURRENCIES[self.cur]
        rows = leaderboard(self.guild.id, self.cur, self.PER, self.page * self.PER)
        medals = {1: "🥇", 2: "🥈", 3: "🥉"}
        lines = [f"{medals.get(n, f'`#{n}`')} <@{r['user_id']}> — **{r['amount']:,}** {icon}"
                 for n, r in enumerate(rows, self.page * self.PER + 1)]
        e = emb(f"{icon} {name} Leaderboard", "\n".join(lines) or "Nobody has any yet.", 0xF1C40F)
        rk = rank_of(self.guild.id, self.viewer_id, self.cur)
        mine = balance(self.guild.id, self.viewer_id, self.cur)
        e.add_field(name="You", value=f"{'#' + str(rk) if rk else 'Unranked'} • **{mine:,}** {icon}", inline=False)
        e.set_footer(text=f"Page {self.page + 1}/{self.pages} • {self.total} players")
        return e

    @discord.ui.button(label="◀", style=discord.ButtonStyle.secondary)
    async def prev(self, i, b):
        self.page = max(0, self.page - 1); self._sync()
        await i.response.edit_message(embed=self.embed(), view=self)

    @discord.ui.button(label="▶", style=discord.ButtonStyle.secondary)
    async def next(self, i, b):
        self.page = min(self.pages - 1, self.page + 1); self._sync()
        await i.response.edit_message(embed=self.embed(), view=self)

# ======================= shared command bodies =======================

async def do_give(i, member, amount, cur, reason):
    if member.bot:
        return await i.response.send_message("❌ Bots can't hold that.", ephemeral=True)
    name, icon = CURRENCIES[cur]
    new = add(i.guild.id, member.id, cur, amount, i.user.id, reason or "staff give")
    extra = f"\nReason: {reason}" if reason else ""
    await i.response.send_message(embed=emb(f"{icon} {name} Given", f"Gave **{amount:,}** {icon} to {member.mention}.\nNew balance: **{new:,}**{extra}", 0x57F287))
    await econ_log(i.guild, f"{icon} {i.user.mention} gave **{amount:,} {name}** to {member.mention} → **{new:,}**{extra}", 0x57F287)

async def do_remove(i, member, amount, cur, reason):
    name, icon = CURRENCIES[cur]
    removed, new = take_up_to(i.guild.id, member.id, cur, amount, i.user.id, reason or "staff remove")
    note = "" if removed == amount else f"\n*(they only had {removed:,})*"
    extra = f"\nReason: {reason}" if reason else ""
    await i.response.send_message(embed=emb(f"{icon} {name} Removed", f"Removed **{removed:,}** {icon} from {member.mention}.{note}\nNew balance: **{new:,}**{extra}", 0xED4245))
    await econ_log(i.guild, f"{icon} {i.user.mention} removed **{removed:,} {name}** from {member.mention} → **{new:,}**{extra}", 0xED4245)

async def do_view(i, member, focus):
    member = member or i.user
    lines = []
    for cur, (name, icon) in CURRENCIES.items():
        line = f"{icon} **{name}:** {balance(i.guild.id, member.id, cur):,}"
        lines.append(f"__{line}__" if cur == focus else line)
    e = emb(f"{member.display_name}'s Balance", "\n".join(lines), 0x5865F2)
    e.set_thumbnail(url=member.display_avatar.url)
    rk = rank_of(i.guild.id, member.id, "credits")
    if rk:
        e.set_footer(text=f"Credits rank #{rk}")
    await i.response.send_message(embed=e)

async def do_buy(i, item, amount):
    price = price_of(i.guild.id, item)
    label = SHOP[item][1]
    if price <= 0:
        return await i.response.send_message(f"❌ {label}s aren't for sale here. Staff can set a price with `/economy prices`.", ephemeral=True)
    new = buy(i.guild.id, i.user.id, item, amount, price)
    cost = price * amount
    if new is None:
        have = balance(i.guild.id, i.user.id, "credits")
        return await i.response.send_message(f"❌ {amount}x {label} costs **{cost:,}** 💰 — you have **{have:,}**.", ephemeral=True)
    await i.response.send_message(embed=emb("🛒 Purchased", f"{i.user.mention} bought **{amount}x {label}** for **{cost:,}** 💰\nYou now have **{new:,}**.", 0x57F287))
    await econ_log(i.guild, f"🛒 {i.user.mention} bought **{amount}x {label}** for **{cost:,} credits**", 0x57F287)

async def do_option_add(i, pool, name, weight):
    name = name.strip()[:80]
    if not name:
        return await i.response.send_message("❌ Give the option a name.", ephemeral=True)
    existed = pool_upsert(i.guild.id, pool, name, weight)
    await i.response.send_message(embed=emb(f"✅ {POOLS[pool]} option {'updated' if existed else 'added'}",
        f"**{name}** (weight {weight:g})\n\n{odds_text(pool_options(i.guild.id, pool))}"[:4000], 0x57F287), ephemeral=True)

async def do_option_remove(i, pool, name):
    if not pool_remove(i.guild.id, pool, name.strip()):
        return await i.response.send_message(f"❌ No {POOLS[pool]} option named **{name}**.", ephemeral=True)
    await i.response.send_message(embed=emb(f"🗑️ Removed from {POOLS[pool]}", f"**{name}**\n\n{odds_text(pool_options(i.guild.id, pool))}"[:4000]), ephemeral=True)

async def do_option_clear(i, pool):
    n = pool_clear(i.guild.id, pool)
    await i.response.send_message(f"🗑️ Removed all **{n}** {POOLS[pool]} prizes. Add your own with `/{'wheel' if pool == 'wheel' else 'mysterybox'} option-add`.", ephemeral=True)

async def option_autocomplete(i: discord.Interaction, current: str, pool: str):
    cur = (current or "").lower()
    return [app_commands.Choice(name=o["name"][:100], value=o["name"][:100])
            for o in pool_options(i.guild.id, pool) if cur in o["name"].lower()][:25]

async def mystery_ac(i, current): return await option_autocomplete(i, current, "mystery")
async def wheel_ac(i, current): return await option_autocomplete(i, current, "wheel")

# ======================= /credit =======================

class CreditGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="credit", description="Server credits", guild_only=True)

    @app_commands.command(name="give", description="Staff: give credits to a member")
    @economy_staff_check()
    async def give(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000_000], reason: str = None):
        await do_give(i, member, amount, "credits", reason)

    @app_commands.command(name="remove", description="Staff: remove credits from a member")
    @economy_staff_check()
    async def remove(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000_000], reason: str = None):
        await do_remove(i, member, amount, "credits", reason)

    @app_commands.command(name="view", description="See your credits, boxes and spins (or someone else's)")
    async def view(self, i: discord.Interaction, member: discord.Member = None):
        await do_view(i, member, "credits")

    @app_commands.command(name="leaderboard", description="Credits leaderboard")
    async def lb(self, i: discord.Interaction):
        v = LeaderboardView(i.guild, "credits", i.user.id)
        await i.response.send_message(embed=v.embed(), view=v)

    @app_commands.command(name="daily", description="Claim your free daily credits")
    async def daily(self, i: discord.Interaction):
        amount = daily_amount(i.guild.id)
        if amount <= 0:
            return await i.response.send_message("❌ Daily credits are turned off on this server.", ephemeral=True)
        ok, nxt = claim_daily(i.guild.id, i.user.id, amount)
        if not ok:
            return await i.response.send_message(f"⏳ You already claimed today. Come back <t:{nxt}:R>.", ephemeral=True)
        await i.response.send_message(embed=emb("💰 Daily Claimed", f"{i.user.mention} got **{amount:,}** credits.\nNew balance: **{balance(i.guild.id, i.user.id, 'credits'):,}**\nNext claim <t:{nxt}:R>.", 0x57F287))

    @app_commands.command(name="pay", description="Send some of your credits to another member")
    async def pay(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1_000_000_000]):
        if member.bot or member.id == i.user.id:
            return await i.response.send_message("❌ Choose another human member.", ephemeral=True)
        if not transfer(i.guild.id, i.user.id, member.id, "credits", amount):
            return await i.response.send_message("❌ You don't have enough credits.", ephemeral=True)
        await i.response.send_message(embed=emb("💸 Credits Sent", f"{i.user.mention} sent **{amount:,}** 💰 to {member.mention}.", 0x57F287))
        await econ_log(i.guild, f"💸 {i.user.mention} paid **{amount:,} credits** to {member.mention}", 0x5865F2)

# ======================= /mysterybox =======================

class MysteryBoxGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="mysterybox", description="Mystery boxes", guild_only=True)

    @app_commands.command(name="give", description="Staff: give mystery boxes to a member")
    @economy_staff_check()
    async def give(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000] = 1, reason: str = None):
        await do_give(i, member, amount, "boxes", reason)

    @app_commands.command(name="remove", description="Staff: take mystery boxes from a member")
    @economy_staff_check()
    async def remove(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000] = 1, reason: str = None):
        await do_remove(i, member, amount, "boxes", reason)

    @app_commands.command(name="view", description="See how many mystery boxes you (or someone) have")
    async def view(self, i: discord.Interaction, member: discord.Member = None):
        await do_view(i, member, "boxes")

    @app_commands.command(name="buy", description="Buy mystery boxes with your credits")
    async def buy_cmd(self, i: discord.Interaction, amount: app_commands.Range[int, 1, 100] = 1):
        await do_buy(i, "boxes", amount)

    @app_commands.command(name="open", description="Open one of your mystery boxes")
    async def open(self, i: discord.Interaction):
        opts = pool_options(i.guild.id, "mystery")
        if not opts:
            return await i.response.send_message("❌ Staff haven't set up any mystery box prizes yet.", ephemeral=True)
        left = take(i.guild.id, i.user.id, "boxes", 1, i.user.id, "opened mystery box")
        if left is None:
            return await i.response.send_message("📦 You don't have any mystery boxes.", ephemeral=True)
        _, prize = pick(opts)
        e = emb("📦 Opening Mystery Box...", f"{i.user.mention} is opening a box...\n\n🔒 *shaking...*", 0x9B59B6)
        try:
            await i.response.send_message(embed=e)
            msg = await i.original_response()
        except Exception:
            add(i.guild.id, i.user.id, "boxes", 1, None, "refund: open failed")
            raise
        try:
            for n, t in enumerate(random.sample(opts, k=min(3, len(opts)))):
                await asyncio.sleep(0.9)
                e.description = f"{i.user.mention} is opening a box...\n\n{'✨' * (n + 1)} **{t['name']}**?"
                await msg.edit(embed=e)
            await asyncio.sleep(1.1)
        except Exception:
            pass
        await post_claim(i.guild, i.user, "📦 Mystery Box", prize["name"])
        done = emb("🎉 Mystery Box Opened!", f"{i.user.mention} unboxed **{prize['name']}**!\n\n"
                   f"Staff have been notified and will deliver it in-game.\n📦 Boxes left: **{left}**", 0xF1C40F)
        done.set_thumbnail(url=i.user.display_avatar.url)
        try:
            await msg.edit(embed=done)
        except Exception:
            await i.followup.send(embed=done)
        await econ_log(i.guild, f"📦 {i.user.mention} opened a mystery box → **{prize['name']}**", 0x9B59B6)

    @app_commands.command(name="options", description="See every prize in the mystery box and the odds")
    async def options(self, i: discord.Interaction):
        await i.response.send_message(embed=emb("📦 Mystery Box Prizes", odds_text(pool_options(i.guild.id, "mystery"))[:4000], 0x9B59B6))

    @app_commands.command(name="option-add", description="Staff: add a prize (or change its weight). Higher weight = more common")
    @economy_staff_check()
    async def option_add(self, i: discord.Interaction, name: str, weight: app_commands.Range[float, 0.01, 1000.0] = 1.0):
        await do_option_add(i, "mystery", name, weight)

    @app_commands.command(name="option-remove", description="Staff: remove a prize from the mystery box")
    @economy_staff_check()
    @app_commands.autocomplete(name=mystery_ac)
    async def option_remove(self, i: discord.Interaction, name: str):
        await do_option_remove(i, "mystery", name)

    @app_commands.command(name="option-clear", description="Staff: remove ALL mystery box prizes (start fresh)")
    @economy_staff_check()
    async def option_clear(self, i: discord.Interaction):
        await do_option_clear(i, "mystery")

    @app_commands.command(name="leaderboard", description="Who has the most mystery boxes")
    async def lb(self, i: discord.Interaction):
        v = LeaderboardView(i.guild, "boxes", i.user.id)
        await i.response.send_message(embed=v.embed(), view=v)

# ======================= /wheel =======================

class WheelGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="wheel", description="Prize wheel", guild_only=True)

    @app_commands.command(name="spin", description="Spin the prize wheel (uses 1 wheel spin)")
    async def spin(self, i: discord.Interaction):
        opts = pool_options(i.guild.id, "wheel")
        if len(opts) < 2:
            return await i.response.send_message("❌ The wheel needs at least 2 prizes. Staff: `/wheel option-add`.", ephemeral=True)
        left = take(i.guild.id, i.user.id, "spins", 1, i.user.id, "wheel spin")
        if left is None:
            return await i.response.send_message("🎡 You don't have any wheel spins.", ephemeral=True)
        try:
            await i.response.defer(thinking=True)
            idx, prize = pick(opts)
            gif, spin_ms = await asyncio.get_running_loop().run_in_executor(
                None, wheel_render.render_spin, [o["name"] for o in opts], [o["weight"] for o in opts], idx)
            e = emb("🎡 Spinning the wheel...", f"{i.user.mention} is spinning! Good luck 🍀", 0xE67E22)
            e.set_image(url="attachment://wheel.gif")
            msg = await i.followup.send(embed=e, file=discord.File(io.BytesIO(gif), filename="wheel.gif"), wait=True)
        except Exception:
            add(i.guild.id, i.user.id, "spins", 1, None, "refund: spin failed")
            raise
        await asyncio.sleep(spin_ms / 1000 + 1.0)
        await post_claim(i.guild, i.user, "🎡 Wheel Spin", prize["name"])
        e.title = "🎉 The wheel has spoken!"
        e.description = (f"{i.user.mention} landed on **{prize['name']}**!\n\n"
                         f"Staff have been notified and will deliver it in-game.\n🎡 Spins left: **{left}**")
        e.color = 0xF1C40F
        try:
            await msg.edit(embed=e)
        except Exception:
            await i.followup.send(embed=e)
        await econ_log(i.guild, f"🎡 {i.user.mention} spun the wheel → **{prize['name']}**", 0xE67E22)

    @app_commands.command(name="give", description="Staff: give wheel spins to a member")
    @economy_staff_check()
    async def give(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000] = 1, reason: str = None):
        await do_give(i, member, amount, "spins", reason)

    @app_commands.command(name="remove", description="Staff: take wheel spins from a member")
    @economy_staff_check()
    async def remove(self, i: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 10_000] = 1, reason: str = None):
        await do_remove(i, member, amount, "spins", reason)

    @app_commands.command(name="view", description="See how many wheel spins you (or someone) have")
    async def view(self, i: discord.Interaction, member: discord.Member = None):
        await do_view(i, member, "spins")

    @app_commands.command(name="buy", description="Buy wheel spins with your credits")
    async def buy_cmd(self, i: discord.Interaction, amount: app_commands.Range[int, 1, 100] = 1):
        await do_buy(i, "spins", amount)

    @app_commands.command(name="options", description="See the wheel and every prize's odds")
    async def options(self, i: discord.Interaction):
        opts = pool_options(i.guild.id, "wheel")
        e = emb("🎡 Wheel Prizes", odds_text(opts)[:4000], 0xE67E22)
        if len(opts) >= 2:
            await i.response.defer()
            png = await asyncio.get_running_loop().run_in_executor(
                None, wheel_render.render_preview, [o["name"] for o in opts], [o["weight"] for o in opts])
            e.set_image(url="attachment://wheel.png")
            return await i.followup.send(embed=e, file=discord.File(io.BytesIO(png), filename="wheel.png"))
        await i.response.send_message(embed=e)

    @app_commands.command(name="option-add", description="Staff: add a wheel prize (or change its weight). Higher weight = bigger slice")
    @economy_staff_check()
    async def option_add(self, i: discord.Interaction, name: str, weight: app_commands.Range[float, 0.01, 1000.0] = 1.0):
        await do_option_add(i, "wheel", name, weight)

    @app_commands.command(name="option-remove", description="Staff: remove a prize from the wheel")
    @economy_staff_check()
    @app_commands.autocomplete(name=wheel_ac)
    async def option_remove(self, i: discord.Interaction, name: str):
        await do_option_remove(i, "wheel", name)

    @app_commands.command(name="option-clear", description="Staff: remove ALL wheel prizes (start fresh)")
    @economy_staff_check()
    async def option_clear(self, i: discord.Interaction):
        await do_option_clear(i, "wheel")

    @app_commands.command(name="leaderboard", description="Who has the most wheel spins")
    async def lb(self, i: discord.Interaction):
        v = LeaderboardView(i.guild, "spins", i.user.id)
        await i.response.send_message(embed=v.embed(), view=v)

# ======================= /economy settings + /prizes =======================

class EconomyGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="economy", description="Credits / boxes / wheel settings", guild_only=True)

    @app_commands.command(name="setup", description="Admin: create private prize-claims + economy-logs channels for staff")
    @admin_check()
    @app_commands.checks.bot_has_permissions(manage_channels=True)
    async def setup_cmd(self, i: discord.Interaction, staff_role: discord.Role):
        if staff_role.is_default():
            return await i.response.send_message("❌ Pick a staff role, not @everyone.", ephemeral=True)
        await i.response.defer(ephemeral=True, thinking=True)
        g = i.guild
        ow = {
            g.default_role: discord.PermissionOverwrite(view_channel=False),
            staff_role: discord.PermissionOverwrite(view_channel=True, read_message_history=True, send_messages=True),
            g.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, embed_links=True, attach_files=True, read_message_history=True),
        }
        cat = g.get_channel(int(db.get_setting(g.id, "economy_category_id", 0) or 0))
        if not isinstance(cat, discord.CategoryChannel):
            cat = await g.create_category("🎁 PRIZES", overwrites=ow, reason=f"Economy setup by {i.user}")
            db.set_setting(g.id, "economy_category_id", cat.id)
        made = []
        for key, name in (("prize_channel_id", "🎁・prize-claims"), ("economy_log_channel_id", "💰・economy-logs")):
            ch = g.get_channel(int(db.get_setting(g.id, key, 0) or 0))
            if not isinstance(ch, discord.TextChannel):
                ch = await g.create_text_channel(name, category=cat, overwrites=ow, reason=f"Economy setup by {i.user}")
                db.set_setting(g.id, key, ch.id)
            made.append(ch.mention)
        db.set_setting(g.id, "economy_staff_role_id", staff_role.id)
        await i.followup.send(f"✅ Prize claims → {made[0]}\n✅ Economy logs → {made[1]}\n✅ {staff_role.mention} can give/remove credits, boxes and spins.\n\n"
                              "Next: `/wheel option-add`, `/mysterybox option-add`, `/economy prices`.", ephemeral=True)

    @app_commands.command(name="staff-role", description="Admin: the role allowed to give/remove credits, boxes and spins")
    @admin_check()
    async def staff_role_cmd(self, i: discord.Interaction, role: discord.Role):
        db.set_setting(i.guild.id, "economy_staff_role_id", role.id)
        await i.response.send_message(f"✅ {role.mention} can now give/remove credits, mystery boxes and wheel spins.", ephemeral=True)

    @app_commands.command(name="log-channel", description="Admin: channel that logs every credit/box/spin change")
    @admin_check()
    async def log_channel(self, i: discord.Interaction, channel: discord.TextChannel):
        db.set_setting(i.guild.id, "economy_log_channel_id", channel.id)
        await i.response.send_message(f"✅ Economy logs → {channel.mention}", ephemeral=True)

    @app_commands.command(name="prize-channel", description="Admin: staff channel where won prizes show up to be delivered")
    @admin_check()
    async def prize_channel(self, i: discord.Interaction, channel: discord.TextChannel):
        db.set_setting(i.guild.id, "prize_channel_id", channel.id)
        await i.response.send_message(f"✅ Prize claims → {channel.mention}", ephemeral=True)

    @app_commands.command(name="prices", description="Admin: credit price for wheel spins / mystery boxes (0 = not for sale)")
    @admin_check()
    @app_commands.choices(item=[app_commands.Choice(name="Wheel Spin", value="spins"), app_commands.Choice(name="Mystery Box", value="boxes")])
    async def prices(self, i: discord.Interaction, item: app_commands.Choice[str], price: app_commands.Range[int, 0, 10_000_000]):
        db.set_setting(i.guild.id, SHOP[item.value][0], int(price))
        cmd = "/wheel buy" if item.value == "spins" else "/mysterybox buy"
        await i.response.send_message(f"✅ {SHOP[item.value][1]} price → **{price:,}** credits." + (f" Members can use `{cmd}`." if price else " (not for sale)"), ephemeral=True)

    @app_commands.command(name="daily", description="Admin: credits given by /credit daily (0 turns it off)")
    @admin_check()
    async def daily_cmd(self, i: discord.Interaction, credits: app_commands.Range[int, 0, 1_000_000]):
        db.set_setting(i.guild.id, "daily_credits", int(credits))
        await i.response.send_message(f"✅ `/credit daily` now gives **{credits:,}** credits." if credits else "✅ `/credit daily` is OFF.", ephemeral=True)

    @app_commands.command(name="settings", description="Show economy settings")
    async def settings(self, i: discord.Interaction):
        g = i.guild.id
        role = int(db.get_setting(g, "economy_staff_role_id", 0) or 0)
        nt = nametag_cfg(g)
        sp, bx = price_of(g, "spins"), price_of(g, "boxes")
        e = emb("⚙️ Economy Settings",
                f"Staff role: {f'<@&{role}>' if role else '*ticket staff role / admins*'}\n"
                f"Log channel: <#{int(db.get_setting(g, 'economy_log_channel_id', 0) or 0)}>\n"
                f"Prize channel: <#{int(db.get_setting(g, 'prize_channel_id', 0) or 0)}>\n"
                f"Daily credits: **{daily_amount(g):,}**\n"
                f"Wheel spin price: **{f'{sp:,} credits' if sp else 'not for sale'}**\n"
                f"Mystery box price: **{f'{bx:,} credits' if bx else 'not for sale'}**\n"
                f"Name-tag reward: **{'ON' if nt['enabled'] else 'OFF'}**" + (f" — `{nt['tag']}` → {nt['credits']} credits" if nt['tag'] else ""))
        await i.response.send_message(embed=e, ephemeral=True)

class PrizesGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="prizes", description="Won prizes waiting for in-game delivery", guild_only=True)

    @app_commands.command(name="pending", description="Staff: list prizes that still need delivering")
    @economy_staff_check()
    async def pending(self, i: discord.Interaction):
        with db.conn() as c:
            rows = c.execute("SELECT * FROM prize_claims WHERE guild_id=? AND status='pending' ORDER BY id LIMIT 30", (i.guild.id,)).fetchall()
        lines = [f"`#{r['id']}` <@{r['user_id']}> — **{r['prize']}** ({r['source']}) <t:{r['created_at']}:R>" for r in rows]
        await i.response.send_message(embed=emb("🎁 Pending Prizes", "\n".join(lines) or "Nothing pending 🎉"), ephemeral=True)

    @app_commands.command(name="deliver", description="Staff: mark a prize delivered by its # number")
    @economy_staff_check()
    async def deliver(self, i: discord.Interaction, claim_id: int):
        with db.conn() as c:
            row = c.execute("SELECT * FROM prize_claims WHERE id=? AND guild_id=? AND status='pending'", (claim_id, i.guild.id)).fetchone()
            if row:
                c.execute("UPDATE prize_claims SET status='delivered',delivered_by=?,delivered_at=? WHERE id=?", (i.user.id, int(time.time()), claim_id))
        if not row:
            return await i.response.send_message("❌ No pending prize with that number.", ephemeral=True)
        await i.response.send_message(f"✅ #{claim_id} **{row['prize']}** marked delivered.", ephemeral=True)
        await dm_delivered(i.guild, row["user_id"], row["prize"])

    @app_commands.command(name="mine", description="See the prizes you've won")
    async def mine(self, i: discord.Interaction):
        with db.conn() as c:
            rows = c.execute("SELECT * FROM prize_claims WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 20", (i.guild.id, i.user.id)).fetchall()
        lines = [f"{'✅' if r['status'] == 'delivered' else '⏳'} **{r['prize']}** — {r['source']} <t:{r['created_at']}:R>" for r in rows]
        await i.response.send_message(embed=emb("🎁 Your Prizes", "\n".join(lines) or "You haven't won anything yet."), ephemeral=True)

# ======================= /link (gamertag) =======================

class LinkGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="link", description="Link your Discord to your gamertag", guild_only=True)

    @app_commands.command(name="set", description="Link your gamertag (so staff can deliver prizes)")
    async def set_cmd(self, i: discord.Interaction, gamertag: app_commands.Range[str, 1, 40]):
        with db.conn() as c:
            c.execute("INSERT OR REPLACE INTO player_links(guild_id,user_id,gamertag,linked_at) VALUES(?,?,?,?)",
                      (i.guild.id, i.user.id, gamertag.strip(), int(time.time())))
        await i.response.send_message(f"✅ Linked to **{gamertag.strip()}**.", ephemeral=True)

    @app_commands.command(name="view", description="See someone's linked gamertag")
    async def view(self, i: discord.Interaction, member: discord.Member = None):
        member = member or i.user
        tag = gamertag_of(i.guild.id, member.id)
        await i.response.send_message(f"🎮 {member.mention} → **{tag}**" if tag else f"{member.mention} hasn't linked a gamertag.", ephemeral=True)

    @app_commands.command(name="remove", description="Unlink your gamertag")
    async def remove(self, i: discord.Interaction):
        with db.conn() as c:
            c.execute("DELETE FROM player_links WHERE guild_id=? AND user_id=?", (i.guild.id, i.user.id))
        await i.response.send_message("✅ Unlinked.", ephemeral=True)

    @app_commands.command(name="staff-set", description="Staff: set a member's gamertag")
    @economy_staff_check()
    async def staff_set(self, i: discord.Interaction, member: discord.Member, gamertag: app_commands.Range[str, 1, 40]):
        with db.conn() as c:
            c.execute("INSERT OR REPLACE INTO player_links(guild_id,user_id,gamertag,linked_at) VALUES(?,?,?,?)",
                      (i.guild.id, member.id, gamertag.strip(), int(time.time())))
        await i.response.send_message(f"✅ {member.mention} → **{gamertag.strip()}**", ephemeral=True)

    @app_commands.command(name="find", description="Staff: find who owns a gamertag")
    @economy_staff_check()
    async def find(self, i: discord.Interaction, gamertag: str):
        with db.conn() as c:
            rows = c.execute("SELECT user_id,gamertag FROM player_links WHERE guild_id=? AND gamertag LIKE ?",
                             (i.guild.id, f"%{gamertag.strip()}%")).fetchall()
        await i.response.send_message("\n".join(f"<@{r['user_id']}> → **{r['gamertag']}**" for r in rows[:25]) or "No match.", ephemeral=True)

# ======================= name-tag reward =======================

def nametag_cfg(gid):
    cfg = dict(NAMETAG_DEFAULT)
    cfg.update(db.get_setting(gid, "nametag_config", {}) or {})
    return cfg

def has_tag(member, tag):
    t = (tag or "").lower().strip()
    if not t:
        return False
    names = [member.nick, getattr(member, "global_name", None), member.name, member.display_name]
    return any(n and t in n.lower() for n in names)

class NametagGroup(app_commands.Group):
    def __init__(self, cog):
        super().__init__(name="nametag", description="Reward members who rep the server tag in their name", guild_only=True)
        self.cog = cog

    @app_commands.command(name="setup", description="Admin: set the tag, reward and (optional) end date")
    @admin_check()
    @app_commands.describe(tag="Text they must put in their Discord name, e.g. !Iceden",
                           credits="Credits given once per member",
                           ends="Optional last day to claim, e.g. 10/03 6:00PM (leave empty = never ends)",
                           announce_channel="Optional channel to shout-out people who claim it")
    async def setup_cmd(self, i: discord.Interaction, tag: app_commands.Range[str, 2, 32], credits: app_commands.Range[int, 1, 1_000_000] = 5,
                        ends: str = None, announce_channel: discord.TextChannel = None):
        try:
            ends_at = parse_when(ends) if ends else 0
        except ValueError as e:
            return await i.response.send_message(f"❌ {e}", ephemeral=True)
        cfg = nametag_cfg(i.guild.id)
        cfg.update({"enabled": True, "tag": tag.strip(), "credits": int(credits), "ends_at": ends_at})
        if announce_channel:
            db.set_setting(i.guild.id, "nametag_channel_id", announce_channel.id)
        db.set_setting(i.guild.id, "nametag_config", cfg)
        await i.response.send_message(
            f"✅ Anyone who puts **{cfg['tag']}** in their Discord name gets **{cfg['credits']} credits** (once)."
            + (f"\nEnds <t:{ends_at}:F>." if ends_at else "") + "\nScanning current members now...", ephemeral=True)
        n = await self.cog.scan_guild(i.guild)
        await i.followup.send(f"🔎 Scan done — rewarded **{n}** member(s) who already had the tag.", ephemeral=True)

    @app_commands.command(name="scan", description="Admin: reward everyone who currently has the tag")
    @admin_check()
    async def scan(self, i: discord.Interaction):
        await i.response.defer(ephemeral=True, thinking=True)
        n = await self.cog.scan_guild(i.guild)
        await i.followup.send(f"🔎 Rewarded **{n}** new member(s).", ephemeral=True)

    @app_commands.command(name="toggle", description="Admin: turn the name-tag reward on/off")
    @admin_check()
    async def toggle(self, i: discord.Interaction, enabled: bool):
        cfg = nametag_cfg(i.guild.id)
        if enabled and not cfg["tag"]:
            return await i.response.send_message("❌ Set a tag first with `/nametag setup`.", ephemeral=True)
        cfg["enabled"] = enabled
        db.set_setting(i.guild.id, "nametag_config", cfg)
        await i.response.send_message(f"✅ Name-tag reward **{'ON' if enabled else 'OFF'}**.", ephemeral=True)

    @app_commands.command(name="status", description="How the name-tag reward works + who claimed it")
    async def status(self, i: discord.Interaction):
        cfg = nametag_cfg(i.guild.id)
        if not cfg["tag"]:
            return await i.response.send_message("The name-tag reward isn't set up yet. Admins: `/nametag setup`.", ephemeral=True)
        with db.conn() as c:
            n = c.execute("SELECT COUNT(*) n FROM nametag_rewards WHERE guild_id=? AND tag=?", (i.guild.id, cfg["tag"])).fetchone()["n"]
        e = emb("🏷️ Name-Tag Reward",
                f"Put **{cfg['tag']}** anywhere in your Discord name (server nickname or display name) "
                f"and you automatically get **{cfg['credits']} credits** — one time.\n\n"
                f"Status: **{'ON' if cfg['enabled'] else 'OFF'}**"
                + (f"\nEnds: <t:{cfg['ends_at']}:F> (<t:{cfg['ends_at']}:R>)" if cfg.get("ends_at") else "")
                + f"\nClaimed by: **{n}** member(s)", 0x1ABC9C)
        await i.response.send_message(embed=e)

# ======================= cog =======================

class EconomyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        init_tables()
        self.groups = [CreditGroup(), MysteryBoxGroup(), WheelGroup(), EconomyGroup(), PrizesGroup(), LinkGroup(), NametagGroup(self)]
        for g in self.groups:
            bot.tree.add_command(g, override=True)

    async def cog_load(self):
        self.bot.add_dynamic_items(DeliverButton)
        if self.bot.is_ready():
            self.bot.loop.create_task(self.scan_all())

    async def cog_unload(self):
        try:
            self.bot.remove_dynamic_items(DeliverButton)
        except Exception:
            pass
        for g in self.groups:
            self.bot.tree.remove_command(g.name, type=discord.AppCommandType.chat_input)

    async def try_reward(self, member):
        if member.bot or not member.guild:
            return False
        cfg = nametag_cfg(member.guild.id)
        if not cfg["enabled"] or (cfg.get("ends_at") and time.time() > cfg["ends_at"]):
            return False
        if not has_tag(member, cfg["tag"]):
            return False
        with db.conn() as c:
            r = c.execute("INSERT OR IGNORE INTO nametag_rewards(guild_id,user_id,tag,amount,awarded_at) VALUES(?,?,?,?,?)",
                          (member.guild.id, member.id, cfg["tag"], int(cfg["credits"]), int(time.time())))
            if r.rowcount == 0:
                return False
            _add(c, member.guild.id, member.id, "credits", int(cfg["credits"]), None, f"name tag {cfg['tag']}")
        new = balance(member.guild.id, member.id, "credits")
        e = emb("🏷️ Tag Reward!", f"{member.mention} is repping **{cfg['tag']}** and got **{cfg['credits']} credits** 💰", 0x1ABC9C)
        sent = await send_to_setting_channel(member.guild, "nametag_channel_id", content=member.mention, embed=e,
                                             allowed_mentions=discord.AllowedMentions(users=True))
        await econ_log(member.guild, f"🏷️ {member.mention} got **{cfg['credits']} credits** for `{cfg['tag']}` in their name → **{new:,}**", 0x1ABC9C)
        if not sent:
            try:
                await member.send(embed=emb("🏷️ Tag Reward!", f"Thanks for repping **{cfg['tag']}** in **{member.guild.name}**! You got **{cfg['credits']} credits** 💰"))
            except Exception:
                pass
        return True

    async def scan_guild(self, guild):
        n = 0
        for m in list(guild.members):
            try:
                if await self.try_reward(m):
                    n += 1
            except Exception as e:
                print(f"Nametag scan warning: {type(e).__name__}")
        return n

    async def scan_all(self):
        for g in self.bot.guilds:
            n = await self.scan_guild(g)
            if n:
                print(f"Name-tag reward: gave credits to {n} member(s) in {g.name}")

    @commands.Cog.listener()
    async def on_ready(self):
        if getattr(self.bot, "_nametag_scanned", False):
            return
        self.bot._nametag_scanned = True
        await self.scan_all()

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.nick != after.nick or before.display_name != after.display_name:
            await self.try_reward(after)

    @commands.Cog.listener()
    async def on_user_update(self, before, after):
        if before.name == after.name and getattr(before, "global_name", None) == getattr(after, "global_name", None):
            return
        for g in self.bot.guilds:
            m = g.get_member(after.id)
            if m:
                await self.try_reward(m)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        await self.try_reward(member)


async def setup(bot):
    await bot.add_cog(EconomyCog(bot))

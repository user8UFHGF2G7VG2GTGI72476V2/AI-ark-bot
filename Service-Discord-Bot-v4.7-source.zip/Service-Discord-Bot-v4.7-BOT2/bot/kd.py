"""KD tracking from the real ARK death lines, on EVERY linked Nitrado server.

Every KD_POLL_SECONDS (default 300) the bot reads the newest part of each server's
ShooterGame.log through your Nitrado token and records lines like:
  mok - Lvl 105 () was killed by Blrddd - Lvl 105 ()! [KillerSID: 950526505]   -> PvP kill
  ski - Lvl 105 () was killed by a R-Allosaurus - Lvl 241 ()!                   -> death to a dino
Each line is stored once (re-reading the same log never double counts).

Shown on the Leaderboard panel together with playtime, per cluster.
/reset all | playtime | kd   wipes stats after a server wipe (links and settings are kept).
"""
import asyncio
import hashlib
import os
import re
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import admin_check
from nitrado_api import NitradoError, service_ids
from log_sources import find_log
import ark_services
from ark_services import norm_tag

DEATH_RE = re.compile(
    r"(?P<victim>[^:\r\n]+?) - Lvl (?P<vlvl>\d+) \((?P<vtribe>[^()]*)\) was killed by (?P<article>an? )?"
    r"(?P<killer>[^\r\n]+?)\s*- Lvl (?P<klvl>\d+) \((?P<ktribe>[^()]*)\)!(?P<sid>\s*\[KillerSID: \d+\])?")
TRIBE_LOG = re.compile(r'Tribe .{0,80}, ID \d+: Day \d+')


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS kd_events(
          id TEXT PRIMARY KEY,
          service TEXT NOT NULL,
          killer TEXT,
          victim TEXT NOT NULL,
          killer_tribe TEXT,
          victim_tribe TEXT,
          pvp INTEGER NOT NULL DEFAULT 0,
          created INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_kd_service ON kd_events(service);
        ''')
        for col in ('kd_role_id INTEGER', 'kd_holder_id INTEGER'):
            try: c.execute(f'ALTER TABLE pt_clusters ADD COLUMN {col}')
            except Exception: pass


def poll_seconds():
    try: return max(60, min(3600, int(os.getenv('KD_POLL_SECONDS', '300'))))
    except ValueError: return 300


def parse_death(line):
    """Return dict(killer, victim, pvp, ...) for a player death line, else None."""
    if not line or 'was killed by' not in line or TRIBE_LOG.search(line) or 'RichColor' in line:
        return None
    body = re.sub(r'^\[[^\]]*\]\[[^\]]*\]', '', line.strip())
    body = re.sub(r'^\d{4}\.\d{2}\.\d{2}_\d{2}\.\d{2}\.\d{2}:\s*', '', body)
    m = DEATH_RE.search(body)
    if not m:
        return None
    killer = m.group('killer').strip()
    pvp = bool(m.group('sid')) or (not m.group('article') and killer.casefold() not in ('', 'unknown'))
    victim = m.group('victim').strip()
    if pvp and norm_tag(killer) == norm_tag(victim):
        pvp = False  # suicide
    return {'victim': victim, 'killer': killer if pvp else None, 'pvp': pvp,
            'victim_tribe': m.group('vtribe').strip(), 'killer_tribe': m.group('ktribe').strip()}


def record_lines(service, lines, now=None):
    """Store new death lines. Returns how many were new."""
    now = int(now or time.time())
    new = 0
    with db.conn() as c:
        for line in lines:
            d = parse_death(line)
            if not d:
                continue
            key = hashlib.sha256(f'{service}|{line.strip()}'.encode()).hexdigest()
            cur = c.execute('INSERT OR IGNORE INTO kd_events(id,service,killer,victim,killer_tribe,victim_tribe,pvp,created) VALUES(?,?,?,?,?,?,?,?)',
                            (key, service, d['killer'], d['victim'], d['killer_tribe'], d['victim_tribe'], 1 if d['pvp'] else 0, now))
            new += cur.rowcount
    return new


def kd_ranking(services):
    """[{name, kills, deaths, pve_deaths, kd}] for these services, grouped by gamertag."""
    if not services:
        return []
    marks = ','.join('?' * len(services))
    with db.conn() as c:
        rows = c.execute(f'SELECT killer,victim,pvp FROM kd_events WHERE service IN ({marks})', list(services)).fetchall()
    stats = {}

    def entry(name):
        key = norm_tag(name)
        return stats.setdefault(key, {'name': name, 'kills': 0, 'deaths': 0, 'pve_deaths': 0}) if key else None
    for r in rows:
        if r['pvp'] and r['killer']:
            k = entry(r['killer'])
            if k: k['kills'] += 1
            v = entry(r['victim'])
            if v: v['deaths'] += 1
        else:
            v = entry(r['victim'])
            if v: v['pve_deaths'] += 1
    for s in stats.values():
        s['kd'] = s['kills'] / s['deaths'] if s['deaths'] else float(s['kills'])
    return sorted(stats.values(), key=lambda s: (-s['kills'], s['deaths'], s['name'].casefold()))


def fmt_kd(s):
    return f"`{s['kills']}` kills · `{s['deaths']}` deaths · KD `{s['kd']:.2f}`"


class KDCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api = bot.nitrado_api
        self.failures = {}
        init_tables()

    async def cog_load(self):
        self.poller.change_interval(seconds=poll_seconds())
        self.poller.start()

    async def cog_unload(self):
        task = self.poller.get_task()
        self.poller.cancel()
        if task:
            await asyncio.gather(task, return_exceptions=True)

    async def log_path(self, sid):
        cached = db.get_setting(0, f'kd_log:{sid}', '')
        if cached:
            return cached
        path = await find_log(self.api, sid)
        db.set_setting(0, f'kd_log:{sid}', path)
        return path

    async def scan(self, sid, length=262144):
        try:
            text = await self.api.log_tail(sid, await self.log_path(sid), length=length)
        except NitradoError:
            db.del_setting(0, f'kd_log:{sid}')  # path may have changed; look again next time
            raise
        lines = text.splitlines()
        ca = self.bot.get_cog('CACog')
        if ca:
            try: await ca.process(sid, lines)
            except Exception as e: print(f'CA scan warning ({sid}): {type(e).__name__}: {e}')
        return record_lines(sid, lines)

    async def scan_all(self, length=262144):
        results = {}

        async def one(sid):
            try:
                results[sid] = await self.scan(sid, length)
                self.failures[sid] = 0
            except NitradoError as e:
                self.failures[sid] = self.failures.get(sid, 0) + 1
                results[sid] = e
        await asyncio.gather(*(one(s) for s in service_ids()))
        return results

    @tasks.loop(seconds=300)
    async def poller(self):
        await self.scan_all()

    @poller.before_loop
    async def before(self):
        await self.bot.wait_until_ready()

    # ----- /reset -----
    reset = app_commands.Group(name='reset', description='Wipe stats after a server wipe (links & settings are kept)', guild_only=True)

    async def _confirm(self, i, confirm):
        if confirm != 'RESET':
            await i.response.send_message('Type `RESET` in the confirm box to do this. It cannot be undone.', ephemeral=True)
            return False
        return True

    @reset.command(name='all', description='Admin: wipe ALL playtime, KD and saved log lines (for a server wipe)')
    @admin_check()
    @app_commands.describe(confirm='Type RESET to confirm')
    async def reset_all(self, i: discord.Interaction, confirm: str):
        if not await self._confirm(i, confirm):
            return
        with db.conn() as c:
            counts = {}
            for table in ('pt_time', 'kd_events', 'ark_events', 'ark_playtime', 'ca_events'):
                try: counts[table] = c.execute(f'DELETE FROM {table}').rowcount
                except Exception: counts[table] = 0
            try: c.execute('UPDATE pt_clusters SET holder_id=NULL, kd_holder_id=NULL')
            except Exception: pass
        db.set_setting(0, 'notifier_cursor', 0)
        await i.response.send_message(
            f"🧹 **Wiped.** Playtime rows: {counts['pt_time']} · KD events: {counts['kd_events']} · turret breaks: {counts['ca_events']} · saved log lines: {counts['ark_events']}.\n"
            "Gamertag links, panels, clusters, notifiers and settings are kept. Record-holder roles update on the next check.", ephemeral=True)

    @reset.command(name='playtime', description='Admin: wipe playtime only')
    @admin_check()
    @app_commands.describe(confirm='Type RESET to confirm')
    async def reset_playtime(self, i: discord.Interaction, confirm: str):
        if not await self._confirm(i, confirm):
            return
        with db.conn() as c:
            n = c.execute('DELETE FROM pt_time').rowcount
        await i.response.send_message(f'🧹 Playtime wiped ({n} rows).', ephemeral=True)

    @reset.command(name='kd', description='Admin: wipe kills and deaths only')
    @admin_check()
    @app_commands.describe(confirm='Type RESET to confirm')
    async def reset_kd(self, i: discord.Interaction, confirm: str):
        if not await self._confirm(i, confirm):
            return
        with db.conn() as c:
            n = c.execute('DELETE FROM kd_events').rowcount
            try: c.execute('UPDATE pt_clusters SET kd_holder_id=NULL')
            except Exception: pass
        await i.response.send_message(f'🧹 KD wiped ({n} kill/death lines).', ephemeral=True)

    @reset.command(name='ca', description='Admin: wipe CA turret-break points (registered tribes are kept)')
    @admin_check()
    @app_commands.describe(confirm='Type RESET to confirm')
    async def reset_ca(self, i: discord.Interaction, confirm: str):
        if not await self._confirm(i, confirm):
            return
        with db.conn() as c:
            n = c.execute('DELETE FROM ca_events').rowcount
            c.execute('UPDATE ca_tribes SET registered_at=? WHERE guild_id=?', (int(time.time()), i.guild_id))
        await i.response.send_message(f'🧹 CA points wiped ({n} turret breaks). Registered tribes start counting again from now.', ephemeral=True)
        ca = self.bot.get_cog('CACog')
        if ca: await ca.refresh_board(i.guild)

    @app_commands.command(name='kd-scan', description='Admin: read every server log now and update kills/deaths')
    @app_commands.guild_only()
    @admin_check()
    async def kd_scan(self, i: discord.Interaction):
        await i.response.defer(ephemeral=True, thinking=True)
        results = await self.scan_all(length=1024 * 1024)
        lines = []
        for sid, r in results.items():
            label = f'{ark_services.name(sid)} ({ark_services.map_name(sid)})'
            lines.append(f'❌ {label}: {r}' if isinstance(r, Exception) else f'✅ {label}: {r} new kill/death line(s)')
        await i.followup.send(('\n'.join(lines) or 'No servers linked. Run /linknitrado.')[:1900], ephemeral=True)


async def setup(bot):
    await bot.add_cog(KDCog(bot))

"""CA (raid) leaderboard: registered tribes earn points for enemy turrets they destroy.

Source: the attacker's tribe log, which ARK writes as
  Tribe Tribe of N I X U S, ID 1366573257: Day 1, 20:47:02: <RichColor ...>mavrixzo - Lvl 135 destroyed their
  'Heavy Automated Turret (Locked)  (The Retards)')!</>)
The KD scanner reads every linked server's log every few minutes and hands the lines here.

/ca turret-points   set points per turret type (applies to the whole leaderboard)
/ca register        register a tribe by its exact in-game name; only breaks AFTER registering count
/ca leaderboard     post the auto-updating CA leaderboard embed in a channel
/ca log-channel     every turret break is dumped there (registered or not)
"""
import calendar
import hashlib
import io
import re
import time
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import admin_check
import ark_services

TURRETS = [
    ('Heavy Automated Turret', 'Heavy Turret'),
    ('Tek Turret', 'Tek Turret'),
    ('Automated Turret', 'Auto Turret'),
    ('Rocket Turret', 'Rocket Turret'),
    ('Minigun Turret', 'Minigun Turret'),
    ('Plant Species X', 'Plant X'),
    ('Ballista Turret', 'Ballista'),
    ('Cannon', 'Cannon'),
    ('Catapult Turret', 'Catapult'),
]
BREAK_RE = re.compile(r"Tribe (?P<tribe>.+?), ID \d+: Day \d+, [\d:]+: (?:<RichColor[^>]*>)?(?P<attacker>.+?) destroyed their '(?P<inner>.+)'\)?!")
STAMP_RE = re.compile(r'^\[(\d{4})\.(\d{2})\.(\d{2})-(\d{2})\.(\d{2})\.(\d{2})')


def norm(name):
    return ' '.join(str(name or '').split()).casefold()


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS ca_points(guild_id INTEGER, pattern TEXT, label TEXT, points INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(guild_id,pattern));
        CREATE TABLE IF NOT EXISTS ca_tribes(guild_id INTEGER, tribe TEXT, tribe_norm TEXT, registered_at INTEGER, leader_id INTEGER, PRIMARY KEY(guild_id,tribe_norm));
        CREATE TABLE IF NOT EXISTS ca_events(
          id TEXT PRIMARY KEY, service TEXT, attacker_tribe TEXT, attacker_norm TEXT, attacker TEXT,
          victim_tribe TEXT, structure TEXT, at_time INTEGER, created INTEGER);
        CREATE INDEX IF NOT EXISTS idx_ca_attacker ON ca_events(attacker_norm);
        ''')


def line_time(line):
    m = STAMP_RE.match(line.strip())
    if not m:
        return int(time.time())
    y, mo, d, h, mi, s = (int(x) for x in m.groups())
    return calendar.timegm((y, mo, d, h, mi, s, 0, 0, 0))  # server log clock is UTC


def parse_break(line):
    """Enemy structure destroyed, from the attacker's tribe log. Returns dict or None."""
    if 'destroyed their' not in line:
        return None
    m = BREAK_RE.search(line)
    if not m:
        return None
    inner = m.group('inner').strip()
    victim = ''
    vm = re.search(r'\s*\(([^()]*)\)\s*$', inner)
    if vm:
        victim, inner = vm.group(1).strip(), inner[:vm.start()].strip()
    structure = re.sub(r'\s*\((?:Locked|Unlocked)\)\s*', ' ', inner).strip()
    attacker = re.sub(r'\s*-\s*Lvl \d+.*$', '', m.group('attacker')).strip()
    return {'tribe': m.group('tribe').strip(), 'attacker': attacker, 'victim': victim, 'structure': structure}


def point_rules(gid):
    with db.conn() as c:
        rows = c.execute('SELECT pattern,label,points FROM ca_points WHERE guild_id=?', (gid,)).fetchall()
    return sorted((dict(r) for r in rows), key=lambda r: -len(r['pattern']))


def rule_for(structure, rules):
    low = structure.casefold()
    return next((r for r in rules if r['pattern'].casefold() in low), None)


def tracked(structure, gid_rules=()):
    low = structure.casefold()
    return 'turret' in low or 'plant species x' in low or 'cannon' in low or any(r['pattern'].casefold() in low for r in gid_rules)


def record_lines(service, lines):
    """Store new turret breaks. Returns list of new event dicts."""
    with db.conn() as c:
        all_rules = [dict(r) for r in c.execute('SELECT pattern,label,points FROM ca_points').fetchall()]
    new = []
    now = int(time.time())
    with db.conn() as c:
        for line in lines:
            b = parse_break(line)
            if not b or not tracked(b['structure'], all_rules):
                continue
            key = hashlib.sha256(f'{service}|{line.strip()}'.encode()).hexdigest()
            at = line_time(line)
            cur = c.execute('INSERT OR IGNORE INTO ca_events(id,service,attacker_tribe,attacker_norm,attacker,victim_tribe,structure,at_time,created) VALUES(?,?,?,?,?,?,?,?,?)',
                            (key, service, b['tribe'], norm(b['tribe']), b['attacker'], b['victim'], b['structure'], at, now))
            if cur.rowcount:
                new.append(dict(b, service=service, at_time=at))
    return new


def tribes(gid):
    with db.conn() as c:
        return [dict(r) for r in c.execute('SELECT * FROM ca_tribes WHERE guild_id=? ORDER BY tribe', (gid,)).fetchall()]


def standings(gid):
    rules = point_rules(gid)
    out = []
    for t in tribes(gid):
        with db.conn() as c:
            rows = c.execute('SELECT structure FROM ca_events WHERE attacker_norm=? AND at_time>=?', (t['tribe_norm'], t['registered_at'])).fetchall()
        counts, points = {}, 0
        for r in rows:
            rule = rule_for(r['structure'], rules)
            label = rule['label'] if rule else r['structure']
            counts[label] = counts.get(label, 0) + 1
            points += rule['points'] if rule else 0
        out.append({'tribe': t['tribe'], 'points': points, 'breaks': len(rows), 'counts': counts, 'leader_id': t['leader_id']})
    return sorted(out, key=lambda s: (-s['points'], -s['breaks'], s['tribe'].casefold()))


def leaderboard_embed(guild):
    rows = standings(guild.id)
    medals = ['🥇', '🥈', '🥉']
    lines = []
    for n, s in enumerate(rows[:20]):
        badge = medals[n] if n < 3 else f'`#{n + 1}`'
        detail = ' · '.join(f'{k} ×{v}' for k, v in sorted(s['counts'].items(), key=lambda kv: -kv[1])[:4]) or 'no turrets yet'
        lead = f" · <@{s['leader_id']}>" if s.get('leader_id') else ''
        lines.append(f"{badge} **{discord.utils.escape_markdown(s['tribe'])}** — `{s['points']}` pts{lead}\n-# {detail}")
    e = discord.Embed(title='💥 CA Leaderboard', color=0x8A2BE2,
                      description='\n'.join(lines) or 'No CA tribes registered yet. Admins: `/ca register`.')
    rules = point_rules(guild.id)
    if rules:
        e.add_field(name='Points', value=' · '.join(f"{r['label']} `{r['points']}`" for r in rules)[:1024], inline=False)
    e.set_footer(text='Counts enemy turrets destroyed after registering · all servers · updates every few minutes')
    e.timestamp = discord.utils.utcnow()
    return e


async def tribe_ac(i, current):
    current = (current or '').casefold()
    return [app_commands.Choice(name=t['tribe'][:100], value=t['tribe'][:100]) for t in tribes(i.guild_id) if current in t['tribe'].casefold()][:25]


class CACog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        init_tables()

    async def process(self, sid, lines):
        """Called by the KD scanner with fresh log lines from one server."""
        new = record_lines(sid, lines)
        if not new:
            return
        for guild in self.bot.guilds:
            await self.dump_log(guild, sid, new)
            await self.refresh_board(guild)

    async def dump_log(self, guild, sid, events):
        ch = guild.get_channel(int(db.get_setting(guild.id, 'ca_log_channel_id', 0) or 0))
        if not isinstance(ch, (discord.TextChannel, discord.Thread)):
            return
        rules = point_rules(guild.id)
        registered = {t['tribe_norm']: t for t in tribes(guild.id)}
        lines = []
        for ev in events:
            rule = rule_for(ev['structure'], rules)
            reg = registered.get(norm(ev['tribe']))
            counts = reg and ev['at_time'] >= reg['registered_at']
            pts = f" · **+{rule['points'] if rule else 0} pts**" if counts else ' · not CA registered'
            lines.append(f"<t:{ev['at_time']}:T> 💥 **{discord.utils.escape_markdown(ev['tribe'])}** ({discord.utils.escape_markdown(ev['attacker'])}) "
                         f"destroyed **{ev['structure']}** of **{discord.utils.escape_markdown(ev['victim'] or '?')}**{pts}")
        title = f'Turret breaks — {ark_services.name(sid)} ({ark_services.map_name(sid)})'
        text = '\n'.join(lines)
        try:
            if len(text) <= 4000:
                await ch.send(embed=discord.Embed(title=title[:256], description=text, color=0xE67E22), allowed_mentions=discord.AllowedMentions.none())
            else:
                await ch.send(f'**{title}** — {len(lines)} breaks', file=discord.File(io.BytesIO(re.sub(r'<t:\d+:T> ', '', text).replace('**', '').encode()),
                                                                                       filename='turret-breaks.txt'))
        except discord.HTTPException:
            pass

    async def refresh_board(self, guild):
        cid = int(db.get_setting(guild.id, 'ca_board_channel_id', 0) or 0)
        mid = int(db.get_setting(guild.id, 'ca_board_message_id', 0) or 0)
        ch = guild.get_channel(cid)
        if not ch or not mid:
            return
        try:
            await ch.get_partial_message(mid).edit(embed=leaderboard_embed(guild))
        except discord.NotFound:
            db.del_setting(guild.id, 'ca_board_message_id')
        except discord.HTTPException:
            pass

    ca = app_commands.Group(name='ca', description='CA raid leaderboard (turret breaks)', guild_only=True)

    @ca.command(name='turret-points', description='Admin: set how many points a turret type is worth')
    @admin_check()
    @app_commands.describe(turret='Turret type', points='Points per break (0 = counted but no points)',
                           custom_name='Only for "Custom": exact structure name, e.g. Tek Generator')
    @app_commands.choices(turret=[app_commands.Choice(name=label, value=pattern) for pattern, label in TURRETS]
                          + [app_commands.Choice(name='Custom structure name…', value='__custom__')])
    async def turret_points(self, i: discord.Interaction, turret: app_commands.Choice[str], points: app_commands.Range[int, 0, 100000],
                            custom_name: app_commands.Range[str, 2, 80] = None):
        if turret.value == '__custom__':
            if not custom_name:
                return await i.response.send_message('❌ Give the `custom_name`, e.g. `Tek Generator`.', ephemeral=True)
            pattern, label = custom_name.strip(), custom_name.strip()
        else:
            pattern, label = turret.value, turret.name
        with db.conn() as c:
            c.execute('INSERT OR REPLACE INTO ca_points(guild_id,pattern,label,points) VALUES(?,?,?,?)', (i.guild_id, pattern, label, points))
        await i.response.send_message(f'✅ **{label}** = `{points}` pts. The whole leaderboard uses the new value.', ephemeral=True)
        await self.refresh_board(i.guild)

    @ca.command(name='points-list', description='Show turret point values')
    async def points_list(self, i: discord.Interaction):
        rules = point_rules(i.guild_id)
        await i.response.send_message('\n'.join(f"**{r['label']}** — `{r['points']}` pts" for r in rules) or
                                      'No point values yet. Set them with `/ca turret-points`.', ephemeral=True)

    @ca.command(name='register', description='Admin: register a tribe for CA (counts breaks from now on)')
    @admin_check()
    @app_commands.describe(tribe='EXACT in-game tribe name, e.g. Tribe of N I X U S', leader='Optional Discord member who leads it')
    async def register(self, i: discord.Interaction, tribe: app_commands.Range[str, 1, 100], leader: discord.Member = None):
        name = ' '.join(tribe.split())
        if any(t['tribe_norm'] == norm(name) for t in tribes(i.guild_id)):
            return await i.response.send_message('❌ That tribe is already registered.', ephemeral=True)
        with db.conn() as c:
            c.execute('INSERT INTO ca_tribes(guild_id,tribe,tribe_norm,registered_at,leader_id) VALUES(?,?,?,?,?)',
                      (i.guild_id, name, norm(name), int(time.time()), leader.id if leader else None))
            seen = c.execute('SELECT COUNT(*) FROM ca_events WHERE attacker_norm=?', (norm(name),)).fetchone()[0]
        note = '' if seen else '\n-# I have not seen this tribe name in the logs yet. Double-check the spelling and spaces (it must match the game exactly).'
        await i.response.send_message(f'✅ **{name}** is CA registered. Enemy turrets they destroy from <t:{int(time.time())}:f> count.{note}', ephemeral=True)
        await self.refresh_board(i.guild)

    @ca.command(name='unregister', description='Admin: remove a tribe from CA')
    @admin_check()
    @app_commands.autocomplete(tribe=tribe_ac)
    async def unregister(self, i: discord.Interaction, tribe: str):
        with db.conn() as c:
            n = c.execute('DELETE FROM ca_tribes WHERE guild_id=? AND tribe_norm=?', (i.guild_id, norm(tribe))).rowcount
        await i.response.send_message('✅ Removed.' if n else '❌ That tribe is not registered.', ephemeral=True)
        await self.refresh_board(i.guild)

    @ca.command(name='tribes', description='List CA registered tribes')
    async def tribes_cmd(self, i: discord.Interaction):
        rows = tribes(i.guild_id)
        await i.response.send_message('\n'.join(f"**{t['tribe']}** · since <t:{t['registered_at']}:d>" + (f" · <@{t['leader_id']}>" if t['leader_id'] else '') for t in rows)
                                      or 'No tribes registered. `/ca register`.', ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @ca.command(name='leaderboard', description='Admin: post (or move) the auto-updating CA leaderboard')
    @admin_check()
    async def leaderboard(self, i: discord.Interaction, channel: discord.TextChannel):
        await i.response.defer(ephemeral=True)
        old_c = i.guild.get_channel(int(db.get_setting(i.guild_id, 'ca_board_channel_id', 0) or 0))
        old_m = int(db.get_setting(i.guild_id, 'ca_board_message_id', 0) or 0)
        msg = await channel.send(embed=leaderboard_embed(i.guild))
        db.set_setting(i.guild_id, 'ca_board_channel_id', channel.id)
        db.set_setting(i.guild_id, 'ca_board_message_id', msg.id)
        if old_c and old_m and old_m != msg.id:
            try: await old_c.get_partial_message(old_m).delete()
            except discord.HTTPException: pass
        await i.followup.send(f'✅ CA leaderboard posted in {channel.mention}. It updates itself after each scan.', ephemeral=True)

    @ca.command(name='log-channel', description='Admin: channel where every turret break is dumped')
    @admin_check()
    async def log_channel(self, i: discord.Interaction, channel: discord.TextChannel):
        db.set_setting(i.guild_id, 'ca_log_channel_id', channel.id)
        await i.response.send_message(f'✅ Turret breaks will be logged in {channel.mention}.', ephemeral=True)

    @ca.command(name='stats', description='Breakdown for one tribe')
    @app_commands.autocomplete(tribe=tribe_ac)
    async def stats(self, i: discord.Interaction, tribe: str):
        s = next((s for s in standings(i.guild_id) if norm(s['tribe']) == norm(tribe)), None)
        if not s:
            return await i.response.send_message('❌ That tribe is not registered.', ephemeral=True)
        detail = '\n'.join(f'{k}: ×{v}' for k, v in sorted(s['counts'].items(), key=lambda kv: -kv[1])) or 'No turret breaks yet.'
        await i.response.send_message(embed=discord.Embed(title=f"💥 {s['tribe']}", color=0x8A2BE2,
                                                          description=f"**{s['points']}** pts · {s['breaks']} breaks\n\n{detail}"), ephemeral=True)


async def setup(bot):
    await bot.add_cog(CACog(bot))

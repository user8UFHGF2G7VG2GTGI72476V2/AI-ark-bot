"""Hype events: a wipe/launch countdown post with a live hype counter,
automatic reminders (24h / 1h / 10min) and a "WE'RE LIVE" post when it hits zero."""
import json, time
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import emb, admin_check, parse_when


def init_tables():
    with db.conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS hype_events(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          channel_id INTEGER NOT NULL,
          message_id INTEGER,
          title TEXT NOT NULL,
          description TEXT,
          image TEXT,
          ping_role_id INTEGER,
          starts_at INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'active',
          reminders TEXT NOT NULL DEFAULT '[]',
          created_by INTEGER,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS hype_joins(
          event_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          at INTEGER NOT NULL,
          PRIMARY KEY(event_id,user_id)
        );
        """)

REMINDERS = [(86400, "24 hours"), (3600, "1 hour"), (600, "10 minutes")]
BAR = 12

def get_event(eid):
    with db.conn() as c:
        r = c.execute("SELECT * FROM hype_events WHERE id=?", (eid,)).fetchone()
    return dict(r) if r else None

def hype_count(eid):
    with db.conn() as c:
        return c.execute("SELECT COUNT(*) n FROM hype_joins WHERE event_id=?", (eid,)).fetchone()["n"]

def nametag_line(gid):
    try:
        from economy import nametag_cfg
    except Exception:
        return None
    cfg = nametag_cfg(gid)
    if not cfg["enabled"] or not cfg["tag"] or (cfg.get("ends_at") and time.time() > cfg["ends_at"]):
        return None
    return f"🏷️ Put **{cfg['tag']}** in your Discord name → get **{cfg['credits']} FREE credits** automatically!"

def hype_embed(ev):
    n = hype_count(ev["id"])
    goal = max(10, ((n // 25) + 1) * 25)
    filled = min(BAR, round(BAR * n / goal))
    live = ev["status"] == "live"
    ended = ev["status"] == "cancelled"
    title = ("🟢 " if live else "🔥 ") + ev["title"] + (" — LIVE NOW!" if live else "")
    e = discord.Embed(title=title[:256], description=ev.get("description") or None,
                      color=0x57F287 if live else (0x99AAB5 if ended else 0xE67E22))
    ts = ev["starts_at"]
    e.add_field(name="🟢 Started" if live else "⏰ Starts", value=f"<t:{ts}:F>\n**<t:{ts}:R>**", inline=True)
    e.add_field(name=f"🔥 Hype ({n})", value=f"`{'█' * filled}{'░' * (BAR - filled)}` {n}/{goal}", inline=True)
    tag = nametag_line(ev["guild_id"])
    if tag and not live:
        e.add_field(name="Free credits", value=tag, inline=False)
    if ev.get("image"):
        e.set_image(url=ev["image"])
    e.set_footer(text="Press 🔥 to show you're coming!" if not live and not ended else "Thanks for the hype!")
    return e

class HypeButton(discord.ui.DynamicItem[discord.ui.Button], template=r"hype:join:(?P<eid>\d+)"):
    def __init__(self, eid: int, disabled=False):
        super().__init__(discord.ui.Button(label="I'm Hyped!", emoji="🔥", style=discord.ButtonStyle.danger,
                                           custom_id=f"hype:join:{eid}", disabled=disabled))
        self.eid = eid

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls(int(match["eid"]))

    async def callback(self, i: discord.Interaction):
        ev = get_event(self.eid)
        if not ev or ev["status"] != "active":
            return await i.response.send_message("This hype event is over.", ephemeral=True)
        with db.conn() as c:
            r = c.execute("INSERT OR IGNORE INTO hype_joins(event_id,user_id,at) VALUES(?,?,?)", (self.eid, i.user.id, int(time.time())))
            joined = r.rowcount > 0
            if not joined:
                c.execute("DELETE FROM hype_joins WHERE event_id=? AND user_id=?", (self.eid, i.user.id))
        await i.response.edit_message(embed=hype_embed(ev), view=hype_view(self.eid))
        await i.followup.send("🔥 You're hyped! See you there." if joined else "You un-hyped 😢 (press again to re-join)", ephemeral=True)

def hype_view(eid, disabled=False):
    v = discord.ui.View(timeout=None)
    v.add_item(HypeButton(eid, disabled))
    return v

class HypeGroup(app_commands.Group):
    def __init__(self, cog):
        super().__init__(name="hype", description="Wipe / launch hype events", guild_only=True)
        self.cog = cog

    @app_commands.command(name="start", description="Admin: post a hype countdown (e.g. the wipe)")
    @admin_check()
    @app_commands.describe(when="Date/time in server timezone, e.g. 10/03 6:00PM", title="e.g. Iceden Wipe",
                           channel="Defaults to the channel set with /hype channel (or this one)", ping_role="Pinged for the post, reminders and go-live",
                           image="Banner image URL", description="Details: rates, map, what's new...")
    async def start(self, i: discord.Interaction, when: str, title: str = "SERVER WIPE", description: str = None,
                    channel: discord.TextChannel = None, ping_role: discord.Role = None, image: str = None):
        try:
            ts = parse_when(when)
        except ValueError as e:
            return await i.response.send_message(f"❌ {e}", ephemeral=True)
        if ts <= time.time():
            return await i.response.send_message("❌ That time is in the past.", ephemeral=True)
        if channel is None:
            channel = i.guild.get_channel(int(db.get_setting(i.guild.id, "hype_default_channel_id", 0) or 0)) or i.channel
        pre = [s for s, _ in REMINDERS if ts - time.time() <= s]  # skip reminders that already passed
        with db.conn() as c:
            cur = c.execute("""INSERT INTO hype_events(guild_id,channel_id,title,description,image,ping_role_id,starts_at,reminders,created_by,created_at)
                               VALUES(?,?,?,?,?,?,?,?,?,?)""",
                            (i.guild.id, channel.id, title[:200], (description or "").replace("\\n", "\n")[:3500] or None, image,
                             ping_role.id if ping_role else None, ts, json.dumps(pre), i.user.id, int(time.time())))
            eid = cur.lastrowid
        ev = get_event(eid)
        msg = await channel.send(content=ping_role.mention if ping_role else None, embed=hype_embed(ev), view=hype_view(eid),
                                 allowed_mentions=discord.AllowedMentions(roles=True, everyone=False))
        with db.conn() as c:
            c.execute("UPDATE hype_events SET message_id=? WHERE id=?", (msg.id, eid))
        await i.response.send_message(f"✅ Hype event **#{eid}** posted in {channel.mention} — goes live <t:{ts}:R>.", ephemeral=True)

    @app_commands.command(name="channel", description="Admin: default channel for hype posts")
    @admin_check()
    async def channel_cmd(self, i: discord.Interaction, channel: discord.TextChannel):
        db.set_setting(i.guild.id, "hype_default_channel_id", channel.id)
        await i.response.send_message(f"✅ Hype events post in {channel.mention} by default.", ephemeral=True)

    @app_commands.command(name="list", description="Active hype events")
    async def list_cmd(self, i: discord.Interaction):
        with db.conn() as c:
            rows = c.execute("SELECT * FROM hype_events WHERE guild_id=? AND status='active' ORDER BY starts_at", (i.guild.id,)).fetchall()
        lines = [f"`#{r['id']}` **{r['title']}** — <t:{r['starts_at']}:R> in <#{r['channel_id']}> • 🔥 {hype_count(r['id'])}" for r in rows]
        await i.response.send_message(embed=emb("🔥 Hype Events", "\n".join(lines) or "None running."), ephemeral=True)

    @app_commands.command(name="cancel", description="Admin: cancel a hype event")
    @admin_check()
    async def cancel(self, i: discord.Interaction, event_id: int):
        ev = get_event(event_id)
        if not ev or ev["guild_id"] != i.guild.id or ev["status"] != "active":
            return await i.response.send_message("❌ No active hype event with that number.", ephemeral=True)
        with db.conn() as c:
            c.execute("UPDATE hype_events SET status='cancelled' WHERE id=?", (event_id,))
        await self.cog.refresh(i.guild, get_event(event_id), disabled=True)
        await i.response.send_message("✅ Cancelled.", ephemeral=True)

    @app_commands.command(name="who", description="See who's hyped for an event")
    async def who(self, i: discord.Interaction, event_id: int):
        with db.conn() as c:
            rows = c.execute("""SELECT j.user_id FROM hype_joins j JOIN hype_events e ON e.id=j.event_id
                                WHERE j.event_id=? AND e.guild_id=? ORDER BY j.at""", (event_id, i.guild.id)).fetchall()
        await i.response.send_message(embed=emb(f"🔥 Hyped for #{event_id} ({len(rows)})", " ".join(f"<@{r['user_id']}>" for r in rows[:150])[:4000] or "Nobody yet."), ephemeral=True)

class HypeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        init_tables()
        self.group = HypeGroup(self)
        bot.tree.add_command(self.group, override=True)

    async def cog_load(self):
        self.bot.add_dynamic_items(HypeButton)
        self.tick.start()

    async def cog_unload(self):
        self.tick.cancel()
        try:
            self.bot.remove_dynamic_items(HypeButton)
        except Exception:
            pass
        self.bot.tree.remove_command("hype", type=discord.AppCommandType.chat_input)

    async def refresh(self, guild, ev, disabled=False):
        ch = guild.get_channel(ev["channel_id"])
        if isinstance(ch, discord.TextChannel) and ev.get("message_id"):
            try:
                await ch.get_partial_message(ev["message_id"]).edit(embed=hype_embed(ev), view=hype_view(ev["id"], disabled))
            except Exception:
                pass

    @tasks.loop(seconds=30)
    async def tick(self):
        now = time.time()
        with db.conn() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM hype_events WHERE status='active'").fetchall()]
        for ev in rows:
            g = self.bot.get_guild(ev["guild_id"])
            if not g:
                continue
            ch = g.get_channel(ev["channel_id"])
            if not isinstance(ch, discord.TextChannel):
                continue
            ping = f"<@&{ev['ping_role_id']}>" if ev.get("ping_role_id") else None
            am = discord.AllowedMentions(roles=True)
            sent = set(json.loads(ev.get("reminders") or "[]"))
            left = ev["starts_at"] - now
            if left <= 0:
                with db.conn() as c:
                    c.execute("UPDATE hype_events SET status='live' WHERE id=?", (ev["id"],))
                ev["status"] = "live"
                n = hype_count(ev["id"])
                e = emb(f"🚨 {ev['title']} IS LIVE! 🚨", f"It's time — get in there! 🦖\n🔥 **{n}** people were hyped.", 0x57F287)
                if ev.get("image"):
                    e.set_image(url=ev["image"])
                try:
                    await ch.send(content=ping, embed=e, allowed_mentions=am)
                except Exception:
                    pass
                await self.refresh(g, ev, disabled=True)
                continue
            due = [(secs, label) for secs, label in REMINDERS if left <= secs and secs not in sent]
            if due:
                sent.update(secs for secs, _ in due)
                with db.conn() as c:
                    c.execute("UPDATE hype_events SET reminders=? WHERE id=?", (json.dumps(sorted(sent)), ev["id"]))
                label = min(due)[1]
                try:
                    await ch.send(content=ping, embed=emb(f"⏰ {ev['title']} in {label}!",
                                  f"Goes live <t:{ev['starts_at']}:R>. 🔥 **{hype_count(ev['id'])}** hyped so far — press 🔥 on the post above!", 0xE67E22),
                                  allowed_mentions=am)
                except Exception:
                    pass
            # keep the countdown/hype bar fresh every ~5 min
            if int(now) // 30 % 10 == 0:
                await self.refresh(g, ev)

    @tick.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(HypeCog(bot))

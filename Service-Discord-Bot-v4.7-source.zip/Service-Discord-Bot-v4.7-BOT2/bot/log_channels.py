"""Provision private channels only for implemented and readable log sources."""
import asyncio
import io
import os
import discord
from discord import app_commands
from discord.ext import commands
import db
from ark_feed import DEFAULT_KILL, parse_kill
from nitrado_api import NitradoError, service_ids
from nitrado_discovery import discover_services
from nitrado_config import save_config
from log_sources import find_log

CHANNELS={
    'all':('📋・server-logs','Complete readable ARK log feed. Staff access only.'),
    'kills':('⚔️・kill-logs','Kill events matching the configured parser. Staff access only.'),
    'kd':('📊・kd-logs','Tracked kill/death totals from parsed kill events. Staff access only.'),
    'admin':('🛠️・admin-logs','Admin/cheat keyword matches from the server log. Staff access only.'),
    'joins':('🚪・join-leave-logs','Join/leave keyword matches from the server log. Staff access only.'),
}


def private_overwrites(guild,staff_role):
    if staff_role.is_default():
        raise NitradoError('Choose a staff role, not @everyone.')
    return {
        guild.default_role:discord.PermissionOverwrite(view_channel=False),
        staff_role:discord.PermissionOverwrite(view_channel=True,read_message_history=True,send_messages=False,create_public_threads=False,create_private_threads=False),
        guild.me:discord.PermissionOverwrite(view_channel=True,read_message_history=True,send_messages=True,embed_links=True,attach_files=True,manage_channels=True),
    }


def observed_routes(text,pattern):
    lines=text.splitlines()
    routes={'all'}
    if any(parse_kill(line,pattern) for line in lines): routes.add('kills')
    if any(any(word in line.casefold() for word in ('admin','cheat')) for line in lines): routes.add('admin')
    if any(any(word in line.casefold() for word in ('joined','left this ark','connected','disconnected')) for line in lines): routes.add('joins')
    return routes


class LogChannelsCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot
        self.locks=getattr(bot,'log_setup_locks',{})
        bot.log_setup_locks=self.locks

    async def category(self,guild,key,name,overwrites):
        saved=int(db.get_setting(guild.id,key,0) or 0)
        category=guild.get_channel(saved)
        if category is not None and not isinstance(category,discord.CategoryChannel):
            raise NitradoError('A saved log category ID no longer points to a category.')
        if category is None:
            category=await guild.create_category(name,overwrites=overwrites,reason='Staff-only log setup')
            db.set_setting(guild.id,key,category.id)
        else:
            await category.edit(overwrites=overwrites,reason='Restore staff-only log permissions')
        return category

    async def channel(self,guild,key,category,name,topic,overwrites):
        saved=int(db.get_setting(guild.id,key,0) or 0)
        channel=guild.get_channel(saved)
        if channel is not None and not isinstance(channel,discord.TextChannel):
            raise NitradoError('A saved log channel ID no longer points to a text channel.')
        if channel is None:
            channel=await guild.create_text_channel(name,category=category,topic=topic,overwrites=overwrites,reason='Staff-only log setup')
            db.set_setting(guild.id,key,channel.id)
        else:
            await channel.edit(category=category,topic=topic,overwrites=overwrites,reason='Restore staff-only log permissions')
        return channel

    @app_commands.command(name='logs-setup',description='Create private staff log channels and connect supported feeds')
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True)
    async def logs_setup(self,i:discord.Interaction,staff_role:discord.Role,service:str=None,file:app_commands.Range[str,1,500]=None):
        ids=service_ids()
        predeferred=False
        if not ids:
            token=os.getenv('NITRADO_TOKEN','').strip()
            if not token: raise NitradoError('No Nitrado token or servers are configured. Run /nitrado setup first, then /logs-setup. Game-log setup has not completed.')
            await i.response.defer(ephemeral=True)
            predeferred=True
            async with self.bot.nitrado_config_lock:
                discovered,discovery_notes=await discover_services(self.bot.nitrado_api,token)
                ids=list(discovered)
                save_config(token,ids)
                db.set_setting(i.guild_id,'nitrado_service',ids[0])
        if service or file or len(ids)<=1:
            if predeferred:
                embed=await self.setup_one(i,staff_role,service,file,predeferred=True)
                return await i.followup.send(embed=embed,ephemeral=True)
            return await self.setup_one(i,staff_role,service,file)
        private_overwrites(i.guild,staff_role)
        if not predeferred: await i.response.defer(ephemeral=True)
        results=[]
        for sid in ids:
            try:
                embed=await self.setup_one(i,staff_role,sid,None,predeferred=True)
                results.append(f'SERVICE {sid}\n{embed.description}')
            except (NitradoError,discord.HTTPException) as exc:
                results.append(f'SERVICE {sid}\n'+(str(exc) if isinstance(exc,NitradoError) else 'Discord channel setup failed. Check bot permissions.'))
        report='\n\n'.join(results)
        await i.followup.send(f'Checked {len(ids)} automatically discovered/configured services. See the setup report for created channels and sources needing attention.',file=discord.File(io.BytesIO(report.encode()),filename='log-setup.txt'),ephemeral=True)

    async def setup_one(self,i,staff_role,service=None,file=None,predeferred=False):
        overwrites=private_overwrites(i.guild,staff_role)
        lock=self.locks.setdefault(i.guild_id,asyncio.Lock())
        if lock.locked():
            if predeferred: raise NitradoError('Log setup is already running for this server.')
            return await i.response.send_message('Log setup is already running for this server.',ephemeral=True)
        if not predeferred: await i.response.defer(ephemeral=True)
        async with lock:
            # Explicit server input must validate before any Discord resources are created.
            api=self.bot.nitrado_api
            sid=None
            path=file
            notes=[]
            if service or file or service_ids():
                chosen=service or str(db.get_setting(i.guild_id,'nitrado_service','')) or (service_ids()[0] if service_ids() else None)
                sid=await api.service(i.guild_id,chosen)
                with db.conn() as c:
                    old=c.execute('SELECT * FROM ark_feed WHERE guild_id=? AND service=?',(i.guild_id,sid)).fetchone()
                if not path and old: path=old['path']
                if not path:
                    try: path=await find_log(api,sid)
                    except NitradoError as exc: notes.append(str(exc))
                if path:
                    if not path.lower().endswith(('.log','.txt')): raise NitradoError('Choose a readable .log or .txt file.')
                    feed=self.bot.get_cog('FeedCog')
                    try:
                        size=await feed.file_size(sid,path)
                        await api.log_tail(sid,path)
                    except NitradoError as exc:
                        notes.append(f'Could not read {path}: {exc}')
                        path=None
                if path:
                    pattern=old['kill_pattern'] if old and old['path']==path else DEFAULT_KILL
                    supported=set(CHANNELS)
                    verified=db.get_setting(i.guild_id,f'ark_verified_routes:{sid}',{})
                    if verified.get('path')==path and verified.get('pattern')==pattern:
                        supported.update(kind for kind in verified.get('kinds',[]) if kind in CHANNELS)
                else:
                    notes.append(f'Service {sid}: log connection blocked. The channels below are created, but cannot receive game events until the source is readable.')
            category=await self.category(i.guild,'staff_log_category','🛡️ STAFF LOGS',overwrites)
            transcript=await self.channel(i.guild,'staff_transcript_channel',category,'🎫・ticket-transcripts','Closed ticket transcripts and ticket close summaries. Staff access only.',overwrites)
            db.set_setting(i.guild_id,'ticket_log_channel_id',transcript.id)
            created=[transcript.mention]
            if sid:
                game_category=await self.category(i.guild,f'ark_log_category:{sid}',f'🛡️ ARK LOGS • {sid}',overwrites)
                destinations={}
                for kind,(name,topic) in CHANNELS.items():
                    channel=await self.channel(i.guild,f'ark_log_channel:{sid}:{kind}',game_category,name,topic,overwrites)
                    destinations[kind]=channel.id
                    created.append(channel.mention)
                if path:
                    feed.configure_feed(i.guild_id,sid,path,destinations['all'],{kind:cid for kind,cid in destinations.items() if kind!='all'},size,preserve=True)
                    db.set_setting(i.guild_id,f'ark_verified_routes:{sid}',{'path':path,'pattern':pattern,'kinds':sorted(supported)})
                    notes.append(f'Service {sid}: CONNECTED to {path}. All five destinations are wired. KD requires parsed kill events. Only new events are delivered; recent history is not reposted.')
                else:
                    with db.conn() as c: c.execute('UPDATE ark_feed SET ready=0 WHERE guild_id=? AND service=?',(i.guild_id,sid))
                    db.set_setting(i.guild_id,f'ark_pending_routes:{sid}',destinations)
                    for cid in destinations.values():
                        channel=i.guild.get_channel(cid)
                        await channel.send(embed=discord.Embed(title='Log source not connected',description='This channel is private and ready, but no game events can be delivered yet. Run /logs-setup again after fixing Nitrado log access, or specify file:FULL_LOG_PATH. See the setup report for the exact error.',color=0xE6A23C))
            if not sid: notes.append('Run /nitrado setup first to connect ARK server logs. Ticket transcripts are connected now.')
            description='\n'.join(created)+'\n\nOnly the selected staff role, the bot, and Discord administrators can view these channels. Staff channels are read-only.\n\n'+'\n'.join(notes)
            connected=bool(sid and path)
            embed=discord.Embed(title='Log channels connected' if connected else 'Log channels created — source not connected',description=description,color=0x5865F2 if connected else 0xE6A23C)
            embed.set_footer(text='Implemented feeds only • connected sources deliver new events automatically')
            if predeferred: return embed
            await i.followup.send(embed=embed,ephemeral=True)


async def setup(bot):
    await bot.add_cog(LogChannelsCog(bot))

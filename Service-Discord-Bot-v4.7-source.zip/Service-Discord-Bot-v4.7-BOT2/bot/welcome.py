import discord
from discord import app_commands
from discord.ext import commands
import db
from common import emb, color_int, admin_check, format_placeholders

DEFAULT = {
    "enabled": False,
    "channel_id": 0,
    "content": "Welcome {mention} to **{server}**!",
    "use_embed": True,
    "title": "Welcome!",
    "description": "Hey {mention}, welcome to **{server}**. You are member **#{member_count}**.",
    "color": "5865F2",
    "image": "",
    "thumbnail": "",
    "footer": "",
}

GOODBYE_DEFAULT = {
    "enabled": False,
    "channel_id": 0,
    "content": "",
    "use_embed": True,
    "title": "Goodbye!",
    "description": "**{user}** has left **{server}**. We now have **{member_count}** members.",
    "color": "ED4245",
    "image": "",
    "thumbnail": "",
    "footer": "",
    # Direct message sent to the person who left
    "send_dm": True,
    "dm_message": "Sorry to see you leave **{server}**, {user}! You're always welcome back.",
}

def cfg(gid, prefix="welcome"):
    base=(GOODBYE_DEFAULT if prefix=="goodbye" else DEFAULT).copy()
    saved=db.get_setting(gid,f"{prefix}_config",{}) or {}
    base.update(saved)
    return base

def make_embed(config, member):
    e=discord.Embed(
        title=format_placeholders(config.get("title",""),member) or None,
        description=format_placeholders(config.get("description",""),member) or None,
        color=color_int(config.get("color","5865F2"))
    )
    if config.get("image"): e.set_image(url=config["image"])
    thumb=config.get("thumbnail") or member.display_avatar.url
    if thumb: e.set_thumbnail(url=thumb)
    if config.get("footer"): e.set_footer(text=format_placeholders(config["footer"],member))
    return e

class WText(discord.ui.Modal):
    def __init__(self,view,key,label,style=discord.TextStyle.short,max_length=1000):
        super().__init__(title=f"Set {label}",timeout=600)
        self.v=view;self.key=key
        self.f=discord.ui.TextInput(label=label,style=style,max_length=max_length,required=False,default=str(view.data.get(key) or "")[:max_length] or None)
        self.add_item(self.f)
    async def on_submit(self,i):
        self.v.data[self.key]=str(self.f.value).strip()
        await i.response.edit_message(content=self.v.status_text(),embed=self.v.preview(i.user),view=self.v)

class WelcomeEditor(discord.ui.View):
    def __init__(self,gid,prefix,target_channel_id):
        super().__init__(timeout=900)
        self.gid=gid;self.prefix=prefix;self.target_channel_id=target_channel_id
        self.data=cfg(gid,prefix)
        if prefix=="goodbye":
            dm=discord.ui.Button(label="DM Message",style=discord.ButtonStyle.primary,row=3)
            async def dm_cb(i): await i.response.send_modal(WText(self,"dm_message","DM sent to the person who left",discord.TextStyle.paragraph,1800))
            dm.callback=dm_cb
            tog=discord.ui.Button(label="Toggle DM",style=discord.ButtonStyle.secondary,row=3)
            async def tog_cb(i):
                self.data["send_dm"]=not bool(self.data.get("send_dm",True))
                await i.response.edit_message(content=self.status_text(),embed=self.preview(i.user),view=self)
            tog.callback=tog_cb
            self.add_item(dm);self.add_item(tog)
    def status_text(self):
        t=f"Embed: **{'ON' if self.data.get('use_embed',True) else 'OFF'}**"
        if self.prefix=="goodbye":
            t+=f" • DM: **{'ON' if self.data.get('send_dm',True) else 'OFF'}**\nDM text: {self.data.get('dm_message') or '*(empty)*'}"
        return t
    def preview(self,member):
        e=make_embed(self.data,member)
        e.set_author(name=f"{self.prefix.title()} Preview")
        return e
    @discord.ui.button(label="Message",style=discord.ButtonStyle.primary,row=0)
    async def message(self,i,b): await i.response.send_modal(WText(self,"content","Normal Message",discord.TextStyle.paragraph,1800))
    @discord.ui.button(label="Title",style=discord.ButtonStyle.primary,row=0)
    async def title(self,i,b): await i.response.send_modal(WText(self,"title","Embed Title",max_length=256))
    @discord.ui.button(label="Description",style=discord.ButtonStyle.primary,row=0)
    async def description(self,i,b): await i.response.send_modal(WText(self,"description","Embed Description",discord.TextStyle.paragraph,4000))
    @discord.ui.button(label="Color",style=discord.ButtonStyle.primary,row=1)
    async def color(self,i,b): await i.response.send_modal(WText(self,"color","HEX Color",max_length=7))
    @discord.ui.button(label="Banner / Image",style=discord.ButtonStyle.primary,row=1)
    async def image(self,i,b): await i.response.send_modal(WText(self,"image","Banner / Image URL",max_length=1000))
    @discord.ui.button(label="Thumbnail",style=discord.ButtonStyle.primary,row=1)
    async def thumbnail(self,i,b): await i.response.send_modal(WText(self,"thumbnail","Thumbnail URL",max_length=1000))
    @discord.ui.button(label="Footer",style=discord.ButtonStyle.primary,row=1)
    async def footer(self,i,b): await i.response.send_modal(WText(self,"footer","Footer",max_length=1000))
    @discord.ui.button(label="Toggle Embed",style=discord.ButtonStyle.secondary,row=2)
    async def toggle(self,i,b):
        self.data["use_embed"]=not bool(self.data.get("use_embed",True))
        await i.response.edit_message(content=self.status_text(),embed=self.preview(i.user),view=self)
    @discord.ui.button(label="Save",style=discord.ButtonStyle.success,row=2)
    async def save(self,i,b):
        try: color_int(self.data.get("color"))
        except Exception as e:return await i.response.send_message(f"❌ {e}",ephemeral=True)
        self.data["enabled"]=True
        self.data["channel_id"]=self.target_channel_id or 0
        db.set_setting(self.gid,f"{self.prefix}_config",self.data)
        for x in self.children:x.disabled=True
        await i.response.edit_message(content=f"✅ {self.prefix.title()} configuration saved.",embed=self.preview(i.user),view=self)

class WelcomeGroup(app_commands.Group):
    def __init__(self,cog,prefix):
        super().__init__(name=prefix,description=f"{prefix.title()} messages")
        self.cog=cog;self.prefix=prefix

    @app_commands.command(name="edit",description="Open the visual message/embed editor")
    @admin_check()
    @app_commands.describe(channel="Channel to post in (goodbye: leave empty for DM only)")
    async def edit(self,i:discord.Interaction,channel:discord.TextChannel=None):
        if channel is None and self.prefix!="goodbye":
            return await i.response.send_message("❌ Pick a channel.",ephemeral=True)
        v=WelcomeEditor(i.guild.id,self.prefix,channel.id if channel else 0)
        extra="\nNo channel picked: only the DM will be sent." if channel is None else ""
        await i.response.send_message(
            "Placeholders: `{mention}` `{user}` `{server}` `{member_count}`\nEdit below, then press **Save**.\n"+v.status_text()+extra,
            embed=v.preview(i.user),view=v,ephemeral=True
        )

    @app_commands.command(name="test",description="Send a test message")
    @admin_check()
    async def test(self,i:discord.Interaction):
        data=cfg(i.guild.id,self.prefix)
        ch=i.guild.get_channel(int(data.get("channel_id") or 0))
        wants_dm=self.prefix=="goodbye" and data.get("send_dm") and data.get("dm_message")
        if not isinstance(ch,discord.TextChannel) and not wants_dm:return await i.response.send_message("❌ Configure a channel first.",ephemeral=True)
        done=[]
        if isinstance(ch,discord.TextChannel):
            content=format_placeholders(data.get("content",""),i.user)
            e=make_embed(data,i.user) if data.get("use_embed") else None
            await ch.send(content or None,embed=e)
            done.append(f"sent in {ch.mention}")
        if wants_dm:
            try:
                await i.user.send(format_placeholders(data["dm_message"],i.user)[:2000])
                done.append("DM sent to you")
            except discord.HTTPException:
                done.append("DM failed (your DMs from server members are off)")
        await i.response.send_message("✅ Test: "+", ".join(done)+".",ephemeral=True)

    @app_commands.command(name="disable",description="Disable messages")
    @admin_check()
    async def disable(self,i:discord.Interaction):
        data=cfg(i.guild.id,self.prefix);data["enabled"]=False
        db.set_setting(i.guild.id,f"{self.prefix}_config",data)
        await i.response.send_message(f"✅ {self.prefix.title()} messages disabled.",ephemeral=True)

    @app_commands.command(name="status",description="Show current configuration")
    async def status(self,i:discord.Interaction):
        data=cfg(i.guild.id,self.prefix)
        cid=int(data.get("channel_id") or 0)
        channel=f"<#{cid}>" if cid else "none"
        text=f"Enabled: **{bool(data.get('enabled'))}**\nChannel: {channel}\nEmbed: **{bool(data.get('use_embed'))}**"
        if self.prefix=="goodbye":
            text+=f"\nDM on leave: **{bool(data.get('send_dm'))}**"
        await i.response.send_message(
            embed=emb(f"{self.prefix.title()} Status",text),
            ephemeral=True
        )

class WelcomeCog(commands.Cog):
    def __init__(self,bot):
        self.bot=bot
        self.welcome=WelcomeGroup(self,"welcome")
        bot.tree.add_command(self.welcome)
        self.goodbye=WelcomeGroup(self,"goodbye")
        bot.tree.add_command(self.goodbye)

    async def send_configured(self,member,prefix):
        data=cfg(member.guild.id,prefix)
        if not data.get("enabled"):return
        ch=member.guild.get_channel(int(data.get("channel_id") or 0))
        if isinstance(ch,discord.TextChannel):
            try:
                await ch.send(
                    format_placeholders(data.get("content",""),member) or None,
                    embed=make_embed(data,member) if data.get("use_embed") else None
                )
            except Exception:pass
        if prefix=="goodbye" and data.get("send_dm") and data.get("dm_message"):
            # Discord only delivers this if the user still shares another server with the bot
            # and allows DMs; otherwise it fails quietly.
            try: await member.send(format_placeholders(data["dm_message"],member)[:2000])
            except Exception: pass

    @commands.Cog.listener()
    async def on_member_join(self,member):
        await self.send_configured(member,"welcome")

    @commands.Cog.listener()
    async def on_member_remove(self,member):
        if member.bot: return
        await self.send_configured(member,"goodbye")

    async def cog_unload(self):
        for name in ("welcome","goodbye"):
            try:self.bot.tree.remove_command(name,type=discord.AppCommandType.chat_input)
            except Exception:pass

async def setup(bot):
    await bot.add_cog(WelcomeCog(bot))

"""Xbox gamertag linking (Discord OAuth "connections") and the Kick Me button.

How linking works (the same way the big ARK bots do it):
 1. The player connects Xbox to Discord once: Discord Settings -> Connections -> Xbox.
 2. They press **Connect** on the Link Gamertag panel and approve on discord.com.
 3. Discord tells the bot which Xbox account is connected (gamertag + Xbox user ID).
    The player never types a gamertag, so nobody can link someone else's account.

That needs one public web address for Discord to send players back to (LINK_PUBLIC_URL)
plus the app's Client Secret. If those are not set, staff can enable manual linking: the
player types their gamertag and a staff member approves it in the log channel.

Kick Me finds the player's linked gamertag online on any configured Nitrado server and
kicks it. If Nitrado does not offer a direct kick for the platform, it bans and
immediately unbans (the usual console workaround). Unbans that fail are retried until
they succeed and staff are alerted.
"""
import asyncio
import html
import os
import secrets
import time
from urllib.parse import quote, urlencode
import aiohttp
from aiohttp import web
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import admin_check, staff_role
from nitrado_api import NitradoError, service_ids
import ark_services

DISCORD_API = 'https://discord.com/api/v10'
STATE_TTL = 600


def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS xbox_links(
          user_id INTEGER PRIMARY KEY,
          gamertag TEXT NOT NULL,
          xuid TEXT,
          method TEXT NOT NULL DEFAULT 'oauth',
          verified INTEGER NOT NULL DEFAULT 1,
          guild_id INTEGER,
          linked_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_xbox_links_tag ON xbox_links(lower(gamertag));
        CREATE TABLE IF NOT EXISTS xbox_pending_unbans(
          service TEXT NOT NULL,
          player_id TEXT NOT NULL,
          name TEXT,
          guild_id INTEGER,
          created INTEGER NOT NULL,
          attempts INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(service,player_id)
        );
        ''')


# ---------- link storage ----------

def get_link(user_id):
    with db.conn() as c:
        r = c.execute('SELECT * FROM xbox_links WHERE user_id=?', (int(user_id),)).fetchone()
    return dict(r) if r else None


def links_by_tag():
    """{normalised gamertag: user_id} for verified links (used by playtime rewards)."""
    with db.conn() as c:
        rows = c.execute('SELECT user_id,gamertag FROM xbox_links WHERE verified=1').fetchall()
    return {ark_services.norm_tag(r['gamertag']): r['user_id'] for r in rows}


def owner_of(gamertag, xuid=None):
    with db.conn() as c:
        rows = c.execute('SELECT * FROM xbox_links').fetchall()
    tag = ark_services.norm_tag(gamertag)
    for r in rows:
        if (xuid and r['xuid'] and str(r['xuid']) == str(xuid)) or ark_services.norm_tag(r['gamertag']) == tag:
            return dict(r)
    return None


def save_link(user_id, gamertag, xuid, method, verified, guild_id):
    with db.conn() as c:
        if verified:
            # A verified owner replaces anybody else's claim on the same Xbox account.
            for r in c.execute('SELECT user_id,gamertag,xuid FROM xbox_links WHERE user_id<>?', (int(user_id),)).fetchall():
                if (xuid and r['xuid'] and str(r['xuid']) == str(xuid)) or ark_services.norm_tag(r['gamertag']) == ark_services.norm_tag(gamertag):
                    c.execute('DELETE FROM xbox_links WHERE user_id=?', (r['user_id'],))
        c.execute('INSERT OR REPLACE INTO xbox_links(user_id,gamertag,xuid,method,verified,guild_id,linked_at) VALUES(?,?,?,?,?,?,?)',
                  (int(user_id), gamertag, xuid, method, 1 if verified else 0, guild_id, int(time.time())))
        if verified and guild_id:
            # Keep the prize-delivery gamertag (/link view) in sync.
            try:
                c.execute('INSERT OR REPLACE INTO player_links(guild_id,user_id,gamertag,linked_at) VALUES(?,?,?,?)',
                          (int(guild_id), int(user_id), gamertag, int(time.time())))
            except Exception:
                pass


def delete_link(user_id):
    with db.conn() as c:
        return c.execute('DELETE FROM xbox_links WHERE user_id=?', (int(user_id),)).rowcount


# ---------- config ----------

def public_url():
    return os.getenv('LINK_PUBLIC_URL', '').strip().rstrip('/')


def redirect_uri():
    return public_url() + '/callback' if public_url() else ''


def client_secret():
    return os.getenv('DISCORD_CLIENT_SECRET', '').strip()


def oauth_ready():
    return bool(public_url() and client_secret())


def cfg(gid):
    out = {'linked_role_id': 0, 'log_channel_id': 0, 'allow_manual': False, 'kick_cooldown': 300, 'kick_method': 'auto'}
    out.update(db.get_setting(gid, 'xbox_config', {}) or {})
    return out


def is_staff(member):
    if not isinstance(member, discord.Member):
        return False
    if member.id == member.guild.owner_id or member.guild_permissions.administrator:
        return True
    role = staff_role(member.guild)
    return bool(role and role in member.roles)


async def log(guild, *args, **kwargs):
    ch = guild.get_channel(int(cfg(guild.id).get('log_channel_id') or 0))
    if isinstance(ch, (discord.TextChannel, discord.Thread)):
        try:
            return await ch.send(*args, allowed_mentions=discord.AllowedMentions.none(), **kwargs)
        except discord.HTTPException:
            pass
    return None


async def give_linked_role(guild, user_id):
    rid = int(cfg(guild.id).get('linked_role_id') or 0)
    role = guild.get_role(rid) if rid else None
    member = guild.get_member(int(user_id))
    if role and member and role not in member.roles:
        try:
            await member.add_roles(role, reason='Linked Xbox gamertag')
        except discord.HTTPException:
            pass


def page(title, message, ok=True):
    color = '#8A2BE2' if ok else '#ED4245'
    icon = '✅' if ok else '⚠️'
    return web.Response(content_type='text/html', text=f'''<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>
<style>body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#1a1033;font-family:system-ui,Segoe UI,sans-serif;color:#eee}}
.card{{max-width:440px;margin:16px;padding:32px;border-radius:14px;background:#251a45;border-left:5px solid {color};box-shadow:0 10px 40px #0006}}
h1{{margin:0 0 12px;font-size:22px}}p{{line-height:1.5;color:#cfc8e8}}</style></head>
<body><div class="card"><h1>{icon} {html.escape(title)}</h1><p>{message}</p><p style="opacity:.6">You can close this tab and go back to Discord.</p></div></body></html>''')


# ---------- Kick Me helpers ----------

async def find_online(api, gamertag, xuid=None):
    """Return [(service, player)] for every server where this gamertag is online right now."""
    tag = ark_services.norm_tag(gamertag)

    async def check(sid):
        try:
            rows = await api.players(sid)
        except NitradoError:
            return []
        return [(sid, p) for p in rows if ark_services.is_online(p) and p.get('id') and (
            ark_services.norm_tag(p.get('name') or p.get('gamertag') or '') == tag or (xuid and str(p.get('id')) == str(xuid)))]
    results = await asyncio.gather(*(check(sid) for sid in service_ids()))
    return [hit for batch in results for hit in batch]


async def unban(api, sid, player_id):
    await api.request('DELETE', f'/services/{sid}/gameservers/games/banlist', payload={'identifier': [str(player_id)]})
    with db.conn() as c:
        c.execute('DELETE FROM xbox_pending_unbans WHERE service=? AND player_id=?', (sid, str(player_id)))


async def send_kick_command(api, sid, ids):
    """ARK's own console command, sent through Nitrado's 'send command to server' endpoint."""
    sent = False
    for ident in dict.fromkeys(str(x) for x in ids if x):
        await api.request('POST', f'/services/{sid}/gameservers/command', payload={'command': f'KickPlayer {ident}'})
        sent = True
    return sent


async def kick_player(api, sid, player, method='auto', guild_id=None, xuid=None):
    pid = str(player['id'])
    path = f"/services/{sid}/gameservers/games/players/{quote(pid, safe='')}"
    errors = []
    if method in ('auto', 'command'):
        try:
            if await send_kick_command(api, sid, [pid, xuid]):
                return 'command'
        except NitradoError as e:
            errors.append(f'command: {e}')
            if method == 'command':
                raise
    if method in ('auto', 'kick'):
        try:
            caps = await api.request('GET', path)
            actions = caps.get('player_actions', []) if isinstance(caps, dict) else []
            if isinstance(actions, list) and any(a == 'kick' or isinstance(a, dict) and a.get('type') == 'kick' for a in actions):
                await api.request('GET', path, params={'type': 'kick'})
                return 'kick'
            errors.append('kick: not offered')
        except NitradoError as e:
            errors.append(f'kick: {e}')
            if method == 'kick':
                raise
        if method == 'kick':
            raise NitradoError('Nitrado does not offer a direct kick on this server. Set `/xbox setup kick_method:Auto`.')
    # Ban -> short wait -> unban. Record the unban first so a crash can never leave them banned.
    with db.conn() as c:
        c.execute('INSERT OR REPLACE INTO xbox_pending_unbans(service,player_id,name,guild_id,created,attempts) VALUES(?,?,?,?,?,0)',
                  (sid, pid, player.get('name'), guild_id, int(time.time())))
    try:
        await api.request('POST', f'/services/{sid}/gameservers/games/banlist', payload={'identifier': [pid]})
    except NitradoError as e:
        with db.conn() as c:
            c.execute('DELETE FROM xbox_pending_unbans WHERE service=? AND player_id=?', (sid, pid))
        if errors:
            raise NitradoError('No kick method works on this server (' + '; '.join(errors + [f'ban: {e}']) + ')') from None
        raise
    try:
        delay = max(3, min(60, int(os.getenv('KICK_UNBAN_DELAY', '10'))))
    except ValueError:
        delay = 10
    await asyncio.sleep(delay)
    try:
        await unban(api, sid, pid)
    except NitradoError:
        pass  # the retry loop keeps trying and alerts staff
    return 'ban-unban'


# ---------- persistent buttons ----------

class ConnectButton(discord.ui.DynamicItem[discord.ui.Button], template=r'xl:connect'):
    def __init__(self):
        super().__init__(discord.ui.Button(label='Connect', style=discord.ButtonStyle.primary, custom_id='xl:connect'))

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls()

    async def callback(self, i: discord.Interaction):
        cog = i.client.get_cog('XboxLinkCog')
        if cog:
            await cog.start_link(i)


class KickButton(discord.ui.DynamicItem[discord.ui.Button], template=r'xl:kick'):
    def __init__(self):
        super().__init__(discord.ui.Button(label='Kick Me', style=discord.ButtonStyle.primary, custom_id='xl:kick'))

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls()

    async def callback(self, i: discord.Interaction):
        cog = i.client.get_cog('XboxLinkCog')
        if cog:
            await cog.kick_me(i)


class ManualButton(discord.ui.DynamicItem[discord.ui.Button], template=r'xl:manual'):
    def __init__(self):
        super().__init__(discord.ui.Button(label='Type my gamertag instead', style=discord.ButtonStyle.secondary, custom_id='xl:manual'))

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls()

    async def callback(self, i: discord.Interaction):
        if not cfg(i.guild_id).get('allow_manual'):
            return await i.response.send_message('Manual linking is turned off on this server.', ephemeral=True)
        await i.response.send_modal(ManualModal())


class ReviewButton(discord.ui.DynamicItem[discord.ui.Button], template=r'xl:(?P<action>ok|no):(?P<uid>\d+)'):
    def __init__(self, action, uid):
        self.action, self.uid = action, int(uid)
        super().__init__(discord.ui.Button(label='Approve' if action == 'ok' else 'Deny',
                                           style=discord.ButtonStyle.success if action == 'ok' else discord.ButtonStyle.danger,
                                           custom_id=f'xl:{action}:{uid}'))

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls(match['action'], match['uid'])

    async def callback(self, i: discord.Interaction):
        if not is_staff(i.user):
            return await i.response.send_message('Only staff can review links.', ephemeral=True)
        link = get_link(self.uid)
        if not link or link['verified']:
            return await i.response.edit_message(content='This request was already handled.', view=None)
        if self.action == 'ok':
            save_link(self.uid, link['gamertag'], link['xuid'], 'manual', True, i.guild_id)
            await give_linked_role(i.guild, self.uid)
            text = f'✅ <@{self.uid}> → **{discord.utils.escape_markdown(link["gamertag"])}** approved by {i.user.mention}.'
            note = f'✅ Your gamertag **{link["gamertag"]}** was approved in **{i.guild.name}**. Kick Me is ready to use.'
        else:
            delete_link(self.uid)
            text = f'❌ <@{self.uid}> → **{discord.utils.escape_markdown(link["gamertag"])}** denied by {i.user.mention}.'
            note = f'❌ Your gamertag link request in **{i.guild.name}** was denied. Ask staff if you think this is a mistake.'
        await i.response.edit_message(content=text, view=None, allowed_mentions=discord.AllowedMentions.none())
        member = i.guild.get_member(self.uid)
        if member:
            try: await member.send(note)
            except discord.HTTPException: pass


class ManualModal(discord.ui.Modal, title='Link your gamertag'):
    gamertag = discord.ui.TextInput(label='Your Xbox gamertag (exactly as in game)', min_length=1, max_length=40)

    async def on_submit(self, i: discord.Interaction):
        tag = self.gamertag.value.strip()
        owner = owner_of(tag)
        if owner and owner['user_id'] != i.user.id and owner['verified']:
            return await i.response.send_message('❌ That gamertag is already linked to another Discord account. Open a ticket if it is yours.', ephemeral=True)
        conf = cfg(i.guild_id)
        channel = i.guild.get_channel(int(conf.get('log_channel_id') or 0))
        if not channel:
            return await i.response.send_message('❌ Staff have not set a link review channel yet (`/xbox setup log_channel`).', ephemeral=True)
        save_link(i.user.id, tag, None, 'manual', False, i.guild_id)
        view = discord.ui.View(timeout=None)
        view.add_item(ReviewButton('ok', i.user.id))
        view.add_item(ReviewButton('no', i.user.id))
        try:
            await channel.send(f'🔗 **Gamertag link request** — {i.user.mention} says they are **{discord.utils.escape_markdown(tag)}**.', view=view,
                               allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            return await i.response.send_message('❌ I could not post to the review channel. Tell staff to check my permissions.', ephemeral=True)
        await i.response.send_message(f'⏳ Sent **{tag}** to staff for approval. You will get a DM when it is approved.', ephemeral=True)


# ---------- the cog ----------

class XboxLinkCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api = bot.nitrado_api
        self.pending = {}
        self.cooldowns = {}
        self.runner = None
        self.session = None
        self.web_error = None
        init_tables()

    async def cog_load(self):
        self.bot.add_dynamic_items(ConnectButton, KickButton, ManualButton, ReviewButton)
        await self.start_web()
        self.unban_loop.start()

    async def cog_unload(self):
        self.bot.remove_dynamic_items(ConnectButton, KickButton, ManualButton, ReviewButton)
        self.unban_loop.cancel()
        if self.runner:
            await self.runner.cleanup()
        if self.session:
            await self.session.close()

    # ----- web server for the Discord OAuth callback -----
    async def start_web(self):
        if not public_url():
            return
        app = web.Application()
        app.router.add_get('/', self.web_index)
        app.router.add_get('/callback', self.web_callback)
        self.runner = web.AppRunner(app, access_log=None)
        await self.runner.setup()
        try:
            port = int(os.getenv('LINK_PORT', '8080'))
            await web.TCPSite(self.runner, os.getenv('LINK_HOST', '0.0.0.0'), port).start()
            print(f'Xbox link web server listening on port {port} -> {redirect_uri()}')
        except (OSError, ValueError) as e:
            self.web_error = f'{type(e).__name__}: {e}'
            print(f'Xbox link web server could not start: {self.web_error}')
            await self.runner.cleanup()
            self.runner = None

    async def http(self):
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20))
        return self.session

    async def web_index(self, request):
        return page('Link server online', 'This page handles gamertag linking for the Discord bot.')

    async def web_callback(self, request):
        state = request.query.get('state', '')
        pending = self.pending.pop(state, None)
        if not pending or time.time() - pending['created'] > STATE_TTL:
            return page('Link expired', 'This link is old or was already used. Press <b>Connect</b> in Discord again.', False)
        if request.query.get('error'):
            return page('Cancelled', 'You cancelled the Discord approval. Press <b>Connect</b> again whenever you are ready.', False)
        code = request.query.get('code', '')
        if not code:
            return page('Something went wrong', 'Discord did not send an approval code. Press <b>Connect</b> again.', False)
        session = await self.http()
        try:
            client_id = str(self.bot.application_id)
            async with session.post(f'{DISCORD_API}/oauth2/token', data={'grant_type': 'authorization_code', 'code': code, 'redirect_uri': redirect_uri()},
                                    auth=aiohttp.BasicAuth(client_id, client_secret())) as r:
                if r.status != 200:
                    print(f'Xbox link: token exchange failed HTTP {r.status}. Check DISCORD_CLIENT_SECRET and the redirect URL in the Developer Portal.')
                    return page('Could not verify', 'Discord refused the approval. Staff: check the Client Secret and Redirect URL (<code>/xbox status</code>).', False)
                token = (await r.json()).get('access_token')
            headers = {'Authorization': f'Bearer {token}'}
            async with session.get(f'{DISCORD_API}/users/@me', headers=headers) as r:
                me = await r.json()
            async with session.get(f'{DISCORD_API}/users/@me/connections', headers=headers) as r:
                connections = await r.json() if r.status == 200 else []
            try:
                async with session.post(f'{DISCORD_API}/oauth2/token/revoke', data={'token': token, 'token_type_hint': 'access_token'},
                                        auth=aiohttp.BasicAuth(client_id, client_secret())):
                    pass
            except aiohttp.ClientError:
                pass
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
            return page('Discord is not responding', 'Try pressing <b>Connect</b> again in a minute.', False)

        if str(me.get('id')) != str(pending['user_id']):
            return page('Wrong Discord account', 'You approved with a different Discord account than the one that pressed Connect. Log in to the right account and try again.', False)
        xbox = [c for c in connections if isinstance(c, dict) and c.get('type') == 'xbox']
        if not xbox:
            await self.finish(pending, None, '❌ No Xbox account is connected to your Discord. Open **Discord Settings → Connections → Xbox**, connect it, then press **Connect** again.')
            return page('No Xbox account found', 'Open <b>Discord Settings → Connections</b>, add your <b>Xbox</b> account, then press <b>Connect</b> in Discord again.', False)
        xbox = sorted(xbox, key=lambda c: not c.get('verified'))[0]
        gamertag, xuid = str(xbox.get('name') or '').strip(), str(xbox.get('id') or '').strip() or None
        guild = self.bot.get_guild(pending['guild_id'])
        save_link(pending['user_id'], gamertag, xuid, 'oauth', True, pending['guild_id'])
        if guild:
            await give_linked_role(guild, pending['user_id'])
            await log(guild, f'🔗 <@{pending["user_id"]}> linked Xbox **{discord.utils.escape_markdown(gamertag)}** (verified via Discord).')
        await self.finish(pending, gamertag, f'✅ Linked to **{discord.utils.escape_markdown(gamertag)}**! Kick Me and playtime rewards are ready.')
        return page('Gamertag linked', f'Your Discord is now linked to <b>{html.escape(gamertag)}</b>.')

    async def finish(self, pending, gamertag, message):
        interaction = pending.get('interaction')
        if interaction:
            try:
                await interaction.edit_original_response(content=message, embed=None, view=None)
            except discord.HTTPException:
                pass

    # ----- Connect button -----
    async def start_link(self, i: discord.Interaction):
        conf = cfg(i.guild_id)
        current = get_link(i.user.id)
        status = ''
        if current:
            status = f"You're currently linked to **{discord.utils.escape_markdown(current['gamertag'])}**" + ('' if current['verified'] else ' (waiting for staff approval)') + '.\n\n'
        if not oauth_ready() or (public_url() and not self.runner):
            if conf.get('allow_manual'):
                return await i.response.send_modal(ManualModal())
            return await i.response.send_message('Linking is not set up yet. Staff: run `/xbox status` for the steps.', ephemeral=True)
        now = time.time()
        for key in [k for k, v in self.pending.items() if now - v['created'] > STATE_TTL]:
            self.pending.pop(key, None)
        state = secrets.token_urlsafe(24)
        self.pending[state] = {'user_id': i.user.id, 'guild_id': i.guild_id, 'created': now, 'interaction': i}
        url = 'https://discord.com/oauth2/authorize?' + urlencode({
            'response_type': 'code', 'client_id': str(self.bot.application_id), 'scope': 'identify connections',
            'redirect_uri': redirect_uri(), 'state': state, 'prompt': 'consent'})
        view = discord.ui.View(timeout=STATE_TTL)
        view.add_item(discord.ui.Button(label='Authorise with Discord', url=url, emoji='🔗'))
        if conf.get('allow_manual'):
            view.add_item(ManualButton())
        e = discord.Embed(title='Link your Xbox gamertag', color=0x8A2BE2, description=status +
                          '1. Make sure Xbox is connected in **Discord Settings → Connections**.\n'
                          '2. Press **Authorise with Discord** below and approve.\n'
                          '3. Come back here — this message updates when you are linked.\n\n'
                          '-# We only read your connected accounts. We never see your password. The link expires in 10 minutes.')
        await i.response.send_message(embed=e, view=view, ephemeral=True)

    # ----- Kick Me button -----
    async def kick_me(self, i: discord.Interaction):
        link = get_link(i.user.id)
        if not link:
            return await i.response.send_message('❌ Link your gamertag first — press **Connect** on the Link Gamertag panel.', ephemeral=True)
        if not link['verified']:
            return await i.response.send_message('⏳ Your gamertag link is still waiting for staff approval.', ephemeral=True)
        conf = cfg(i.guild_id)
        wait = int(conf.get('kick_cooldown') or 0) - (time.time() - self.cooldowns.get(i.user.id, 0))
        if wait > 0:
            return await i.response.send_message(f'⏳ You can use Kick Me again <t:{int(time.time() + wait)}:R>.', ephemeral=True)
        if not service_ids():
            return await i.response.send_message('❌ No Nitrado servers are linked yet. Staff: run `/linknitrado`.', ephemeral=True)
        await i.response.defer(ephemeral=True, thinking=True)
        hits = await find_online(self.api, link['gamertag'], link['xuid'])
        if not hits:
            return await i.followup.send(f"❌ **{discord.utils.escape_markdown(link['gamertag'])}** isn't showing as online on any of our servers.\n"
                                         "If you're stuck on a loading screen, wait a minute and press Kick Me again.", ephemeral=True)
        self.cooldowns[i.user.id] = time.time()
        done, failed = [], []
        for sid, player in hits:
            try:
                how = await kick_player(self.api, sid, player, conf.get('kick_method', 'auto'), i.guild_id, link.get('xuid'))
                done.append((sid, how))
            except NitradoError as e:
                failed.append((sid, str(e)))
        names = ', '.join(f'**{ark_services.name(sid)}**' for sid, _ in done)
        if done:
            await i.followup.send(f'✅ Kicked **{discord.utils.escape_markdown(link["gamertag"])}** from {names}. You can rejoin in a few seconds.', ephemeral=True)
            await log(i.guild, f'👢 Kick Me: {i.user.mention} (**{discord.utils.escape_markdown(link["gamertag"])}**) from {names} · method: {", ".join(h for _, h in done)}')
        if failed:
            if not done:
                self.cooldowns.pop(i.user.id, None)
            await i.followup.send('❌ Nitrado would not kick you: ' + '; '.join(f'{ark_services.name(s)}: {e}' for s, e in failed)[:1800], ephemeral=True)

    @tasks.loop(seconds=30)
    async def unban_loop(self):
        with db.conn() as c:
            rows = c.execute('SELECT * FROM xbox_pending_unbans WHERE created<=?', (int(time.time()) - 20,)).fetchall()
        for r in rows:
            try:
                await unban(self.api, r['service'], r['player_id'])
            except NitradoError:
                with db.conn() as c:
                    c.execute('UPDATE xbox_pending_unbans SET attempts=attempts+1 WHERE service=? AND player_id=?', (r['service'], r['player_id']))
                if r['attempts'] in (2, 20) and r['guild_id']:
                    guild = self.bot.get_guild(r['guild_id'])
                    if guild:
                        await log(guild, f'⚠️ Kick Me could not unban **{discord.utils.escape_markdown(r["name"] or r["player_id"])}** on {ark_services.name(r["service"])} yet. '
                                         f'Still retrying — you can also run `/nitrado unban`.')

    @unban_loop.before_loop
    async def before_unban(self):
        await self.bot.wait_until_ready()

    # ----- /xbox commands -----
    xbox = app_commands.Group(name='xbox', description='Xbox gamertag linking and Kick Me', guild_only=True)

    @xbox.command(name='setup', description='Admin: linked role, review/log channel, manual linking and Kick Me options')
    @admin_check()
    @app_commands.describe(linked_role='Role given to everyone who links', log_channel='Staff channel for link logs, Kick Me logs and manual approvals',
                           allow_manual='Let players type a gamertag for staff to approve (use if the web link is not set up)',
                           kick_cooldown_minutes='How often one player can use Kick Me', kick_method='How Kick Me removes the player')
    @app_commands.choices(kick_method=[app_commands.Choice(name='Auto (KickPlayer command, then kick, then ban+unban)', value='auto'),
                                       app_commands.Choice(name='KickPlayer server command only', value='command'),
                                       app_commands.Choice(name='Nitrado kick only', value='kick'),
                                       app_commands.Choice(name='Ban + instant unban', value='banunban')])
    async def setup(self, i: discord.Interaction, linked_role: discord.Role = None, log_channel: discord.TextChannel = None,
                    allow_manual: bool = None, kick_cooldown_minutes: app_commands.Range[int, 0, 1440] = None,
                    kick_method: app_commands.Choice[str] = None):
        conf = cfg(i.guild_id)
        if linked_role:
            if linked_role.is_default() or linked_role >= i.guild.me.top_role:
                return await i.response.send_message('❌ Pick a role below my highest role (not @everyone).', ephemeral=True)
            conf['linked_role_id'] = linked_role.id
        if log_channel: conf['log_channel_id'] = log_channel.id
        if allow_manual is not None: conf['allow_manual'] = allow_manual
        if kick_cooldown_minutes is not None: conf['kick_cooldown'] = kick_cooldown_minutes * 60
        if kick_method: conf['kick_method'] = kick_method.value
        db.set_setting(i.guild_id, 'xbox_config', conf)
        role = i.guild.get_role(int(conf['linked_role_id'] or 0))
        log_text = '<#%s>' % conf['log_channel_id'] if conf['log_channel_id'] else 'none'
        await i.response.send_message(
            f"✅ Saved.\nLinked role: {role.mention if role else 'none'}\nLog channel: {log_text}\n"
            f"Manual linking: {'on' if conf['allow_manual'] else 'off'}\nKick Me cooldown: {conf['kick_cooldown'] // 60} min · method: {conf['kick_method']}",
            ephemeral=True)

    @xbox.command(name='status', description='Admin: check the linking setup and show what is missing')
    @admin_check()
    async def status(self, i: discord.Interaction):
        ok, bad = '✅', '❌'
        lines = [
            f"{ok if public_url() else bad} **LINK_PUBLIC_URL** in .env: `{public_url() or 'not set'}`",
            f"{ok if client_secret() else bad} **DISCORD_CLIENT_SECRET** in .env: {'set' if client_secret() else 'not set'}",
            f"{ok if self.runner else bad} Web server: {'running on port ' + os.getenv('LINK_PORT', '8080') if self.runner else (self.web_error or 'not running (needs LINK_PUBLIC_URL)')}",
            f"{ok if service_ids() else bad} Nitrado servers linked: {len(service_ids())}",
        ]
        conf = cfg(i.guild_id)
        lines.append(f"{'✅' if conf['allow_manual'] else '➖'} Manual linking: {'on' if conf['allow_manual'] else 'off'}")
        with db.conn() as c:
            n = c.execute('SELECT COUNT(*) FROM xbox_links WHERE verified=1').fetchone()[0]
        lines.append(f'🔗 Verified links: **{n}**')
        steps = (f"\n**Finish setup (one time):**\n1. Discord Developer Portal → your bot → **OAuth2** → **Redirects** → add\n`{redirect_uri() or 'https://YOUR-ADDRESS/callback'}`\n"
                 "2. Copy **Client Secret** from the same page into `.env` as `DISCORD_CLIENT_SECRET=`\n"
                 "3. Set `LINK_PUBLIC_URL=` to the public address that reaches this PC on `LINK_PORT` (see the setup guide: Cloudflare Tunnel is free).\n"
                 "4. Restart the bot, then run this again.")
        await i.response.send_message('\n'.join(lines) + ('' if oauth_ready() and self.runner else steps), ephemeral=True)

    @xbox.command(name='lookup', description='Staff: see who a gamertag belongs to, or a member\'s gamertag')
    async def lookup(self, i: discord.Interaction, member: discord.Member = None, gamertag: str = None):
        if not is_staff(i.user):
            return await i.response.send_message('❌ Staff only.', ephemeral=True)
        if member:
            link = get_link(member.id)
            text = (f"{member.mention} → **{discord.utils.escape_markdown(link['gamertag'])}** · {'verified' if link['verified'] else 'pending'} · "
                    f"{link['method']} · linked <t:{link['linked_at']}:R>" + (f" · XUID `{link['xuid']}`" if link['xuid'] else '')) if link else f'{member.mention} has not linked.'
        elif gamertag:
            link = owner_of(gamertag)
            text = f"**{discord.utils.escape_markdown(gamertag)}** → <@{link['user_id']}> ({'verified' if link['verified'] else 'pending'})" if link else 'Nobody has linked that gamertag.'
        else:
            text = 'Give a member or a gamertag.'
        await i.response.send_message(text, ephemeral=True)

    @xbox.command(name='force-link', description='Staff: link a member to a gamertag (counts as verified)')
    async def force_link(self, i: discord.Interaction, member: discord.Member, gamertag: app_commands.Range[str, 1, 40]):
        if not is_staff(i.user):
            return await i.response.send_message('❌ Staff only.', ephemeral=True)
        save_link(member.id, gamertag.strip(), None, 'staff', True, i.guild_id)
        await give_linked_role(i.guild, member.id)
        await log(i.guild, f'🔗 {i.user.mention} linked {member.mention} → **{discord.utils.escape_markdown(gamertag)}** (staff).')
        await i.response.send_message(f'✅ {member.mention} → **{discord.utils.escape_markdown(gamertag)}**', ephemeral=True)

    @xbox.command(name='unlink', description='Staff: remove a member\'s gamertag link')
    async def unlink(self, i: discord.Interaction, member: discord.Member):
        if not is_staff(i.user):
            return await i.response.send_message('❌ Staff only.', ephemeral=True)
        n = delete_link(member.id)
        await i.response.send_message('✅ Unlinked.' if n else 'They were not linked.', ephemeral=True)

    @xbox.command(name='me', description='See which gamertag your Discord is linked to')
    async def me(self, i: discord.Interaction):
        link = get_link(i.user.id)
        await i.response.send_message(f"🎮 Linked to **{discord.utils.escape_markdown(link['gamertag'])}**" + ('' if link['verified'] else ' (waiting for approval)')
                                      if link else 'You have not linked a gamertag yet. Press **Connect** on the Link Gamertag panel.', ephemeral=True)

    @xbox.command(name='unlink-me', description='Remove your own gamertag link')
    async def unlink_me(self, i: discord.Interaction):
        n = delete_link(i.user.id)
        await i.response.send_message('✅ Your gamertag was unlinked.' if n else 'You were not linked.', ephemeral=True)


async def setup(bot):
    await bot.add_cog(XboxLinkCog(bot))

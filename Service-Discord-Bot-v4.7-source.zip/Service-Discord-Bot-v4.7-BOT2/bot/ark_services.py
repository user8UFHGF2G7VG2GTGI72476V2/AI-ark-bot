"""Shared, cached facts about the configured Nitrado ASE services (name, map, status).

Not an extension: imported by playtime, notifiers and xbox_link. The cache lives in the
settings table under guild 0 so it survives restarts and module reloads.
"""
import re
import time
import discord
from discord import app_commands
import db
from nitrado_api import NitradoError, service_ids

MAP_NAMES = {
    'theisland': 'The Island', 'thecenter': 'The Center', 'scorchedearth': 'Scorched Earth',
    'scorchedearthp': 'Scorched Earth', 'ragnarok': 'Ragnarok', 'aberration': 'Aberration',
    'aberrationp': 'Aberration', 'extinction': 'Extinction', 'valguero': 'Valguero',
    'valguerop': 'Valguero', 'genesis': 'Genesis', 'gen1': 'Genesis', 'genesis2': 'Genesis 2',
    'gen2': 'Genesis 2', 'crystalisles': 'Crystal Isles', 'lostisland': 'Lost Island',
    'fjordur': 'Fjordur', 'tunguska': 'Tunguska',
}
REFRESH_SECONDS = 1800


def pretty_map(raw):
    raw = str(raw or '').strip()
    if not raw:
        return 'Unknown map'
    key = re.sub(r'[^a-z0-9]', '', raw.casefold())
    if key not in MAP_NAMES and key.endswith('p') and key[:-1] in MAP_NAMES:
        key = key[:-1]
    if key in MAP_NAMES:
        return MAP_NAMES[key]
    # "TheIsland" -> "The Island", "Genesis2" -> "Genesis 2"
    spaced = re.sub(r'(?<=[a-z])(?=[A-Z0-9])', ' ', raw.replace('_P', '').replace('_', ' '))
    return spaced.strip() or raw


def info(sid):
    return db.get_setting(0, f'svc_info:{sid}', {}) or {}


def name(sid):
    return info(sid).get('name') or f'Server {sid}'


def map_name(sid):
    return info(sid).get('map') or 'Unknown map'


def remember(sid, details):
    q = details.get('query', {}) if isinstance(details, dict) else {}
    settings = details.get('settings', {}) if isinstance(details, dict) else {}
    cfg = settings.get('config', {}) if isinstance(settings, dict) else {}
    raw_map = q.get('map') or (cfg.get('map') if isinstance(cfg, dict) else None)
    current = info(sid)
    current.update({
        'name': q.get('server_name') or current.get('name') or f'Server {sid}',
        'map': pretty_map(raw_map) if raw_map else current.get('map') or 'Unknown map',
        'status': details.get('status', current.get('status', 'unknown')),
        'players': q.get('player_current'),
        'max': q.get('player_max'),
        'updated': int(time.time()),
    })
    db.set_setting(0, f'svc_info:{sid}', current)
    return current


async def refresh(api, sid, force=False):
    current = info(sid)
    if not force and time.time() - int(current.get('updated', 0) or 0) < REFRESH_SECONDS:
        return current
    try:
        return remember(sid, await api.details(sid))
    except NitradoError:
        return current


async def refresh_all(api, force=False):
    for sid in service_ids():
        await refresh(api, sid, force)


async def service_autocomplete(i: discord.Interaction, current: str):
    current = (current or '').casefold()
    out = []
    for sid in service_ids():
        label = f'{name(sid)} · {map_name(sid)} ({sid})'
        if current in label.casefold():
            out.append(app_commands.Choice(name=label[:100], value=sid))
    return out[:25]


def is_online(player):
    return str(player.get('online', '')).casefold() in ('true', '1')


def norm_tag(value):
    """Gamertags compare case-insensitively; new-style '#1234' suffixes are optional."""
    value = str(value or '').strip().casefold()
    return re.sub(r'#\d{3,5}$', '', value).strip()


def fmt_duration(seconds):
    seconds = int(seconds or 0)
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m = rem // 60
    if d:
        return f'{d}d {h}h {m}m'
    if h:
        return f'{h}h {m}m'
    return f'{m}m'

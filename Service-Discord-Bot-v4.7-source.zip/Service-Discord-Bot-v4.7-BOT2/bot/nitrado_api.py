import asyncio
import os
import time
from urllib.parse import urlparse
import aiohttp
from discord import app_commands
import db

BASE='https://api.nitrado.net'


class NitradoError(app_commands.CheckFailure):
    pass


def service_ids():
    return [s.strip() for s in os.getenv('NITRADO_SERVICE_IDS','').split(',') if s.strip().isdigit()]


def resolve_name(rows,name):
    matches=[p for p in rows if any(str(p.get(k,'')).casefold()==name.strip().casefold() for k in ('name','gamertag','ingame_name'))]
    identities={str(p['id']):p for p in matches if p.get('id')}
    if len(identities)!=1:
        raise NitradoError('Name not found or ambiguous. Use the exact unique gamertag/ingame name returned by /nitrado players or the relevant list.')
    return next(iter(identities.values()))


def form_body(payload):
    if payload is None: return None
    fields=[]
    for key,value in payload.items():
        if isinstance(value,(list,tuple)):
            if len(value)==1: fields.append((key,str(value[0])))
            else: fields.extend((f'{key}[]',str(v)) for v in value)
        elif value is not None:
            fields.append((key,str(value)))
    return fields


class Client:
    def __init__(self):
        self.session=None
        self.blocked_until=0

    async def close(self):
        if self.session: await self.session.close()

    async def http(self):
        if self.session is None or self.session.closed:
            self.session=aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25))
        return self.session

    async def request(self,method,path,params=None,payload=None,public=False,token_override=None):
        if time.monotonic()<self.blocked_until:
            raise NitradoError('Nitrado rate limit active. Try again shortly.')
        token=token_override if token_override is not None else os.getenv('NITRADO_TOKEN','').strip()
        if not token and not public: raise NitradoError('Run /nitrado setup to save a token and service IDs first.')
        headers={} if public else {'Authorization':f'Bearer {token}'}
        session=await self.http()
        try:
            # Same body format as Nitrado's official libraries: form fields, not JSON.
            async with session.request(method,BASE+path,headers=headers,params=params,data=form_body(payload),allow_redirects=False) as r:
                if r.status==429:
                    try: delay=float(r.headers.get('Retry-After','60'))
                    except ValueError: delay=60
                    self.blocked_until=time.monotonic()+min(max(delay,1),3600)
                    raise NitradoError('Nitrado rate limit reached. Try again later.')
                if r.status in (401,403): raise NitradoError('Nitrado denied access. Check token permissions and the configured service IDs.')
                if r.status in (404,405,501): raise NitradoError('This endpoint is unavailable for this service/game/platform.')
                if r.status>=400: raise NitradoError(f'Nitrado returned HTTP {r.status}. Check the service in its web panel.')
                try: body=await r.json(content_type=None)
                except (ValueError,aiohttp.ContentTypeError): raise NitradoError('Nitrado returned an invalid response.')
                if body.get('status')!='success': raise NitradoError('Nitrado did not confirm success. Check its web panel for details.')
                return body.get('data',{})
        except (aiohttp.ClientError,asyncio.TimeoutError):
            raise NitradoError('Nitrado connection failed or timed out. For changes, check the web panel before retrying.') from None

    async def service(self,gid,sid):
        allowed=service_ids()
        bound=str(db.get_setting(gid,'nitrado_service',''))
        sid=sid or bound
        if not sid or sid not in allowed: raise NitradoError('Run /nitrado setup or /nitrado service-add, then /nitrado bind to select a configured service ID.')
        return sid

    async def details(self,sid):
        return (await self.request('GET',f'/services/{sid}/gameservers')).get('gameserver',{})

    async def players(self,sid):
        rows=(await self.request('GET',f'/services/{sid}/gameservers/games/players')).get('players')
        if not isinstance(rows,list): raise NitradoError('Player data is unavailable on this platform.')
        return rows

    async def lists(self,sid,kind):
        caps=await self.request('GET',f'/services/{sid}/gameservers/games/players/lists')
        if kind not in caps.get('player_lists',[]): raise NitradoError(f'{kind} is not supported by Nitrado for this service.')
        rows=(await self.request('GET',f'/services/{sid}/gameservers/games/{kind}')).get(kind)
        if not isinstance(rows,list): raise NitradoError('Nitrado returned an unexpected player-list format.')
        return rows

    async def file_size(self,sid,path):
        """Size of a file. Nitrado's stat answer can be a list or a {path: info} map."""
        try:
            data=await self.request('GET',f'/services/{sid}/gameservers/file_server/stat',params=[('files[]',path)])
        except NitradoError:
            data=None
        if data is not None:
            entries=data.get('entries') if isinstance(data,dict) else None
            if isinstance(entries,dict): entries=list(entries.values())
            entry=entries[0] if isinstance(entries,list) and entries and isinstance(entries[0],dict) else None
            if not entry: raise NitradoError('Log file not found or not readable on this server.')
            if str(entry.get('type','file')).lower() in ('dir','directory'): raise NitradoError('That path is a folder, not a log file.')
            try: return int(entry.get('size') or 0)
            except (TypeError,ValueError): return 0
        data=await self.request('GET',f'/services/{sid}/gameservers/file_server/size',params={'path':path})
        return int(data.get('size') or 0)

    async def fetch_signed(self,token_info,keep_last=131072,max_bytes=50*1024*1024,raw=False):
        """Download from a Nitrado file token. The signed URL needs ?token=<token> (as in Nitrado's official library)."""
        token_info=token_info if isinstance(token_info,dict) else {}
        url=str(token_info.get('url') or '')
        parsed=urlparse(url)
        if parsed.scheme not in ('http','https') or not (parsed.hostname or '').endswith('.nitrado.net'):
            raise NitradoError('Unexpected Nitrado file-download host.')
        params={'token':str(token_info['token'])} if token_info.get('token') else None
        session=await self.http()
        try:
            # A signed file URL never receives the lifetime bearer token.
            async with session.get(url,params=params,allow_redirects=False) as r:
                if r.status!=200: raise NitradoError(f'Nitrado could not read that log file (HTTP {r.status}).')
                buf=bytearray(); size=0
                async for chunk in r.content.iter_chunked(65536):
                    size+=len(chunk)
                    if size>max_bytes: break
                    buf.extend(chunk)
                    if len(buf)>keep_last*2: del buf[:len(buf)-keep_last]
                data=bytes(buf[-keep_last:])
                return data if raw else data.decode('utf-8',errors='replace')
        except (aiohttp.ClientError,asyncio.TimeoutError):
            raise NitradoError('Log download failed. Try again later.') from None

    async def resolve_path(self,sid,path):
        """Nitrado lists logs as 'arkxb/ShooterGame/...'; the file server wants the full '/games/<user>/noftp/arkxb/...' path."""
        path=str(path or '').strip()
        cache=getattr(self,'_paths',None)
        if cache is None: cache=self._paths={}
        if (sid,path) in cache: return cache[(sid,path)]
        candidates=[path]
        if not path.startswith('/'):
            try: g=await self.details(sid)
            except NitradoError: g={}
            user=str(g.get('username') or '')
            gsp=str((g.get('game_specific') or {}).get('path') or '').rstrip('/')
            first,_,rest=path.partition('/')
            if gsp:
                if gsp.endswith('/'+first) and rest: candidates.append(f'{gsp}/{rest}')
                candidates.append(f'{gsp}/{path}')
            if user:
                candidates += [f'/games/{user}/noftp/{path}',f'/games/{user}/ftproot/{path}',f'/games/{user}/{path}']
        for candidate in dict.fromkeys(candidates):
            try:
                await self.file_size(sid,candidate)
            except NitradoError:
                continue
            cache[(sid,path)]=candidate
            return candidate
        raise NitradoError('Log file not found on this server. Tried: '+', '.join(dict.fromkeys(candidates))[:900])

    async def game_root(self,sid):
        """Full path of the game folder, e.g. /games/ni123_1/noftp/arkxb"""
        g=await self.details(sid)
        gsp=str((g.get('game_specific') or {}).get('path') or '').rstrip('/')
        if gsp: return gsp
        user=str(g.get('username') or '')
        if not user: raise NitradoError('Could not work out this server\'s game folder.')
        return f'/games/{user}/noftp/arkxb'

    async def list_dir(self,sid,folder):
        data=await self.request('GET',f'/services/{sid}/gameservers/file_server/list',params={'dir':folder})
        self.last_list_raw=data
        entries=data.get('entries') if isinstance(data,dict) else None
        if entries is None and isinstance(data,dict):
            entries=next((v for v in data.values() if isinstance(v,(list,dict))),None)
        if isinstance(entries,dict): entries=list(entries.values())
        return [e for e in (entries or []) if isinstance(e,dict)]

    async def download_to(self,sid,path,dest,max_bytes=2*1024**3):
        """Stream a whole file from the Nitrado file server to a local file. Returns bytes written."""
        body=await self.request('GET',f'/services/{sid}/gameservers/file_server/download',params={'file':path})
        info=body.get('token') if isinstance(body,dict) else None
        info=info if isinstance(info,dict) else {}
        url=str(info.get('url') or '')
        parsed=urlparse(url)
        if parsed.scheme not in ('http','https') or not (parsed.hostname or '').endswith('.nitrado.net'):
            raise NitradoError('Unexpected Nitrado file-download host.')
        params={'token':str(info['token'])} if info.get('token') else None
        session=await self.http()
        written=0
        tmp=str(dest)+'.part'
        try:
            async with session.get(url,params=params,allow_redirects=False,timeout=aiohttp.ClientTimeout(total=1800)) as r:
                if r.status!=200: raise NitradoError(f'Nitrado could not send that file (HTTP {r.status}).')
                with open(tmp,'wb') as f:
                    async for chunk in r.content.iter_chunked(1024*1024):
                        written+=len(chunk)
                        if written>max_bytes: raise NitradoError('File is larger than 2 GB; stopped.')
                        f.write(chunk)
            os.replace(tmp,dest)
            return written
        except (aiohttp.ClientError,asyncio.TimeoutError):
            raise NitradoError('Download failed part-way. Try again.') from None
        finally:
            if os.path.exists(tmp): os.remove(tmp)

    async def log_tail(self,sid,path,length=131072):
        """Last `length` bytes of a log.
        Downloads the whole current file (Nitrado's reported file size can lag behind, which made
        seek-based reads return an old copy). Falls back to seek if download is refused."""
        path=await self.resolve_path(sid,path)
        try:
            body=await self.request('GET',f'/services/{sid}/gameservers/file_server/download',params={'file':path})
            return await self.fetch_signed(body.get('token'),keep_last=length)
        except NitradoError as first:
            try:
                size=await self.file_size(sid,path)
                if size==0: return ''
                offset=max(0,size-length)
                body=await self.request('GET',f'/services/{sid}/gameservers/file_server/seek',params={'file':path,'offset':offset,'length':length*8,'mode':'raw'})
                return await self.fetch_signed(body.get('token'),keep_last=length)
            except NitradoError:
                raise first from None



"""Embed maker, ready-made panels and dropdown "information" options.

/embed create name type   -> opens a live editor (preview + buttons) for a saved embed
/embed edit | list | delete | media
/add information channel  -> adds a dropdown option (Player Stats, Dino Changes, ...) to an embed
/remove information       -> removes one

Panel types attach working components to the embed:
  link      -> "Connect" button (xbox_link.py handles it)
  kickme    -> "Kick Me" button (xbox_link.py)
  playtime  -> cluster leaderboard dropdown (playtime.py)
  custom    -> just your embed (+ info dropdown / link buttons)
"""
import json
import re
import time
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import color_int, admin_check
from ticket_media import clean_url, media_url, media_files, cache_media, store_image

KIND_LABELS = {
    'custom': 'Custom embed',
    'link': 'Link Gamertag panel',
    'kickme': 'Kick Me panel',
    'playtime': 'Leaderboard panel (playtime + KD)',
}

PANEL_DEFAULTS = {
    'custom': dict(title='New Embed', description='Use the editor buttons to change me.', color='8A2BE2', font='normal',
                   placeholder='Choose an option...'),
    'link': dict(title='Link Gamertag', color='8A2BE2', font='serif', button_label='Connect', thumbnail_from_server=True, description=(
        "**Important Info:**\n"
        "- {server} never sees your password.\n"
        "- Your Discord ID, Gamertag and Xbox account ID are saved to link your account.\n\n"
        "**How To Link:**\n"
        "- Open Discord settings, press **Connections** and connect your Xbox account.\n"
        "- Once done, press **Connect** below and authorise with Discord.\n\n"
        "**Features of linking your gamertag:**\n"
        "- Use the **Kick Me** button in {kickme_channel} whenever you need it!\n"
        "- Able to gain exclusive Discord roles from {playtime_channel}.")),
    'kickme': dict(title='Kick Me', color='8A2BE2', font='serif', button_label='Kick Me', thumbnail_from_server=True, description=(
        "**Important Info:**\n"
        "- Helps players get unstuck.\n"
        "- You must link your gamertag in {link_channel}.\n\n"
        "**How To Kick:**\n"
        "Press **Kick Me** below.")),
    'playtime': dict(title='Leaderboard', color='8A2BE2', font='serif', placeholder='Choose a leaderboard...',
                     thumbnail_from_server=True, description=(
        "**Important Info:**\n"
        "- Your playtime, kills and deaths on {server} are fully tracked.\n"
        "- Choose your cluster below to view its top players.\n\n"
        "**How To Earn Rewards:**\n"
        "- Link your Discord and Xbox gamertag in {link_channel}.\n"
        "- The leading linked players in each cluster earn its Record Holder roles automatically.")),
}

# ---------- fancy title fonts (Unicode letter styles, like the panels in the screenshots) ----------

def _font_map(upper, lower, digit=None, exceptions=None):
    table = {}
    for n in range(26):
        table[chr(65 + n)] = chr(upper + n)
        table[chr(97 + n)] = chr(lower + n)
    if digit:
        for n in range(10):
            table[chr(48 + n)] = chr(digit + n)
    table.update(exceptions or {})
    return table

FONTS = {
    'normal': ('Normal', None),
    'serif': ('𝐁𝐨𝐥𝐝 𝐒𝐞𝐫𝐢𝐟', _font_map(0x1D400, 0x1D41A, 0x1D7CE)),
    'sans': ('𝗕𝗼𝗹𝗱 𝗦𝗮𝗻𝘀', _font_map(0x1D5D4, 0x1D5EE, 0x1D7EC)),
    'script': ('𝓢𝓬𝓻𝓲𝓹𝓽', _font_map(0x1D4D0, 0x1D4EA)),
    'double': ('𝔻𝕠𝕦𝕓𝕝𝕖', _font_map(0x1D538, 0x1D552, 0x1D7D8, {
        'C': 'ℂ', 'H': 'ℍ', 'N': 'ℕ', 'P': 'ℙ', 'Q': 'ℚ', 'R': 'ℝ', 'Z': 'ℤ'})),
}
FONT_ORDER = list(FONTS)


def stylize(text, font):
    table = FONTS.get(font or 'normal', (None, None))[1]
    if not table or not text:
        return text
    # Leave {placeholders}, <#mentions> and :emoji: untouched.
    parts = re.split(r'(\{[^{}]*\}|<[^<>]*>|:[A-Za-z0-9_]+:)', text)
    return ''.join(p if i % 2 else ''.join(table.get(ch, ch) for ch in p) for i, p in enumerate(parts))


# ---------- storage ----------

def init_tables():
    with db.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS embeds(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          guild_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'custom',
          channel_id INTEGER,
          message_id INTEGER,
          data TEXT NOT NULL DEFAULT '{}',
          created INTEGER NOT NULL,
          UNIQUE(guild_id,name)
        );
        CREATE TABLE IF NOT EXISTS embed_info(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          embed_id INTEGER NOT NULL,
          position INTEGER NOT NULL DEFAULT 0,
          label TEXT NOT NULL,
          emoji TEXT,
          description TEXT,
          data TEXT NOT NULL DEFAULT '{}',
          FOREIGN KEY(embed_id) REFERENCES embeds(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_embeds_channel ON embeds(guild_id,channel_id);
        ''')


def row_dict(row):
    if row is None:
        return None
    out = dict(row)
    try:
        out['data'] = json.loads(out.get('data') or '{}')
    except ValueError:
        out['data'] = {}
    return out


def get_embed(eid):
    with db.conn() as c:
        return row_dict(c.execute('SELECT * FROM embeds WHERE id=?', (int(eid),)).fetchone())


def find_embed(gid, name):
    with db.conn() as c:
        return row_dict(c.execute('SELECT * FROM embeds WHERE guild_id=? AND lower(name)=lower(?)', (gid, name)).fetchone())


def guild_embeds(gid, channel_id=None, kind=None):
    sql, args = 'SELECT * FROM embeds WHERE guild_id=?', [gid]
    if channel_id:
        sql += ' AND channel_id=? AND message_id IS NOT NULL'
        args.append(channel_id)
    if kind:
        sql += ' AND kind=?'
        args.append(kind)
    with db.conn() as c:
        return [row_dict(r) for r in c.execute(sql + ' ORDER BY id', args).fetchall()]


def create_embed(gid, name, kind='custom'):
    data = dict(PANEL_DEFAULTS.get(kind, PANEL_DEFAULTS['custom']))
    with db.conn() as c:
        cur = c.execute('INSERT INTO embeds(guild_id,name,kind,data,created) VALUES(?,?,?,?,?)',
                        (gid, name, kind, json.dumps(data, ensure_ascii=False), int(time.time())))
        return cur.lastrowid


def save_data(eid, data):
    with db.conn() as c:
        c.execute('UPDATE embeds SET data=? WHERE id=?', (json.dumps(data, ensure_ascii=False), int(eid)))


def set_location(eid, channel_id, message_id):
    with db.conn() as c:
        c.execute('UPDATE embeds SET channel_id=?,message_id=? WHERE id=?', (channel_id, message_id, int(eid)))


def infos(eid):
    with db.conn() as c:
        rows = c.execute('SELECT * FROM embed_info WHERE embed_id=? ORDER BY position,id', (int(eid),)).fetchall()
    return [row_dict(r) for r in rows]


def get_info(info_id):
    with db.conn() as c:
        return row_dict(c.execute('SELECT * FROM embed_info WHERE id=?', (int(info_id),)).fetchone())


# ---------- rendering ----------

def kind_channel(guild, kind):
    for row in guild_embeds(guild.id, kind=kind):
        if row.get('message_id') and guild.get_channel(int(row.get('channel_id') or 0)):
            return f"<#{row['channel_id']}>"
    return None


def _norm(value):
    return re.sub(r'[^a-z0-9]', '', str(value).casefold())


def fill(text, guild):
    """Placeholders: {server} {member_count} {link_channel} {kickme_channel} {playtime_channel} {#channel-name}"""
    if not text or guild is None:
        return text or ''
    text = str(text).replace('{server}', guild.name).replace('{member_count}', str(guild.member_count or 0))
    fallback = {'link': '#link-gamertag', 'kickme': '#kick-me', 'playtime': '#playtime'}
    for kind in ('link', 'kickme', 'playtime'):
        token = '{' + kind + '_channel}'
        if token in text:
            text = text.replace(token, kind_channel(guild, kind) or fallback[kind])

    def channel_ref(match):
        wanted = _norm(match.group(1))
        for ch in guild.channels:
            if _norm(ch.name) == wanted or (wanted and _norm(ch.name).endswith(wanted)):
                return ch.mention
        return '#' + match.group(1)
    text = re.sub(r'\{#([^{}]{1,100})\}', channel_ref, text)

    def emoji_ref(match):
        # ":BlackDot:" typed in a slash command stays plain text; swap in the server's real emoji.
        name = match.group(1)
        emoji = next((e for e in getattr(guild, 'emojis', ()) if e.name == name), None) or \
                next((e for e in getattr(guild, 'emojis', ()) if e.name.casefold() == name.casefold()), None)
        return str(emoji) if emoji else match.group(0)
    return re.sub(r'(?<![<\w]):([A-Za-z0-9_]{2,32}):(?!\d)', emoji_ref, text)


def build_embed(guild, data, gid=None):
    gid = gid or (guild.id if guild else 0)
    title = stylize(fill(data.get('title'), guild), data.get('font'))
    e = discord.Embed(title=title[:256] or None, description=fill(data.get('description'), guild)[:4096] or None,
                      color=color_int(data.get('color') or '8A2BE2'))
    if data.get('url'):
        try: e.url = clean_url(data['url'])
        except ValueError: pass
    if data.get('author_name'):
        icon = media_url(gid, data, 'author_icon')
        e.set_author(name=fill(data['author_name'], guild)[:256], icon_url=icon or None)
    image = media_url(gid, data, 'image')
    if image:
        e.set_image(url=image)
    thumb = media_url(gid, data, 'thumbnail')
    if not thumb and data.get('thumbnail_from_server') and guild and guild.icon:
        thumb = guild.icon.url
    if thumb:
        e.set_thumbnail(url=thumb)
    for f in (data.get('fields') or [])[:25]:
        e.add_field(name=fill(f.get('name'), guild)[:256] or '​', value=fill(f.get('value'), guild)[:1024] or '​',
                    inline=bool(f.get('inline', True)))
    if data.get('footer'):
        e.set_footer(text=fill(data['footer'], guild)[:2048])
    if data.get('timestamp'):
        e.timestamp = discord.utils.utcnow()
    if len(e) > 6000:
        raise ValueError('This embed is over Discord\'s 6,000 character limit. Shorten some text.')
    return e


class InfoSelect(discord.ui.DynamicItem[discord.ui.Select], template=r'ei:(?P<eid>\d+)'):
    """The dropdown under an embed. Works after restarts because the embed id is in the custom_id."""
    def __init__(self, eid, options=None, placeholder=None):
        self.eid = int(eid)
        super().__init__(discord.ui.Select(custom_id=f'ei:{self.eid}', placeholder=(placeholder or 'Choose an option...')[:150],
                                           options=options or [discord.SelectOption(label='…', value='0')], min_values=1, max_values=1))

    @classmethod
    async def from_custom_id(cls, interaction, item, match):
        return cls(match['eid'])

    async def callback(self, i: discord.Interaction):
        values = (i.data or {}).get('values') or []
        info = get_info(values[0]) if values and str(values[0]).isdigit() else None
        row = get_embed(self.eid)
        if not info or not row or info['embed_id'] != self.eid or row['guild_id'] != i.guild_id:
            return await i.response.send_message('That option no longer exists.', ephemeral=True)
        d = info['data']
        merged = dict(d)
        merged.setdefault('color', row['data'].get('color'))
        title = d.get('title') or f"{info.get('emoji') or ''} {info['label']}".strip()
        e = discord.Embed(title=fill(title, i.guild)[:256], description=fill(d.get('body'), i.guild)[:4096] or None,
                          color=color_int(merged.get('color') or '8A2BE2'))
        image = media_url(i.guild_id, d, 'image')
        if image:
            e.set_image(url=image)
        await i.response.send_message(embed=e, files=media_files(i.guild_id, d), ephemeral=True)
        # Reset the dropdown so the same option can be picked again.
        try:
            cog = i.client.get_cog('EmbedCog')
            if cog and i.message:
                await i.message.edit(view=cog.build_view(i.guild, row))
        except discord.HTTPException:
            pass


def info_options(eid):
    out = []
    for info in infos(eid)[:25]:
        emoji = None
        if info.get('emoji'):
            try: emoji = discord.PartialEmoji.from_str(info['emoji'])
            except Exception: emoji = None
        out.append(discord.SelectOption(label=info['label'][:100], value=str(info['id']), emoji=emoji,
                                        description=(info.get('description') or None) and info['description'][:100]))
    return out


# ---------- the cog ----------

class EmbedCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        init_tables()

    async def cog_load(self):
        self.bot.add_dynamic_items(InfoSelect)
        extras = getattr(self.bot, 'extra_group_commands', None)
        if extras is None:
            extras = self.bot.extra_group_commands = {'add': {}, 'remove': {}}
        extras['add']['information'] = add_information
        extras['remove']['information'] = remove_information
        for group_name, cmd in (('add', add_information), ('remove', remove_information)):
            group = self.bot.tree.get_command(group_name)
            if isinstance(group, app_commands.Group) and group.get_command(cmd.name) is None:
                group.add_command(cmd)

    async def cog_unload(self):
        self.bot.remove_dynamic_items(InfoSelect)
        extras = getattr(self.bot, 'extra_group_commands', {})
        for group_name in ('add', 'remove'):
            extras.get(group_name, {}).pop('information', None)
            group = self.bot.tree.get_command(group_name)
            if isinstance(group, app_commands.Group):
                group.remove_command('information')

    # ----- message building -----
    def build_view(self, guild, row):
        data = row['data']
        view = discord.ui.View(timeout=None)
        kind = row['kind']
        style = getattr(discord.ButtonStyle, str(data.get('button_style') or 'primary'), discord.ButtonStyle.primary)
        if kind == 'link':
            view.add_item(discord.ui.Button(label=(data.get('button_label') or 'Connect')[:80], style=style, custom_id='xl:connect'))
        elif kind == 'kickme':
            view.add_item(discord.ui.Button(label=(data.get('button_label') or 'Kick Me')[:80], style=style, custom_id='xl:kick'))
        elif kind == 'playtime':
            try:
                import playtime
                options = playtime.board_options(guild.id)
            except Exception:
                options = [discord.SelectOption(label='All servers', value='*')]
            view.add_item(discord.ui.Select(custom_id='pt:board', placeholder=(data.get('placeholder') or 'Choose a leaderboard...')[:150],
                                            options=options[:25]))
        opts = info_options(row['id'])
        if opts:
            view.add_item(InfoSelect(row['id'], opts, data.get('placeholder')))
        for b in (data.get('buttons') or [])[:5]:
            emoji = None
            if b.get('emoji'):
                try: emoji = discord.PartialEmoji.from_str(b['emoji'])
                except Exception: emoji = None
            view.add_item(discord.ui.Button(label=b.get('label')[:80] if b.get('label') else None, url=b['url'], emoji=emoji))
        return view

    def render(self, guild, row):
        data = row['data']
        return dict(content=fill(data.get('content'), guild)[:2000] or None, embed=build_embed(guild, data),
                    view=self.build_view(guild, row), files=media_files(guild.id, data))

    async def post(self, guild, row, channel):
        msg = self.render(guild, row)
        sent = await channel.send(content=msg['content'], embed=msg['embed'], view=msg['view'], files=msg['files'],
                                  allowed_mentions=discord.AllowedMentions(everyone=True, roles=True, users=True))
        old_channel, old_message = row.get('channel_id'), row.get('message_id')
        set_location(row['id'], channel.id, sent.id)
        if old_message and (old_channel, old_message) != (channel.id, sent.id):
            old = guild.get_channel(int(old_channel or 0))
            if old:
                try: await old.get_partial_message(int(old_message)).delete()
                except discord.HTTPException: pass
        return sent

    async def update_posted(self, guild, row):
        """Re-render a posted embed in place. Returns False when it is not posted (or was deleted)."""
        if not row or not row.get('message_id'):
            return False
        channel = guild.get_channel(int(row.get('channel_id') or 0))
        if not channel:
            return False
        msg = self.render(guild, row)
        try:
            await channel.get_partial_message(int(row['message_id'])).edit(content=msg['content'], embed=msg['embed'], view=msg['view'],
                                                                           attachments=msg['files'])
            return True
        except discord.NotFound:
            set_location(row['id'], None, None)
            return False

    async def refresh_kind(self, guild, kind):
        for row in guild_embeds(guild.id, kind=kind):
            try: await self.update_posted(guild, row)
            except discord.HTTPException: pass

    async def refresh_all(self, guild):
        """Placeholders like {kickme_channel} change when another panel is posted."""
        for row in guild_embeds(guild.id):
            try: await self.update_posted(guild, row)
            except (discord.HTTPException, ValueError): pass

    # ----- commands -----
    embed = app_commands.Group(name='embed', description='Make and edit embeds and panels', guild_only=True)

    @embed.command(name='create', description='Make a new embed or ready-made panel and open the editor')
    @admin_check()
    @app_commands.describe(name='A name to find it later, e.g. rules or duos-info', type='Custom embed, or a working panel')
    @app_commands.choices(type=[app_commands.Choice(name=v, value=k) for k, v in KIND_LABELS.items()])
    async def create(self, i: discord.Interaction, name: app_commands.Range[str, 1, 60], type: app_commands.Choice[str] = None):
        kind = type.value if type else 'custom'
        name = name.strip()
        if find_embed(i.guild_id, name):
            return await i.response.send_message(f'❌ An embed called **{name}** already exists. Use `/embed edit`.', ephemeral=True)
        if len(guild_embeds(i.guild_id)) >= 200:
            return await i.response.send_message('❌ 200 saved embeds is the limit. Delete some with `/embed delete`.', ephemeral=True)
        eid = create_embed(i.guild_id, name, kind)
        await open_builder(i, eid)

    @embed.command(name='edit', description='Open the editor for a saved embed or panel')
    @admin_check()
    async def edit(self, i: discord.Interaction, embed: str):
        row = resolve(i.guild_id, embed)
        if not row:
            return await i.response.send_message('❌ No saved embed with that name.', ephemeral=True)
        await open_builder(i, row['id'])

    @embed.command(name='list', description='Show saved embeds and where they are posted')
    @admin_check()
    async def list_cmd(self, i: discord.Interaction):
        rows = guild_embeds(i.guild_id)
        lines = [f"**{r['name']}** · {KIND_LABELS.get(r['kind'], r['kind'])} · "
                 + (f"<#{r['channel_id']}>" if r.get('message_id') else 'not posted')
                 + (f" · {len(infos(r['id']))} info option(s)" if infos(r['id']) else '') for r in rows]
        e = discord.Embed(title='Saved embeds', description='\n'.join(lines)[:4000] or 'None yet — `/embed create`.', color=0x8A2BE2)
        await i.response.send_message(embed=e, ephemeral=True)

    @embed.command(name='delete', description='Delete a saved embed (and its posted message)')
    @admin_check()
    async def delete(self, i: discord.Interaction, embed: str, keep_message: bool = False):
        row = resolve(i.guild_id, embed)
        if not row:
            return await i.response.send_message('❌ No saved embed with that name.', ephemeral=True)
        if row.get('message_id') and not keep_message:
            ch = i.guild.get_channel(int(row.get('channel_id') or 0))
            if ch:
                try: await ch.get_partial_message(int(row['message_id'])).delete()
                except discord.HTTPException: pass
        with db.conn() as c:
            c.execute('DELETE FROM embeds WHERE id=?', (row['id'],))
        await i.response.send_message(f"✅ Deleted **{row['name']}**.", ephemeral=True)

    @embed.command(name='media', description='Upload an image straight into an embed (no links needed)')
    @admin_check()
    @app_commands.choices(slot=[app_commands.Choice(name='Big image (bottom)', value='image'), app_commands.Choice(name='Thumbnail (top right)', value='thumbnail'),
                                app_commands.Choice(name='Author icon', value='author_icon')])
    async def media(self, i: discord.Interaction, embed: str, slot: app_commands.Choice[str], image: discord.Attachment = None):
        row = resolve(i.guild_id, embed)
        if not row:
            return await i.response.send_message('❌ No saved embed with that name.', ephemeral=True)
        await i.response.defer(ephemeral=True)
        data = row['data']
        if image is None:
            data.pop(slot.value + '_file', None)
            data[slot.value] = ''
            if slot.value == 'thumbnail':
                data['thumbnail_from_server'] = False
            note = 'removed'
        else:
            try:
                data[slot.value + '_file'] = store_image(i.guild_id, await image.read())
            except ValueError as e:
                return await i.followup.send(f'❌ {e}', ephemeral=True)
            data[slot.value] = ''
            note = 'uploaded'
        save_data(row['id'], data)
        row = get_embed(row['id'])
        posted = await self.update_posted(i.guild, row)
        await i.followup.send(f"✅ {slot.name} {note}." + (' Posted message updated.' if posted else ''), ephemeral=True)

    @edit.autocomplete('embed')
    @delete.autocomplete('embed')
    @media.autocomplete('embed')
    async def embed_ac(self, i, current):
        return embed_choices(i.guild_id, current)


def resolve(gid, value):
    value = str(value or '').strip()
    if value.isdigit():
        row = get_embed(value)
        if row and row['guild_id'] == gid:
            return row
    return find_embed(gid, value)


def embed_choices(gid, current, channel_id=None):
    current = (current or '').casefold()
    rows = guild_embeds(gid, channel_id=channel_id)
    return [app_commands.Choice(name=f"{r['name']} · {KIND_LABELS.get(r['kind'], r['kind'])}"[:100], value=str(r['id']))
            for r in rows if current in r['name'].casefold()][:25]


# ---------- the live editor ----------

def builder_status(guild, row):
    where = f"posted in <#{row['channel_id']}>" if row.get('message_id') else 'not posted yet — pick a channel below'
    font = FONTS.get(row['data'].get('font') or 'normal', FONTS['normal'])[0]
    lines = [f"**Editing `{row['name']}`** · {KIND_LABELS.get(row['kind'], row['kind'])} · {where}", f"Title font: {font}"]
    if row['data'].get('content'):
        lines.append(f"Message text: {fill(row['data']['content'], guild)[:300]}")
    n = len(infos(row['id']))
    lines.append(f"Info options: {n} (add with `/add information`)" if n else "Tip: add dropdown info with `/add information` after posting.")
    lines.append("Placeholders: `{server}` `{link_channel}` `{kickme_channel}` `{playtime_channel}` `{#channel-name}`")
    return '\n'.join(lines)


async def open_builder(i, eid):
    row = get_embed(eid)
    view = Builder(i.user.id, eid)
    try:
        embed = build_embed(i.guild, row['data'])
    except ValueError as e:
        embed = discord.Embed(title='Preview unavailable', description=str(e), color=0xED4245)
    await i.response.send_message(builder_status(i.guild, row), embed=embed, view=view,
                                  files=media_files(i.guild_id, row['data']), ephemeral=True)


async def refresh_builder(i, eid, view, note=None):
    row = get_embed(eid)
    try:
        embed = build_embed(i.guild, row['data'])
    except ValueError as e:
        embed = discord.Embed(title='Preview unavailable', description=str(e), color=0xED4245)
    content = builder_status(i.guild, row) + (f"\n{note}" if note else '')
    kwargs = dict(content=content[:2000], embed=embed, view=view, attachments=media_files(i.guild_id, row['data']))
    if i.response.is_done():
        await i.edit_original_response(**kwargs)
    else:
        await i.response.edit_message(**kwargs)
    cog = i.client.get_cog('EmbedCog')
    if cog and row.get('message_id'):
        try: await cog.update_posted(i.guild, row)
        except (discord.HTTPException, ValueError): pass


def text_input(label, value, *, style=discord.TextStyle.short, max_length=256, placeholder=None, required=False):
    return discord.ui.TextInput(label=label, default=(str(value)[:max_length] if value else None), style=style,
                                max_length=max_length, required=required, placeholder=placeholder)


class BuilderModal(discord.ui.Modal):
    def __init__(self, builder, title, fields, apply):
        super().__init__(title=title, timeout=600)
        self.builder, self.apply = builder, apply
        self.inputs = {}
        for key, item in fields:
            self.inputs[key] = item
            self.add_item(item)

    async def on_submit(self, i):
        row = get_embed(self.builder.eid)
        data = row['data']
        values = {k: str(v.value or '').strip() for k, v in self.inputs.items()}
        try:
            note = await self.apply(i, data, values)
            build_embed(i.guild, data)  # validate before saving
        except ValueError as e:
            if i.response.is_done():
                return await i.followup.send(f'❌ {e}', ephemeral=True)
            return await i.response.send_message(f'❌ {e}', ephemeral=True)
        save_data(self.builder.eid, data)
        await refresh_builder(i, self.builder.eid, self.builder, note)

    async def on_error(self, i, error):
        msg = f'Discord rejected that: {error.text[:500]}' if isinstance(error, discord.HTTPException) else 'Something went wrong saving that. Check the console.'
        print(f'Embed builder error: {type(error).__name__}: {error}')
        if i.response.is_done(): await i.followup.send('❌ ' + msg, ephemeral=True)
        else: await i.response.send_message('❌ ' + msg, ephemeral=True)


def yes(value):
    return str(value).strip().casefold() in ('y', 'yes', 'true', '1', 'on')


class Builder(discord.ui.View):
    def __init__(self, user_id, eid):
        super().__init__(timeout=900)
        self.user_id, self.eid = user_id, eid

    async def interaction_check(self, i):
        if i.user.id != self.user_id:
            await i.response.send_message('Only the person editing can use these buttons.', ephemeral=True)
            return False
        return True

    def data(self):
        return get_embed(self.eid)['data']

    @discord.ui.button(label='Text', emoji='✏️', style=discord.ButtonStyle.primary, row=0)
    async def text(self, i, _):
        d = self.data()
        async def apply(i, data, v):
            data['content'], data['title'], data['description'], data['footer'] = v['content'], v['title'], v['description'], v['footer']
            if v['color']:
                data['color'] = f"{color_int(v['color']):06X}"
        await i.response.send_modal(BuilderModal(self, 'Embed text', [
            ('content', text_input('Message text (above the embed)', d.get('content'), style=discord.TextStyle.paragraph, max_length=2000)),
            ('title', text_input('Title', d.get('title'))),
            ('description', text_input('Description', d.get('description'), style=discord.TextStyle.paragraph, max_length=4000)),
            ('footer', text_input('Footer', d.get('footer'), max_length=2048)),
            ('color', text_input('Color (HEX)', '#' + str(d.get('color') or '8A2BE2').lstrip('#'), max_length=7, placeholder='#8A2BE2')),
        ], apply))

    @discord.ui.button(label='Images', emoji='🖼️', style=discord.ButtonStyle.primary, row=0)
    async def images(self, i, _):
        d = self.data()
        async def apply(i, data, v):
            data['author_name'] = v['author_name']
            data['url'] = v['url']
            if data['url']:
                clean_url(data['url'])
            for key in ('thumbnail', 'image', 'author_icon'):
                if v[key] == '':
                    if data.get(key + '_file') or data.get(key):
                        data.pop(key + '_file', None)
                        data[key] = ''
                    if key == 'thumbnail':
                        data['thumbnail_from_server'] = False
                elif v[key].casefold() == 'server' and key == 'thumbnail':
                    data.pop('thumbnail_file', None); data['thumbnail'] = ''; data['thumbnail_from_server'] = True
                elif v[key] != '(uploaded image)':
                    data[key] = clean_url(v[key]); data.pop(key + '_file', None)
            await i.response.defer()
            cached = await cache_media(i.guild_id, data)
            data.clear(); data.update(cached)
        def shown(key):
            if d.get(key + '_file'): return '(uploaded image)'
            if key == 'thumbnail' and d.get('thumbnail_from_server') and not d.get('thumbnail'): return 'server'
            return d.get(key)
        await i.response.send_modal(BuilderModal(self, 'Images & author', [
            ('thumbnail', text_input('Thumbnail URL (type "server" for server icon)', shown('thumbnail'), max_length=1000)),
            ('image', text_input('Big image URL', shown('image'), max_length=1000)),
            ('author_name', text_input('Author name (small text at top)', d.get('author_name'))),
            ('author_icon', text_input('Author icon URL', shown('author_icon'), max_length=1000)),
            ('url', text_input('Title link URL (optional)', d.get('url'), max_length=1000)),
        ], apply))

    @discord.ui.button(label='Title Font', emoji='🔤', style=discord.ButtonStyle.secondary, row=0)
    async def font(self, i, _):
        d = self.data()
        current = d.get('font') or 'normal'
        d['font'] = FONT_ORDER[(FONT_ORDER.index(current) + 1) % len(FONT_ORDER)] if current in FONT_ORDER else 'normal'
        save_data(self.eid, d)
        await refresh_builder(i, self.eid, self)

    @discord.ui.button(label='Buttons & Menu', emoji='🔘', style=discord.ButtonStyle.secondary, row=0)
    async def components(self, i, _):
        d = self.data()
        async def apply(i, data, v):
            data['button_label'] = v['button_label'] or None
            data['placeholder'] = v['placeholder'] or None
            style = v['button_style'].casefold() or 'primary'
            aliases = {'blue': 'primary', 'blurple': 'primary', 'grey': 'secondary', 'gray': 'secondary', 'green': 'success', 'red': 'danger'}
            style = aliases.get(style, style)
            if style not in ('primary', 'secondary', 'success', 'danger'):
                raise ValueError('Button color must be blue, grey, green or red.')
            data['button_style'] = style
            data['timestamp'] = yes(v['timestamp'])
        await i.response.send_modal(BuilderModal(self, 'Buttons, dropdown & extras', [
            ('button_label', text_input('Panel button text (Connect / Kick Me)', d.get('button_label'), max_length=80)),
            ('button_style', text_input('Panel button color: blue, grey, green, red', d.get('button_style') or 'blue', max_length=10)),
            ('placeholder', text_input('Dropdown placeholder text', d.get('placeholder'), max_length=150)),
            ('timestamp', text_input('Show timestamp in footer? (yes/no)', 'yes' if d.get('timestamp') else 'no', max_length=3)),
        ], apply))

    @discord.ui.button(label='Done', emoji='✅', style=discord.ButtonStyle.success, row=0)
    async def done(self, i, _):
        self.stop()
        row = get_embed(self.eid)
        await i.response.edit_message(content=f"✅ Saved **{row['name']}**." + ('' if row.get('message_id') else ' Reopen with `/embed edit` to post it.'),
                                      view=None)

    @discord.ui.button(label='Add Field', emoji='➕', style=discord.ButtonStyle.secondary, row=1)
    async def add_field(self, i, _):
        async def apply(i, data, v):
            fields = data.setdefault('fields', [])
            if len(fields) >= 25:
                raise ValueError('25 fields is the maximum.')
            fields.append({'name': v['name'], 'value': v['value'], 'inline': not v['inline'] or yes(v['inline'])})
        await i.response.send_modal(BuilderModal(self, 'Add a field', [
            ('name', text_input('Field name', None, required=True)),
            ('value', text_input('Field value', None, style=discord.TextStyle.paragraph, max_length=1024, required=True)),
            ('inline', text_input('Side by side? (yes/no)', 'yes', max_length=3)),
        ], apply))

    @discord.ui.button(label='Remove Field', emoji='➖', style=discord.ButtonStyle.secondary, row=1)
    async def remove_field(self, i, _):
        async def apply(i, data, v):
            fields = data.get('fields') or []
            if not fields:
                raise ValueError('There are no fields to remove.')
            n = int(v['number']) if v['number'].isdigit() else len(fields)
            if not 1 <= n <= len(fields):
                raise ValueError(f'Pick a field number from 1 to {len(fields)}.')
            gone = fields.pop(n - 1)
            return f"Removed field **{gone.get('name')}**."
        await i.response.send_modal(BuilderModal(self, 'Remove a field', [
            ('number', text_input('Field number (1 = first, blank = last)', None, max_length=2)),
        ], apply))

    @discord.ui.button(label='Add Link Button', emoji='🔗', style=discord.ButtonStyle.secondary, row=1)
    async def add_link(self, i, _):
        async def apply(i, data, v):
            buttons = data.setdefault('buttons', [])
            if len(buttons) >= 5:
                raise ValueError('5 link buttons is the maximum.')
            url = clean_url(v['url'])
            if not url:
                raise ValueError('Enter a link.')
            if not v['label'] and not v['emoji']:
                raise ValueError('Give the button a label or an emoji.')
            buttons.append({'label': v['label'], 'url': url, 'emoji': v['emoji']})
        await i.response.send_modal(BuilderModal(self, 'Add a link button', [
            ('label', text_input('Button text', None, max_length=80)),
            ('url', text_input('Link (https://...)', None, max_length=512, required=True)),
            ('emoji', text_input('Emoji (optional)', None, max_length=100)),
        ], apply))

    @discord.ui.button(label='Clear Link Buttons', emoji='🧹', style=discord.ButtonStyle.secondary, row=1)
    async def clear_links(self, i, _):
        d = self.data()
        d['buttons'] = []
        save_data(self.eid, d)
        await refresh_builder(i, self.eid, self, 'Link buttons cleared.')

    @discord.ui.select(cls=discord.ui.ChannelSelect, channel_types=[discord.ChannelType.text, discord.ChannelType.news],
                       placeholder='📤 Post (or move) this embed to a channel…', row=2)
    async def destination(self, i, select):
        channel = i.guild.get_channel(select.values[0].id)
        cog = i.client.get_cog('EmbedCog')
        perms = channel.permissions_for(i.guild.me) if channel else None
        if not channel or not perms.send_messages or not perms.embed_links:
            return await i.response.send_message('❌ I need Send Messages, Embed Links and Attach Files in that channel.', ephemeral=True)
        await i.response.defer()
        row = get_embed(self.eid)
        try:
            sent = await cog.post(i.guild, row, channel)
        except (discord.HTTPException, ValueError) as e:
            return await i.followup.send(f'❌ Could not post: {getattr(e, "text", e)}', ephemeral=True)
        await cog.refresh_all(i.guild)  # other panels may reference this channel
        await refresh_builder(i, self.eid, self, f'✅ Posted: {sent.jump_url}')

    async def on_error(self, i, error, item):
        print(f'Embed builder error: {type(error).__name__}: {error}')
        msg = f'❌ {error}' if isinstance(error, ValueError) else '❌ That failed. Check the bot console.'
        if i.response.is_done(): await i.followup.send(msg[:1900], ephemeral=True)
        else: await i.response.send_message(msg[:1900], ephemeral=True)


# ---------- /add information and /remove information (attached to the ticket bot's /add and /remove groups) ----------

def channel_embed(gid, channel_id, embed_value):
    if embed_value:
        row = resolve(gid, embed_value)
        if row and (not channel_id or row.get('channel_id') == channel_id):
            return row, None
        return None, '❌ That embed is not posted in that channel.'
    rows = guild_embeds(gid, channel_id=channel_id)
    if not rows:
        return None, '❌ No saved embed is posted in that channel. Make one with `/embed create`, post it, then try again.'
    if len(rows) > 1:
        return None, '❌ That channel has several embeds: ' + ', '.join(f"**{r['name']}**" for r in rows) + '. Pick one with the `embed` option.'
    return rows[0], None



STYLE_CHOICES = [
    app_commands.Choice(name='Bullets + value boxes  (Harvest - 20x  ->  - Harvest - `20x`)', value='boxes'),
    app_commands.Choice(name='Bullets  (each part on its own - line)', value='bullets'),
    app_commands.Choice(name='Plain text  (| just starts a new line)', value='plain'),
]


def format_text(text, style='boxes'):
    """Slash-command text is one line, so | (or \\n) starts a new line.
    boxes:   "Harvest Rates - 20x | Player XP - Inf"  ->  "- Harvest Rates - `20x`" lines
    bullets: each part becomes "- part"
    plain:   parts are just put on separate lines"""
    raw_parts = [p.strip() for p in re.split(r'\s*\|\s*|\\n|\n', str(text or ''))]
    parts = [p for p in raw_parts if p]
    if style == 'plain':
        # "||" leaves a blank line (handy between sections)
        return '\n'.join(raw_parts).strip('\n')
    lines = []
    for part in parts:
        if part.startswith(('- ', '• ', '* ', '#', '>')) or re.match(r'\d+\.\s', part):
            lines.append(part)
            continue
        if style == 'boxes' and '`' not in part:
            m = re.match(r'(.+?)(?:\s+-|\s*[:=])\s+(.+)$', part)
            icon = re.match(r'((?:<a?:\w+:\d+>|[^\w\s`*_~]+))\s+(.+)$', part)
            if m:
                lines.append(f'- {m.group(1)} - `{m.group(2)}`')
                continue
            if icon:  # "➕ +12.5" -> "- ➕ `+12.5`" (the Player Stats look)
                lines.append(f'- {icon.group(1)} `{icon.group(2)}`')
                continue
        lines.append(f'- {part}')
    return '\n'.join(lines)


async def save_info(i, row, existing, label, emoji, description, title, body, image=None, color=None):
    label, emoji = str(label or '').strip(), str(emoji or '').strip()
    description, title, body = str(description or '').strip(), str(title or '').strip(), str(body or '').strip()
    send = i.followup.send if i.response.is_done() else i.response.send_message
    if not label or not body:
        return await send('❌ Give the option a name and some text.', ephemeral=True)
    if emoji:
        parsed = discord.PartialEmoji.from_str(emoji)
        if not parsed.id and not any(ord(ch) > 0x2000 for ch in emoji):
            return await send('❌ Use a real emoji like ✅ or a custom one like <:name:123>.', ephemeral=True)
        emoji = str(parsed)
    current = infos(row['id'])
    if any(x['label'].casefold() == label.casefold() and (not existing or x['id'] != existing['id']) for x in current):
        return await send('❌ An option with that name already exists on this embed. Use `edit:` to change it.', ephemeral=True)
    if not existing and len(current) >= 25:
        return await send('❌ A dropdown can hold 25 options. Remove one first.', ephemeral=True)
    if not i.response.is_done():
        await i.response.defer(ephemeral=True)
    data = dict(existing['data']) if existing else {}
    data['title'], data['body'] = title, body
    if color:
        data['color'] = color
    if image:
        try:
            data['image_file'] = store_image(i.guild_id, await image.read())
            data['image'] = ''
        except ValueError as e:
            return await i.followup.send(f'❌ {e}', ephemeral=True)
    with db.conn() as c:
        if existing:
            c.execute('UPDATE embed_info SET label=?,emoji=?,description=?,data=? WHERE id=?',
                      (label, emoji or None, description or None, json.dumps(data, ensure_ascii=False), existing['id']))
        else:
            pos = max([x['position'] for x in current], default=0) + 1
            c.execute('INSERT INTO embed_info(embed_id,position,label,emoji,description,data) VALUES(?,?,?,?,?,?)',
                      (row['id'], pos, label, emoji or None, description or None, json.dumps(data, ensure_ascii=False)))
    cog = i.client.get_cog('EmbedCog')
    posted = await cog.update_posted(i.guild, get_embed(row['id'])) if cog else False
    preview = discord.Embed(title=fill(title or f"{emoji} {label}".strip(), i.guild)[:256], description=fill(body, i.guild)[:4096],
                            color=color_int(data.get('color') or row['data'].get('color') or '8A2BE2'))
    img = media_url(i.guild_id, data, 'image')
    if img:
        preview.set_image(url=img)
    await i.followup.send(f"✅ {'Updated' if existing else 'Added'} **{label}** on **{row['name']}**."
                          + (' The dropdown is live.' if posted else ' Post the embed to see the dropdown.') + ' Preview:',
                          embed=preview, files=media_files(i.guild_id, data), ephemeral=True)


class InfoModal(discord.ui.Modal):
    def __init__(self, row, existing=None, image=None, color=None):
        super().__init__(title=('Edit' if existing else 'Add') + ' information', timeout=600)
        self.row, self.existing, self.image, self.color = row, existing, image, color
        d = existing['data'] if existing else {}
        self.label = text_input('Option name (shown in the dropdown)', existing and existing['label'], max_length=100, required=True,
                                placeholder='Player Stats')
        self.emoji = text_input('Emoji (optional)', existing and existing.get('emoji'), max_length=100, placeholder='✅ or <:name:id>')
        self.description = text_input('Small text under the option (optional)', existing and existing.get('description'), max_length=100)
        self.info_title = text_input('Info title (blank = option name)', d.get('title'), max_length=256)
        self.body = text_input('Info content', d.get('body'), style=discord.TextStyle.paragraph, max_length=4000, required=True,
                               placeholder='- Harvest Rates - `20x`\n- Player XP - `Inf`\nStart lines with "- " for bullets.')
        for item in (self.label, self.emoji, self.description, self.info_title, self.body):
            self.add_item(item)

    async def on_submit(self, i):
        await save_info(i, self.row, self.existing, self.label.value, self.emoji.value, self.description.value,
                        self.info_title.value, self.body.value, self.image, self.color)

    async def on_error(self, i, error):
        print(f'Info modal error: {type(error).__name__}: {error}')
        if i.response.is_done(): await i.followup.send('❌ Could not save that option. Check the bot console.', ephemeral=True)
        else: await i.response.send_message('❌ Could not save that option. Check the bot console.', ephemeral=True)


@app_commands.command(name='information', description='Add an info option to the dropdown under a posted embed')
@admin_check()
@app_commands.describe(channel='Channel the embed is posted in', name='Option name in the dropdown, e.g. Player Stats',
                       text='The info. Use | for a new line, e.g. Harvest Rates - 20x | Player XP - Inf  (leave empty for a big text box)',
                       emoji='Emoji shown beside the option', description='Small text under the option (optional)',
                       title='Title of the info (blank = option name)', style='How the text is laid out (default: bullets + value boxes)',
                       image='Optional image shown with the info', color='Optional HEX color, e.g. #1E90FF',
                       embed='Only needed if that channel has more than one embed', edit='Pick an existing option to change it')
@app_commands.choices(style=STYLE_CHOICES)
async def add_information(i: discord.Interaction, channel: discord.TextChannel, name: app_commands.Range[str, 1, 100],
                          text: app_commands.Range[str, 1, 4000] = None, emoji: app_commands.Range[str, 1, 100] = None,
                          description: app_commands.Range[str, 1, 100] = None, title: app_commands.Range[str, 1, 256] = None,
                          style: app_commands.Choice[str] = None, image: discord.Attachment = None, color: str = None,
                          embed: str = None, edit: str = None):
    row, err = channel_embed(i.guild_id, channel.id, embed)
    if err:
        return await i.response.send_message(err, ephemeral=True)
    existing = None
    if edit:
        existing = get_info(edit) if str(edit).isdigit() else next((x for x in infos(row['id']) if x['label'].casefold() == edit.casefold()), None)
        if not existing or existing['embed_id'] != row['id']:
            return await i.response.send_message('❌ That option is not on this embed.', ephemeral=True)
    if color:
        try: color = f'{color_int(color):06X}'
        except ValueError as e: return await i.response.send_message(f'❌ {e}', ephemeral=True)
    if image and image.size > 8 * 1024 * 1024:
        return await i.response.send_message('❌ Use an image under 8 MB.', ephemeral=True)
    if text is None:
        # No text given: open the big multi-line form, pre-filled with what was typed.
        modal = InfoModal(row, existing, image, color)
        modal.label.default = name
        if emoji: modal.emoji.default = emoji
        if description: modal.description.default = description
        if title: modal.info_title.default = title
        return await i.response.send_modal(modal)
    body = format_text(text, style.value if style else 'boxes')
    if existing:
        emoji = emoji if emoji is not None else existing.get('emoji')
        description = description if description is not None else existing.get('description')
        title = title if title is not None else existing['data'].get('title')
    await save_info(i, row, existing, name, emoji, description, title, body, image, color)


@app_commands.command(name='information', description='Remove a dropdown info option from a posted embed')
@admin_check()
async def remove_information(i: discord.Interaction, channel: discord.TextChannel, option: str, embed: str = None):
    row, err = channel_embed(i.guild_id, channel.id, embed)
    if err:
        return await i.response.send_message(err, ephemeral=True)
    info = get_info(option) if str(option).isdigit() else next((x for x in infos(row['id']) if x['label'].casefold() == option.casefold()), None)
    if not info or info['embed_id'] != row['id']:
        return await i.response.send_message('❌ That option is not on this embed.', ephemeral=True)
    with db.conn() as c:
        c.execute('DELETE FROM embed_info WHERE id=?', (info['id'],))
    await i.response.defer(ephemeral=True)
    cog = i.client.get_cog('EmbedCog')
    if cog:
        await cog.update_posted(i.guild, get_embed(row['id']))
    await i.followup.send(f"✅ Removed **{info['label']}** from **{row['name']}**.", ephemeral=True)


def _channel_id(i):
    ch = getattr(i.namespace, 'channel', None)
    return getattr(ch, 'id', None)


@add_information.autocomplete('embed')
@remove_information.autocomplete('embed')
async def _embed_ac(i, current):
    return embed_choices(i.guild_id, current, _channel_id(i))


async def _option_ac(i, current):
    cid = _channel_id(i)
    if not cid:
        return []
    row, err = channel_embed(i.guild_id, cid, getattr(i.namespace, 'embed', None))
    if err:
        return []
    current = (current or '').casefold()
    return [app_commands.Choice(name=x['label'][:100], value=str(x['id'])) for x in infos(row['id']) if current in x['label'].casefold()][:25]

add_information.autocomplete('edit')(_option_ac)
remove_information.autocomplete('option')(_option_ac)


async def setup(bot):
    await bot.add_cog(EmbedCog(bot))

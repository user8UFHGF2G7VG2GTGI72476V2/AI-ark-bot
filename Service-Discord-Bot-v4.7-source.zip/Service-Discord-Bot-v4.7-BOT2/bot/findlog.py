"""/findlog — search your Nitrado server logs by describing what you want.

  /findlog what:osd
  /findlog what:turret broken  server:<pick>
  /findlog what:Dxjxxspotify killed

Words are expanded to the wording ARK actually writes, e.g. "turret broken" matches
"destroyed your 'Heavy Auto Turret'". Every idea you type must appear in the line.
It searches the live end of each server's log (read through your Nitrado token) plus
everything the log feed has already saved (/logs-setup).
"""
import asyncio
import io
import re
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import staff_check
from nitrado_api import NitradoError, service_ids
from log_sources import find_log
import ark_services

STOP = {'the', 'a', 'an', 'log', 'logs', 'find', 'show', 'me', 'of', 'in', 'on', 'for', 'all', 'any', 'my', 'get', 'what',
        'who', 'when', 'was', 'were', 'is', 'are', 'that', 'this', 'with', 'by', 'from', 'to', 'and', 'or', 'please', 'search'}

# idea -> words ARK uses for it. A typed word that matches any key/alias becomes that idea.
SYNONYMS = {
    'osd': ['orbital supply drop', 'supply drop', 'osd', 'orbital'],
    'drop': ['supply drop', 'supply crate', 'beacon', 'drop'],
    'node': ['element node', 'element vein', 'node'],
    'element': ['element'],
    'asteroid': ['asteroid'],
    'turret': ['turret'],
    'broken': ['destroyed', 'demolished', 'broken', 'broke', 'auto-decay', 'decayed', 'decay'],
    'raid': ['destroyed', 'demolished', 'c4', 'explosive', 'rocket'],
    'c4': ['c4', 'explosive'],
    'killed': ['killed', 'was killed', 'died', 'death', 'starved'],
    'tamed': ['tamed', 'taming'],
    'claimed': ['claimed', 'unclaimed'],
    'joined': ['joined this ark', 'joined', 'connected'],
    'left': ['left this ark', 'disconnected', 'left'],
    'admin': ['admin', 'cheat', 'command'],
    'cryo': ['cryopod', 'cryo'],
    'upload': ['upload', 'uploaded', 'transfer', 'download', 'downloaded'],
    'tribe': ['tribe'],
    'chat': ['chat', 'said'],
    'structure': ['structure', 'foundation', 'wall', 'ceiling', 'door', 'gate', 'pillar'],
    'dino': ['dino', 'tame', 'lvl'],
    'player': ['player', 'tribemember', 'survivor'],
}
ALIASES = {
    'supply': 'drop', 'drops': 'drop', 'crate': 'drop', 'crates': 'drop', 'nodes': 'node', 'vein': 'node', 'turrets': 'turret',
    'heavy': 'turret', 'tek': 'turret', 'destroyed': 'broken', 'destroy': 'broken', 'break': 'broken', 'demolished': 'broken',
    'demo': 'broken', 'decayed': 'broken', 'decay': 'broken', 'died': 'killed', 'death': 'killed', 'deaths': 'killed',
    'kill': 'killed', 'kills': 'killed', 'dead': 'killed', 'tame': 'tamed', 'tames': 'tamed', 'taming': 'tamed',
    'claim': 'claimed', 'unclaimed': 'claimed', 'join': 'joined', 'joins': 'joined', 'connect': 'joined', 'leave': 'left',
    'leaves': 'left', 'disconnect': 'left', 'cheat': 'admin', 'cheats': 'admin', 'cryopod': 'cryo', 'transfer': 'upload',
    'download': 'upload', 'uploads': 'upload', 'raids': 'raid', 'raided': 'raid', 'explosive': 'c4', 'dinos': 'dino',
    'orbital': 'osd', 'osds': 'osd', 'asteroids': 'asteroid', 'players': 'player', 'tribes': 'tribe', 'structures': 'structure',
}


def concepts(query):
    """'turret broken' -> [['turret'], ['destroyed', 'demolished', ...]]. Quoted text is matched exactly."""
    groups = []
    for phrase in re.findall(r'"([^"]+)"', query):
        groups.append([phrase.casefold()])
    rest = re.sub(r'"[^"]+"', ' ', query)
    for word in re.findall(r"[\w'#\-]+", rest.casefold()):
        if word in STOP or len(word) < 2 and not word.isdigit():
            continue
        key = ALIASES.get(word, word)
        groups.append(SYNONYMS.get(key, [word.rstrip('s') if len(word) > 3 and word.endswith('s') else word]))
    return groups


def matches(line, groups):
    low = line.casefold()
    return bool(groups) and all(any(term in low for term in group) for group in groups)


def describe(groups):
    return ' + '.join('(' + ' / '.join(g[:4]) + (' …' if len(g) > 4 else '') + ')' if len(g) > 1 else g[0] for g in groups)


class FindLogCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api = bot.nitrado_api

    async def log_path(self, gid, sid):
        with db.conn() as c:
            try:
                row = c.execute('SELECT path FROM ark_feed WHERE service=? ORDER BY guild_id=? DESC LIMIT 1', (sid, gid)).fetchone()
            except Exception:
                row = None
        if row and row['path']:
            return row['path']
        saved = db.get_setting(gid, f'ark_discovered_logs:{sid}', []) or []
        if saved:
            return saved[0]
        path = await find_log(self.api, sid)
        db.set_setting(gid, f'ark_discovered_logs:{sid}', [path])
        return path

    async def live_lines(self, gid, sid):
        path = await self.log_path(gid, sid)
        return (await self.api.log_tail(sid, path)).splitlines()

    @app_commands.command(name='findlog', description='Search your Nitrado server logs, e.g. osd, turret broken, Gamertag killed')
    @app_commands.guild_only()
    @staff_check()
    @app_commands.describe(what='What to look for, in your own words. Put exact text in "quotes".',
                           server='Only search this server (blank = all servers)', limit='How many results to show (default 15)')
    @app_commands.autocomplete(server=ark_services.service_autocomplete)
    async def findlog(self, i: discord.Interaction, what: app_commands.Range[str, 1, 200], server: str = None,
                      limit: app_commands.Range[int, 1, 50] = 15):
        groups = concepts(what)
        if not groups:
            return await i.response.send_message('❌ Tell me what to look for, e.g. `osd` or `turret broken`.', ephemeral=True)
        sids = [server] if server else service_ids()
        if not sids or (server and server not in service_ids()):
            return await i.response.send_message('❌ No Nitrado servers linked (run `/linknitrado`), or that server is not one of them.', ephemeral=True)
        await i.response.defer(ephemeral=True, thinking=True)

        results, notes = {}, []

        async def one(sid):
            found = []
            try:
                found.extend(line for line in await self.live_lines(i.guild_id, sid) if matches(line, groups))
            except NitradoError as e:
                notes.append(f'{ark_services.name(sid)}: live log unavailable ({e})')
            with db.conn() as c:
                try:
                    saved = c.execute('SELECT line FROM ark_events WHERE guild_id=? AND service=? ORDER BY rowid DESC LIMIT 50000',
                                      (i.guild_id, sid)).fetchall()
                except Exception:
                    saved = []
            older = [r['line'] for r in reversed(saved) if r['line'] and matches(r['line'], groups)]
            seen, merged = set(), []
            for line in older + found:
                key = line.strip()
                if key and key not in seen:
                    seen.add(key)
                    merged.append(key)
            results[sid] = merged

        await asyncio.gather(*(one(s) for s in sids))
        total = sum(len(v) for v in results.values())
        e = discord.Embed(title=f'🔎 Log search: {what}'[:256], color=0x8A2BE2,
                          description=f'Looking for: {describe(groups)}\n**{total}** matching line(s) across {len(sids)} server(s).')
        shown = 0
        for sid, lines in results.items():
            if not lines:
                continue
            take = lines[-max(1, limit - shown):] if shown < limit else []
            shown += len(take)
            if take and len(e) < 4500:
                block = '\n'.join(l.replace('`', "'")[:160] for l in take)
                if len(block) > 1000:
                    block = block[-1000:].split('\n', 1)[-1]
                e.add_field(name=f'{ark_services.name(sid)} · {ark_services.map_name(sid)} ({len(lines)})'[:256],
                            value=f'```\n{block}\n```', inline=False)
        if not total:
            e.description += '\n\nNothing found. Try fewer or different words, or check the text with `/nitrado logs`.'
        if notes:
            e.set_footer(text=' · '.join(notes)[:2048])
        kwargs = {'embed': e}
        if total:
            report = '\n\n'.join(f'===== {ark_services.name(s)} ({s}) =====\n' + '\n'.join(v) for s, v in results.items() if v)
            kwargs['file'] = discord.File(io.BytesIO(report.encode()), filename='log-search.txt')
        await i.followup.send(**kwargs, ephemeral=True)


async def setup(bot):
    await bot.add_cog(FindLogCog(bot))

"""Ticket embed URL handling and persistent uploaded media."""
import re
import asyncio
import ipaddress
import socket
import uuid
import aiohttp
from urllib.parse import urlsplit, urlunsplit
import discord
import db

MEDIA_KEYS = ('image', 'thumbnail', 'author_icon')

def clean_url(value):
    value = str(value or '').strip().strip('<>')
    match = re.fullmatch(r'!?\[[^\]]*\]\((https?://.+)\)', value)
    if match: value = match.group(1)
    if not value: return ''
    p = urlsplit(value)
    if p.scheme not in ('https', 'http') or not p.hostname or p.username or p.password or any(c.isspace() for c in value):
        raise ValueError('Use a public https:// image link, or upload an image with /ticket media. Leave the field empty to remove it.')
    host = p.hostname.lower()
    if host in ('discord.com', 'www.discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com') and p.path.startswith('/channels/'):
        raise ValueError('That is a message link. Right-click the image and choose Copy Media Link, or use /ticket media to upload it.')
    if host in ('imgur.com', 'www.imgur.com'):
        match = re.fullmatch(r'/([A-Za-z0-9]+)(?:\.(png|jpg|jpeg|gif|webp))?/?', p.path)
        if not match:
            raise ValueError('Imgur album/gallery pages are not image links. Use the direct image link or /ticket media.')
        return f'https://i.imgur.com/{match[1]}.{match[2] or "png"}'
    if host in ('cdn.discordapp.com', 'media.discordapp.net') and p.path.startswith('/attachments/'):
        # Keep the complete signed URL when retrieving the actual image bytes.
        return value
    if host in ('tenor.com', 'www.tenor.com', 'giphy.com', 'www.giphy.com'):
        raise ValueError('Use the direct GIF image URL, not the viewing page, or upload the GIF with /ticket media.')
    return value

def media_url(gid, cfg, key):
    filename = cfg.get(key + '_file')
    if filename and re.fullmatch(r'[a-f0-9]{32}\.(png|jpg|gif|webp)', filename):
        if (db.DATA / 'ticket_media' / str(gid) / filename).is_file():
            return 'attachment://' + filename
    return clean_url(cfg.get(key))

def media_files(gid, cfg):
    files = []
    for key in MEDIA_KEYS:
        url = media_url(gid, cfg, key)
        if url.startswith('attachment://'):
            filename = url.removeprefix('attachment://')
            if not any(f.filename == filename for f in files):
                files.append(discord.File(db.DATA / 'ticket_media' / str(gid) / filename, filename=filename))
    return files

def image_extension(data):
    if data.startswith(b'\x89PNG\r\n\x1a\n'): return 'png'
    if data.startswith(b'\xff\xd8\xff'): return 'jpg'
    if data.startswith((b'GIF87a', b'GIF89a')): return 'gif'
    if data.startswith(b'RIFF') and data[8:12] == b'WEBP': return 'webp'
    raise ValueError('Upload a PNG, JPG, GIF, or WebP image. Videos and webpage files cannot be embed images.')


MAX_BYTES = 2 * 1024 * 1024

class PublicResolver(aiohttp.abc.AbstractResolver):
    """Resolve only publicly routable destinations, including redirected hosts."""
    async def resolve(self, host, port=0, family=socket.AF_INET):
        addresses = await asyncio.get_running_loop().getaddrinfo(host, port, type=socket.SOCK_STREAM, family=family)
        results = []
        for af, _, proto, _, address in addresses:
            ip = address[0]
            if not ipaddress.ip_address(ip).is_global:
                raise OSError("Image URLs must point to a public image host.")
            results.append(dict(hostname=host, host=ip, port=port, family=af, proto=proto, flags=socket.AI_NUMERICHOST))
        return results

    async def close(self): pass


def check_destination(url):
    parsed = urlsplit(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Use a public HTTP or HTTPS image URL.')
    try: address = ipaddress.ip_address(parsed.hostname)
    except ValueError: return
    if not address.is_global:
        raise ValueError('Image URLs must point to a public image host.')


async def download_image(url):
    """Download the image now so Discord does not have to hotlink it later."""
    from urllib.parse import urljoin
    connector = aiohttp.TCPConnector(resolver=PublicResolver())
    timeout = aiohttp.ClientTimeout(total=20)
    try:
        async with aiohttp.ClientSession(connector=connector, timeout=timeout, trust_env=False) as session:
            for _ in range(6):
                check_destination(url)
                async with session.get(url, allow_redirects=False) as response:
                    if response.status in (301, 302, 303, 307, 308):
                        location = response.headers.get('Location')
                        if not location: raise ValueError('The image host returned an invalid redirect.')
                        url = urljoin(url, location)
                        continue
                    if response.status != 200:
                        raise ValueError(f'The image host returned HTTP {response.status}. Copy a fresh media link or use /ticket media to upload the image.')
                    if response.content_length and response.content_length > MAX_BYTES:
                        raise ValueError('Use an image smaller than 2 MB.')
                    data = bytearray()
                    async for chunk in response.content.iter_chunked(65536):
                        data.extend(chunk)
                        if len(data) > MAX_BYTES: raise ValueError('Use an image smaller than 2 MB.')
                    image_extension(data)
                    return bytes(data)
            raise ValueError('The image link redirected too many times. Use /ticket media instead.')
    except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as error:
        raise ValueError('Could not download that image. Copy a fresh direct media link, or upload the image with /ticket media.') from error


def store_image(gid, data):
    ext = image_extension(data)
    if len(data) > MAX_BYTES: raise ValueError('Use an image smaller than 2 MB.')
    folder = db.DATA / 'ticket_media' / str(gid)
    folder.mkdir(parents=True, exist_ok=True)
    filename = uuid.uuid4().hex + '.' + ext
    (folder / filename).write_bytes(data)
    return filename


async def cache_media(gid, cfg):
    candidate = cfg.copy()
    for key in MEDIA_KEYS:
        if candidate.get(key + '_file') and media_url(gid, candidate, key).startswith('attachment://'):
            continue
        url = clean_url(candidate.get(key))
        if url:
            candidate[key + '_file'] = store_image(gid, await download_image(url))
            candidate[key] = ''
    return candidate

"""Explicit allowlist: shared storage, configuration, and startup require restart."""
FEATURE_EXTENSIONS=('tickets','reviews','invites','welcome','profile','autoreact','giveaways','general','nitrado','ark_feed','population','log_channels','economy','hype','embeds','xbox_link','playtime','notifiers','findlog','ca','kd')
STARTUP_EXTENSIONS=(*FEATURE_EXTENSIONS,'maintenance')

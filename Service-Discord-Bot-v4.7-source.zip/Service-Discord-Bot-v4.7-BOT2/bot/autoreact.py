import re
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import emb, admin_check

# Settings key per guild: {"<channel_id>": {"emojis": [...], "include_bots": False}}
KEY = "autoreact_channels"
CUSTOM_EMOJI = re.compile(r"<a?:[A-Za-z0-9_]{2,32}:\d{15,25}>")


def load(guild_id):
    data = db.get_setting(guild_id, KEY, {}) or {}
    return data if isinstance(data, dict) else {}


def _split_unicode(token):
    """Split a run like '🔥👍❤️👨‍👩‍👧🇺🇸1️⃣' into separate emojis (keeps ZWJ, skin tones, flags, keycaps together)."""
    parts, cur = [], ""
    i = 0
    while i < len(token):
        ch = token[i]
        cp = ord(ch)
        joiner = cur and (cp in (0x200D, 0xFE0F, 0x20E3) or 0x1F3FB <= cp <= 0x1F3FF or 0xE0020 <= cp <= 0xE007F
                          or cur.endswith("\u200d"))
        flag_pair = cur and 0x1F1E6 <= cp <= 0x1F1FF and len(cur) == 1 and 0x1F1E6 <= ord(cur) <= 0x1F1FF
        if joiner or flag_pair:
            cur += ch
        else:
            if cur:
                parts.append(cur)
            cur = ch
        i += 1
    if cur:
        parts.append(cur)
    return parts


def parse_emojis(text):
    """Turn '🔥 👍 <:pog:123...>' (spaces, commas or nothing between) into a list of unique emojis, in order."""
    out = []
    for token in re.findall(r"<a?:[A-Za-z0-9_]{2,32}:\d{15,25}>|[^\s,<>]+", text or ""):
        pieces = [token] if token.startswith("<") else _split_unicode(token)
        for e in pieces:
            if e not in out:
                out.append(e)
    return out[:20]  # Discord allows 20 different reactions per message


class AutoReactGroup(app_commands.Group):
    def __init__(self):
        super().__init__(name="autoreact", description="Automatically react to messages in a channel", guild_only=True)

    @app_commands.command(name="set", description="Pick a channel and the reactions the bot adds to every message there")
    @admin_check()
    @app_commands.describe(channel="Channel to auto-react in",
                           emojis="Reactions, separated by spaces, e.g. 🔥 👍 <:pog:123456789>",
                           include_bots="Also react to messages from bots/webhooks (default: no)")
    async def set_(self, i: discord.Interaction, channel: discord.TextChannel, emojis: str, include_bots: bool = False):
        await i.response.defer(ephemeral=True)
        wanted = parse_emojis(emojis)
        if not wanted:
            return await i.followup.send("❌ Enter at least one emoji, e.g. `🔥 👍`.", ephemeral=True)
        perms = channel.permissions_for(i.guild.me)
        if not (perms.view_channel and perms.add_reactions and perms.read_message_history):
            return await i.followup.send(f"❌ I need View Channel, Add Reactions and Read Message History in {channel.mention}.", ephemeral=True)
        # Custom emojis must be from a server the bot is in, or Discord rejects the reaction.
        good, bad = [], []
        for e in wanted:
            try:
                discord.PartialEmoji.from_str(e)
                if CUSTOM_EMOJI.fullmatch(e):
                    eid = int(e.rsplit(":", 1)[1].rstrip(">"))
                    if not i.client.get_emoji(eid):
                        bad.append(e)
                        continue
                good.append(e)
            except Exception:
                bad.append(e)
        if not good:
            return await i.followup.send("❌ None of those reactions are usable. Custom emojis must be from a server I'm in.", ephemeral=True)
        data = load(i.guild.id)
        data[str(channel.id)] = {"emojis": good, "include_bots": bool(include_bots)}
        db.set_setting(i.guild.id, KEY, data)
        msg = f"✅ Auto-react on in {channel.mention}: {' '.join(good)}"
        if bad:
            msg += f"\n⚠️ Skipped (I can't use these): {' '.join(bad)}"
        await i.followup.send(msg, ephemeral=True)

    @app_commands.command(name="remove", description="Turn off auto-react in a channel")
    @admin_check()
    async def remove(self, i: discord.Interaction, channel: discord.TextChannel):
        data = load(i.guild.id)
        if data.pop(str(channel.id), None) is None:
            return await i.response.send_message(f"❌ Auto-react isn't on in {channel.mention}.", ephemeral=True)
        db.set_setting(i.guild.id, KEY, data)
        await i.response.send_message(f"✅ Auto-react turned off in {channel.mention}.", ephemeral=True)

    @app_commands.command(name="list", description="Show every auto-react channel and its reactions")
    @admin_check()
    async def list_(self, i: discord.Interaction):
        data = load(i.guild.id)
        if not data:
            return await i.response.send_message("No auto-react channels yet. Use `/autoreact set`.", ephemeral=True)
        lines = [f"<#{cid}> → {' '.join(cfg.get('emojis', []))}" + (" *(incl. bots)*" if cfg.get("include_bots") else "")
                 for cid, cfg in data.items()]
        await i.response.send_message(embed=emb("😀 Auto-React Channels", "\n".join(lines)), ephemeral=True)


class AutoReactCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.group = AutoReactGroup()
        bot.tree.add_command(self.group)

    async def cog_unload(self):
        self.bot.tree.remove_command("autoreact", type=discord.AppCommandType.chat_input)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.id == self.bot.user.id:
            return
        cfg = load(message.guild.id).get(str(message.channel.id))
        if not cfg:
            return
        if (message.author.bot or message.webhook_id) and not cfg.get("include_bots"):
            return
        for e in cfg.get("emojis", []):
            try:
                await message.add_reaction(e)
            except discord.HTTPException:
                continue


async def setup(bot):
    await bot.add_cog(AutoReactCog(bot))

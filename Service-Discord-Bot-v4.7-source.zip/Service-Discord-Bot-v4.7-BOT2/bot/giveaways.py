import random
import time
from datetime import datetime, timezone
import discord
from discord import app_commands
from discord.ext import commands, tasks
import db
from common import emb, admin_check

GIVEAWAY_COLOR = 0xF1C40F
ENDED_COLOR = 0x2B2D31
MAX_SECONDS = 60 * 24 * 3600  # 60 days
_rng = random.SystemRandom()


# ---------- database helpers ----------
def init_tables():
    with db.conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS giveaways(
          message_id INTEGER PRIMARY KEY,
          guild_id INTEGER NOT NULL,
          channel_id INTEGER NOT NULL,
          host_id INTEGER NOT NULL,
          prize TEXT NOT NULL,
          description TEXT,
          winners INTEGER NOT NULL DEFAULT 1,
          required_role_id INTEGER,
          ends_at INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'active',
          winner_ids TEXT
        );
        CREATE TABLE IF NOT EXISTS giveaway_entries(
          message_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          PRIMARY KEY(message_id, user_id)
        );
        """)


def get_giveaway(message_id):
    with db.conn() as c:
        return c.execute("SELECT * FROM giveaways WHERE message_id=?", (int(message_id),)).fetchone()


def entry_ids(message_id):
    with db.conn() as c:
        return [int(r["user_id"]) for r in c.execute("SELECT user_id FROM giveaway_entries WHERE message_id=?", (int(message_id),))]


def entry_count(message_id):
    with db.conn() as c:
        return c.execute("SELECT COUNT(*) AS n FROM giveaway_entries WHERE message_id=?", (int(message_id),)).fetchone()["n"]


def format_duration(seconds):
    seconds = int(seconds)
    parts = []
    for name, size in (("day", 86400), ("hour", 3600), ("minute", 60)):
        n, seconds = divmod(seconds, size)
        if n:
            parts.append(f"{n} {name}{'s' if n != 1 else ''}")
    return ", ".join(parts) or "less than a minute"


# ---------- embeds / views ----------
def giveaway_embed(row, entries, winners=None):
    ended = row["status"] != "active"
    lines = []
    if row["description"]:
        lines.append(row["description"] + "\n")
    if ended:
        if winners:
            lines.append(f"**Winner{'s' if len(winners) != 1 else ''}:** " + ", ".join(f"<@{w}>" for w in winners))
        elif row["status"] == "cancelled":
            lines.append("**Cancelled** — no winners.")
        else:
            lines.append("**No valid entries** — no winners.")
        lines.append(f"**Ended:** <t:{row['ends_at']}:R>")
    else:
        lines.append(f"**Ends:** <t:{row['ends_at']}:R> (<t:{row['ends_at']}:f>)")
        lines.append(f"**Winners:** {row['winners']}")
    if row["required_role_id"]:
        lines.append(f"**Required role:** <@&{row['required_role_id']}>")
    lines.append(f"**Hosted by:** <@{row['host_id']}>")
    lines.append(f"**Entries:** {entries}")
    e = discord.Embed(title=f"🎉 {row['prize']}", description="\n".join(lines),
                      color=ENDED_COLOR if ended else GIVEAWAY_COLOR)
    e.set_footer(text="Giveaway ended" if ended else "Press 🎉 to enter • press again to leave")
    e.timestamp = datetime.fromtimestamp(int(row["ends_at"]), tz=timezone.utc)
    return e


class GiveawayView(discord.ui.View):
    """Persistent: one registered instance handles the Enter button on every giveaway, even after restarts."""
    def __init__(self, count=0, ended=False):
        super().__init__(timeout=None)
        button = discord.ui.Button(label=f"Enter ({count})", emoji="🎉", style=discord.ButtonStyle.success,
                                   custom_id="giveaway:enter", disabled=ended)
        button.callback = self.enter
        self.add_item(button)

    async def enter(self, i: discord.Interaction):
        row = get_giveaway(i.message.id)
        if not row or row["status"] != "active" or row["ends_at"] <= time.time():
            return await i.response.send_message("❌ This giveaway has ended.", ephemeral=True)
        role_id = row["required_role_id"]
        if role_id and not any(r.id == int(role_id) for r in getattr(i.user, "roles", [])):
            return await i.response.send_message(f"❌ You need the <@&{role_id}> role to enter.", ephemeral=True)
        with db.conn() as c:
            exists = c.execute("SELECT 1 FROM giveaway_entries WHERE message_id=? AND user_id=?", (i.message.id, i.user.id)).fetchone()
            if exists:
                c.execute("DELETE FROM giveaway_entries WHERE message_id=? AND user_id=?", (i.message.id, i.user.id))
            else:
                c.execute("INSERT INTO giveaway_entries(message_id,user_id) VALUES(?,?)", (i.message.id, i.user.id))
        n = entry_count(i.message.id)
        await i.response.edit_message(embed=giveaway_embed(row, n), view=GiveawayView(n))
        await i.followup.send("👋 You left the giveaway." if exists else f"🎉 You're entered for **{row['prize']}**! Good luck.", ephemeral=True)


# ---------- ending / rerolling ----------
def pick_winners(guild, message_id, amount, exclude=()):
    pool = [u for u in entry_ids(message_id) if u not in exclude]
    if guild is not None and guild.chunked:
        pool = [u for u in pool if guild.get_member(u)]  # skip people who left the server
    return _rng.sample(pool, min(amount, len(pool)))


async def finish_giveaway(bot, row, cancelled=False):
    with db.conn() as c:
        updated = c.execute("UPDATE giveaways SET status=? WHERE message_id=? AND status='active'",
                            ("cancelled" if cancelled else "ended", row["message_id"])).rowcount
    if not updated:
        return None  # already ended by someone else
    guild = bot.get_guild(int(row["guild_id"]))
    winners = [] if cancelled else pick_winners(guild, row["message_id"], int(row["winners"]))
    with db.conn() as c:
        c.execute("UPDATE giveaways SET winner_ids=?, ends_at=? WHERE message_id=?",
                  (",".join(map(str, winners)), min(int(row["ends_at"]), int(time.time())), row["message_id"]))
    row = get_giveaway(row["message_id"])
    channel = bot.get_channel(int(row["channel_id"]))
    if channel is None:
        return winners
    n = entry_count(row["message_id"])
    try:
        msg = await channel.fetch_message(int(row["message_id"]))
        await msg.edit(embed=giveaway_embed(row, n, winners), view=GiveawayView(n, ended=True))
    except discord.HTTPException:
        msg = None
    if cancelled:
        return winners
    try:
        if winners:
            text = f"🎉 Congratulations {', '.join(f'<@{w}>' for w in winners)}! You won **{row['prize']}**!"
        else:
            text = f"No valid entries for **{row['prize']}**, so there are no winners."
        await channel.send(text, reference=msg.to_reference(fail_if_not_exists=False) if msg else None,
                           allowed_mentions=discord.AllowedMentions(users=True))
    except discord.HTTPException:
        pass
    return winners


# ---------- commands ----------
async def giveaway_autocomplete(i: discord.Interaction, current: str, statuses=("active",)):
    q = "SELECT message_id, prize, status FROM giveaways WHERE guild_id=? AND status IN (%s) ORDER BY ends_at DESC LIMIT 50" % ",".join("?" * len(statuses))
    with db.conn() as c:
        rows = c.execute(q, (i.guild.id, *statuses)).fetchall()
    return [app_commands.Choice(name=f"{r['prize']} ({r['status']})"[:100], value=str(r["message_id"]))
            for r in rows if current.lower() in r["prize"].lower() or current in str(r["message_id"])][:25]


async def active_autocomplete(i, current):
    return await giveaway_autocomplete(i, current, ("active",))


async def ended_autocomplete(i, current):
    return await giveaway_autocomplete(i, current, ("ended",))


def guild_giveaway(i, message_id):
    try:
        row = get_giveaway(int(str(message_id).strip()))
    except ValueError:
        return None
    return row if row and int(row["guild_id"]) == i.guild.id else None


class GiveawayGroup(app_commands.Group):
    def __init__(self, cog):
        super().__init__(name="giveaway", description="Run giveaways", guild_only=True)
        self.cog = cog

    @app_commands.command(name="start", description="Start a giveaway with a prize and a duration")
    @admin_check()
    @app_commands.describe(prize="What the winner gets", days="Days to run", hours="Hours to run", minutes="Minutes to run",
                           winners="How many winners (default 1)", channel="Where to post it (default: this channel)",
                           description="Extra text shown on the giveaway", required_role="Only members with this role can enter")
    async def start(self, i: discord.Interaction, prize: app_commands.Range[str, 1, 200],
                    days: app_commands.Range[int, 0, 60] = 0, hours: app_commands.Range[int, 0, 23] = 0,
                    minutes: app_commands.Range[int, 0, 59] = 0, winners: app_commands.Range[int, 1, 50] = 1,
                    channel: discord.TextChannel = None, description: app_commands.Range[str, 1, 1000] = None,
                    required_role: discord.Role = None):
        seconds = days * 86400 + hours * 3600 + minutes * 60
        if seconds < 60:
            return await i.response.send_message("❌ Set a duration of at least 1 minute (days / hours / minutes).", ephemeral=True)
        if seconds > MAX_SECONDS:
            return await i.response.send_message("❌ Giveaways can run for at most 60 days.", ephemeral=True)
        channel = channel or i.channel
        perms = channel.permissions_for(i.guild.me)
        if not (perms.view_channel and perms.send_messages and perms.embed_links):
            return await i.response.send_message(f"❌ I need View Channel, Send Messages and Embed Links in {channel.mention}.", ephemeral=True)
        await i.response.defer(ephemeral=True)
        ends_at = int(time.time()) + seconds
        row = {"message_id": 0, "guild_id": i.guild.id, "channel_id": channel.id, "host_id": i.user.id, "prize": prize.strip(),
               "description": (description or "").replace("\\n", "\n").strip() or None, "winners": winners,
               "required_role_id": required_role.id if required_role else None, "ends_at": ends_at, "status": "active", "winner_ids": None}
        msg = await channel.send(embed=giveaway_embed(row, 0), view=GiveawayView(0))
        with db.conn() as c:
            c.execute("""INSERT INTO giveaways(message_id,guild_id,channel_id,host_id,prize,description,winners,required_role_id,ends_at,status)
                         VALUES(?,?,?,?,?,?,?,?,?, 'active')""",
                      (msg.id, i.guild.id, channel.id, i.user.id, row["prize"], row["description"], winners, row["required_role_id"], ends_at))
        await i.followup.send(f"✅ Giveaway for **{row['prize']}** started in {channel.mention} — ends <t:{ends_at}:R> ({format_duration(seconds)}). [Jump]({msg.jump_url})", ephemeral=True)

    @app_commands.command(name="end", description="End a giveaway now and pick the winners")
    @admin_check()
    @app_commands.autocomplete(giveaway=active_autocomplete)
    @app_commands.describe(giveaway="The giveaway (pick from the list, or paste its message ID)")
    async def end(self, i: discord.Interaction, giveaway: str):
        row = guild_giveaway(i, giveaway)
        if not row or row["status"] != "active":
            return await i.response.send_message("❌ No running giveaway found with that ID.", ephemeral=True)
        await i.response.defer(ephemeral=True)
        winners = await finish_giveaway(i.client, row)
        await i.followup.send(f"✅ Ended **{row['prize']}**. Winners: {', '.join(f'<@{w}>' for w in winners or []) or 'none'}", ephemeral=True)

    @app_commands.command(name="reroll", description="Pick new winner(s) for an ended giveaway")
    @admin_check()
    @app_commands.autocomplete(giveaway=ended_autocomplete)
    @app_commands.describe(giveaway="The ended giveaway", winners="How many new winners to pick (default 1)")
    async def reroll(self, i: discord.Interaction, giveaway: str, winners: app_commands.Range[int, 1, 50] = 1):
        row = guild_giveaway(i, giveaway)
        if not row or row["status"] != "ended":
            return await i.response.send_message("❌ That giveaway hasn't ended (or doesn't exist).", ephemeral=True)
        old = {int(x) for x in (row["winner_ids"] or "").split(",") if x}
        new = pick_winners(i.guild, row["message_id"], winners, exclude=old)
        if not new:
            return await i.response.send_message("❌ No other entrants left to pick from.", ephemeral=True)
        with db.conn() as c:
            c.execute("UPDATE giveaways SET winner_ids=? WHERE message_id=?", (",".join(map(str, list(old) + new)), row["message_id"]))
        channel = i.guild.get_channel(int(row["channel_id"]))
        await i.response.send_message(f"🔁 Rerolled **{row['prize']}**.", ephemeral=True)
        if channel:
            await channel.send(f"🎉 New winner{'s' if len(new) != 1 else ''}: {', '.join(f'<@{w}>' for w in new)}! You won **{row['prize']}**!",
                               allowed_mentions=discord.AllowedMentions(users=True))

    @app_commands.command(name="cancel", description="Cancel a running giveaway without picking winners")
    @admin_check()
    @app_commands.autocomplete(giveaway=active_autocomplete)
    async def cancel(self, i: discord.Interaction, giveaway: str):
        row = guild_giveaway(i, giveaway)
        if not row or row["status"] != "active":
            return await i.response.send_message("❌ No running giveaway found with that ID.", ephemeral=True)
        await i.response.defer(ephemeral=True)
        await finish_giveaway(i.client, row, cancelled=True)
        await i.followup.send(f"🛑 Cancelled **{row['prize']}**.", ephemeral=True)

    @app_commands.command(name="list", description="Show running giveaways")
    async def list_(self, i: discord.Interaction):
        with db.conn() as c:
            rows = c.execute("SELECT * FROM giveaways WHERE guild_id=? AND status='active' ORDER BY ends_at", (i.guild.id,)).fetchall()
        if not rows:
            return await i.response.send_message("No giveaways are running. Start one with `/giveaway start`.", ephemeral=True)
        lines = [f"🎉 **{r['prize']}** — <#{r['channel_id']}> • ends <t:{r['ends_at']}:R> • {entry_count(r['message_id'])} entries • "
                 f"[jump](https://discord.com/channels/{r['guild_id']}/{r['channel_id']}/{r['message_id']})" for r in rows]
        await i.response.send_message(embed=emb("🎉 Running Giveaways", "\n".join(lines)[:4000], GIVEAWAY_COLOR), ephemeral=True)


class GiveawayCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._finishing=set()
        init_tables()
        self.group = GiveawayGroup(self)
        bot.tree.add_command(self.group)
        self.view=GiveawayView()
        bot.add_view(self.view)  # keeps Enter buttons working after restarts/reloads

    async def cog_load(self):
        for view in list(self.bot.persistent_views):
            if type(view).__module__==__name__ and view is not self.view: view.stop()
        self.ender.start()

    async def cog_unload(self):
        task=self.ender.get_task()
        self.ender.cancel()
        if task:
            import asyncio
            await asyncio.gather(task,return_exceptions=True)
            if self._finishing:
                await asyncio.gather(*self._finishing,return_exceptions=True)
        self.view.stop()
        self.bot.tree.remove_command("giveaway", type=discord.AppCommandType.chat_input)

    @tasks.loop(seconds=10)
    async def ender(self):
        with db.conn() as c:
            due = c.execute("SELECT * FROM giveaways WHERE status='active' AND ends_at<=?", (int(time.time()),)).fetchall()
        for row in due:
            try:
                import asyncio
                finishing=asyncio.create_task(finish_giveaway(self.bot,row))
                self._finishing.add(finishing)
                finishing.add_done_callback(self._finishing.discard)
                await asyncio.shield(finishing)
            except Exception as e:
                print(f"Giveaway end error ({row['message_id']}): {e}")

    @ender.before_loop
    async def before_ender(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(GiveawayCog(bot))

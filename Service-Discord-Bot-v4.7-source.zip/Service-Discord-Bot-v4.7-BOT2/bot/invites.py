import asyncio
import logging
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import admin_check

log = logging.getLogger(__name__)

def attribute(previous, current):
    """Only attribute a single observed use; batches/deleted invites are unknown."""
    if previous is None: return None
    changes = [(value[1], value[0] - previous.get(code, (0, None))[0]) for code, value in current.items() if value[0] > previous.get(code, (0, None))[0]]
    if len(changes) == 1 and changes[0][1] == 1:
        return changes[0][0]
    return None

def record_join(gid, uid, inviter):
    with db.conn() as c:
        c.execute('INSERT INTO invite_members(guild_id, member_id, inviter_id, active) VALUES(?,?,?,1) ON CONFLICT(guild_id,member_id) DO UPDATE SET active=1', (gid, uid, inviter))

def counts(gid, uid):
    with db.conn() as c:
        r=c.execute('SELECT COUNT(*) total, COALESCE(SUM(active),0) active FROM invite_members WHERE guild_id=? AND inviter_id=?', (gid, uid)).fetchone()
        return r['total'], r['active']

class InviteCog(commands.Cog):
    def __init__(self, bot):
        self.bot=bot
        self.cache=getattr(bot,'_invite_cache',{})
        self.locks=getattr(bot,'_invite_locks',{})
        bot._invite_cache=self.cache
        bot._invite_locks=self.locks
        with db.conn() as c:
            c.execute('CREATE TABLE IF NOT EXISTS invite_members(guild_id INTEGER, member_id INTEGER, inviter_id INTEGER, active INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(guild_id,member_id))')

    def lock(self, gid):
        return self.locks.setdefault(gid, asyncio.Lock())

    async def snapshot(self, guild):
        try:
            return {v.code: (v.uses or 0, db.get_setting(guild.id,f'invite_requester:{v.code}',v.inviter.id if v.inviter else None)) for v in await guild.invites()}
        except discord.HTTPException:
            log.warning('Invite tracking unavailable in %s: check Manage Server permission.', guild.id)
            return None

    @commands.Cog.listener()
    async def on_ready(self):
        for guild in self.bot.guilds:
            async with self.lock(guild.id):
                self.cache[guild.id]=await self.snapshot(guild)
                # Reconcile departures that occurred while the bot was offline.
                if guild.chunked:
                    present={m.id for m in guild.members}
                    with db.conn() as c:
                        rows=c.execute('SELECT member_id FROM invite_members WHERE guild_id=?', (guild.id,)).fetchall()
                        c.executemany('UPDATE invite_members SET active=? WHERE guild_id=? AND member_id=?', [(int(r['member_id'] in present),guild.id,r['member_id']) for r in rows])

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        async with self.lock(guild.id): self.cache[guild.id]=await self.snapshot(guild)

    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        async with self.lock(invite.guild.id):
            cached=self.cache.get(invite.guild.id)
            if cached is not None:
                cached.setdefault(invite.code, (invite.uses or 0, invite.inviter.id if invite.inviter else None))

    @commands.Cog.listener()
    async def on_member_join(self, member):
        async with self.lock(member.guild.id):
            previous=self.cache.get(member.guild.id)
            current=await self.snapshot(member.guild)
            inviter=attribute(previous,current) if current is not None else None
            self.cache[member.guild.id]=current
            if member.bot: return
            if inviter == member.id: inviter=None
            record_join(member.guild.id, member.id, inviter)
            with db.conn() as c:
                row=c.execute('SELECT inviter_id FROM invite_members WHERE guild_id=? AND member_id=?',(member.guild.id,member.id)).fetchone()
                credited=row['inviter_id']
            channel=member.guild.get_channel(db.get_setting(member.guild.id,'invite_channel',0))
            if channel:
                text=f'{member.mention} joined. '
                text+=f'Observed inviter: <@{inviter}>.' if inviter else 'Inviter: unknown (no unambiguous invite use).'
                if credited:
                    total,active=counts(member.guild.id,credited)
                    text+=f'\nOriginal inviter <@{credited}>: **{active}** current / **{total}** unique invites.'
                try: await channel.send(text, allowed_mentions=discord.AllowedMentions.none())
                except discord.HTTPException: log.warning('Cannot post invite log in %s', member.guild.id)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        async with self.lock(member.guild.id):
            with db.conn() as c:
                c.execute('UPDATE invite_members SET active=0 WHERE guild_id=? AND member_id=?',(member.guild.id,member.id))

    @app_commands.command(name='invite-setup', description='Choose the channel for invite join logs')
    @app_commands.guild_only()
    @admin_check()
    async def setup_invites(self, i: discord.Interaction, channel: discord.TextChannel):
        db.set_setting(i.guild_id,'invite_channel',channel.id)
        await i.response.send_message(f'Invite logs will appear in {channel.mention}. I need Manage Server to read invite uses.',ephemeral=True)

    @app_commands.command(name='invites', description='See your or another member’s tracked invites')
    @app_commands.guild_only()
    async def invites(self, i: discord.Interaction, member: discord.Member=None):
        member=member or i.user
        total,active=counts(i.guild_id,member.id)
        await i.response.send_message(f'{member.mention}: **{active}** current invites · **{total}** unique invites · **{total-active}** left.\nTracking starts when the bot is online; unknown joins are not credited.', allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name='invited-by', description='See who originally invited a tracked member')
    @app_commands.guild_only()
    async def invited_by(self, i: discord.Interaction, member: discord.Member=None):
        member=member or i.user
        with db.conn() as c:
            row=c.execute('SELECT inviter_id FROM invite_members WHERE guild_id=? AND member_id=?',(i.guild_id,member.id)).fetchone()
        who=f"<@{row['inviter_id']}>" if row and row['inviter_id'] else 'Unknown / not tracked'
        await i.response.send_message(f'{member.mention} — original inviter: {who}', allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name='invite-leaderboard', description='Top inviters, ranked by members still in the server')
    @app_commands.guild_only()
    async def leaderboard(self, i: discord.Interaction):
        with db.conn() as c:
            rows=c.execute('SELECT inviter_id, COUNT(*) total, SUM(active) active FROM invite_members WHERE guild_id=? AND inviter_id IS NOT NULL GROUP BY inviter_id ORDER BY active DESC,total DESC,inviter_id LIMIT 20',(i.guild_id,)).fetchall()
        text='\n'.join(f"{n}. <@{r['inviter_id']}> — {r['active']} current / {r['total']} unique" for n,r in enumerate(rows,1)) or 'No attributed invites yet.'
        await i.response.send_message(text,allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name='invite-links', description='Show your active invite links')
    @app_commands.guild_only()
    @app_commands.checks.cooldown(1,30,key=lambda i:(i.guild_id,i.user.id))
    async def links(self, i: discord.Interaction):
        await i.response.defer(ephemeral=True)
        links=[v for v in await i.guild.invites() if v.inviter and v.inviter.id==i.user.id]
        await i.followup.send(('\n'.join(f'{v.url} — {v.uses or 0} uses' for v in links) or 'No active invite links.')[:1900],ephemeral=True)

    @app_commands.command(name='invite-create', description='Create a one-day invite to this channel')
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(create_instant_invite=True)
    @app_commands.checks.cooldown(1,60,key=lambda i:(i.guild_id,i.user.id))
    async def create(self, i: discord.Interaction):
        await i.response.defer(ephemeral=True)
        invite=await i.channel.create_invite(max_age=86400,unique=True,reason=f'Invite requested by {i.user}')
        # Discord attributes bot-created invites to the bot; record the requester locally.
        async with self.lock(i.guild_id):
            cached=self.cache.get(i.guild_id)
            if cached is not None: cached[invite.code]=(0,i.user.id)
            db.set_setting(i.guild_id,f'invite_requester:{invite.code}',i.user.id)
        await i.followup.send(invite.url,ephemeral=True)


async def setup(bot):
    await bot.add_cog(InviteCog(bot))

"""Read-only discovery of log files in known ARK game directories."""
import posixpath
from nitrado_api import NitradoError
from nitrado_discovery import log_candidates


async def find_log(api,sid):
    details=await api.details(sid)
    candidates=log_candidates(details)
    if candidates:
        return sorted(candidates,key=lambda p:('shootergame.log' not in p.lower(),'server' not in posixpath.basename(p).lower(),p))[0]
    bookmarks=await api.request('GET',f'/services/{sid}/gameservers/file_server/bookmarks')
    queue=[(path,0) for path in bookmarks.get('bookmarks',[]) if isinstance(path,str)]
    if not queue: queue=[('',0)]
    seen=set()
    found=[]
    for _ in range(24):
        if not queue: break
        folder,depth=queue.pop(0)
        if folder in seen: continue
        seen.add(folder)
        data=await api.request('GET',f'/services/{sid}/gameservers/file_server/list',params={'dir':folder} if folder else None)
        for entry in data.get('entries',[]):
            path=entry.get('path')
            name=str(entry.get('name') or posixpath.basename(path or '')).lower()
            if not isinstance(path,str): continue
            if entry.get('type')=='file' and name.endswith('.log') and name not in ('restart.log','install.log','update.log'):
                found.append((path,int(entry.get('modified_at') or 0)))
            elif entry.get('type') in ('dir','directory') and depth<5 and (name.startswith('ark') or name in ('shootergame','saved','logs','log','logfiles')):
                queue.append((path,depth+1))
    if not found: raise NitradoError('No readable ARK game log was discovered. Check Nitrado file-browser permissions and enable server logging, then rerun /logs-setup. No log connection is active.')
    return sorted(found,key=lambda pair:('shootergame.log' not in pair[0].lower(),-pair[1],pair[0]))[0][0]

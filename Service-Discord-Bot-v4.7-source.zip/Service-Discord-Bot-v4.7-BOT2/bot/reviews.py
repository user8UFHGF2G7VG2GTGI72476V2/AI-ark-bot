import asyncio
import time
import discord
from discord import app_commands
from discord.ext import commands
import db
from common import admin_check, color_int

DEFAULT = dict(channel_id=0, content='', title='📌 | Leave us a review', description='↳ {channel}\nUse /review to tell us about the service you received.', color='00D9ED', thumbnail='', image='', footer='')

def config(gid):
    return DEFAULT | (db.get_setting(gid, 'reviews', {}) or {})

def prompt_embed(c):
    e = discord.Embed(title=c['title'] or None, description=c['description'].replace('{channel}', f"<#{c['channel_id']}>") or None, color=color_int(c['color']))
    if c['thumbnail']: e.set_thumbnail(url=c['thumbnail'])
    if c['image']: e.set_image(url=c['image'])
    if c['footer']: e.set_footer(text=c['footer'])
    return e

class ReviewForm(discord.ui.Modal, title='Leave a review'):
    service = discord.ui.TextInput(label='Service received', max_length=100)
    rating = discord.ui.TextInput(label='Rating (1–5)', max_length=1, placeholder='5')
    review = discord.ui.TextInput(label='Your review', style=discord.TextStyle.paragraph, max_length=2000)

    def __init__(self, cog):
        super().__init__(timeout=600)
        self.cog = cog

    async def on_submit(self, i):
        c = config(i.guild_id)
        if i.channel_id != c['channel_id']:
            return await i.response.send_message('The review channel changed. Run /review in the configured channel.', ephemeral=True)
        if self.rating.value not in ('1','2','3','4','5') or not self.service.value.strip() or not self.review.value.strip():
            return await i.response.send_message('Enter a rating from 1 to 5 and fill out both text fields.', ephemeral=True)
        await i.response.defer(ephemeral=True)
        async with self.cog.locks.setdefault((i.guild_id, i.user.id), asyncio.Lock()):
            key = f'review_last_{i.user.id}'
            if time.time() - db.get_setting(i.guild_id, key, 0) < 300:
                return await i.followup.send('Please wait five minutes between reviews.', ephemeral=True)
            e = discord.Embed(title='★' * int(self.rating.value) + '☆' * (5-int(self.rating.value)), description=self.review.value.strip(), color=color_int(c['color']), timestamp=discord.utils.utcnow())
            e.set_author(name=i.user.display_name, icon_url=i.user.display_avatar.url)
            e.add_field(name='Service', value=self.service.value.strip(), inline=False)
            e.set_footer(text=f'Reviewer ID: {i.user.id}')
            try:
                await i.channel.send(embed=e, allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                return await i.followup.send('Could not post your review. Ask an admin to check my channel permissions.', ephemeral=True)
            db.set_setting(i.guild_id, key, time.time())
            await i.followup.send('Thank you! Your review has been posted.', ephemeral=True)

class ReviewCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.locks = {}

    @app_commands.command(name='review-setup', description='Customize the !r prompt and choose the review channel')
    @app_commands.guild_only()
    @admin_check()
    async def setup_reviews(self, i: discord.Interaction, channel: discord.TextChannel,
                            title: app_commands.Range[str, 1, 256] = None,
                            description: app_commands.Range[str, 1, 3000] = None,
                            message: app_commands.Range[str, 1, 1800] = None,
                            color: str = None, thumbnail: str = None, image: str = None,
                            footer: app_commands.Range[str, 1, 500] = None):
        c = config(i.guild_id)
        c['channel_id'] = channel.id
        for key, value in dict(title=title, description=description, content=message, color=color, thumbnail=thumbnail, image=image, footer=footer).items():
            if value is not None: c[key] = '' if value == '-' and key != 'color' else value.replace('\\n', '\n')
        try:
            color_int(c['color'])
            for key in ('thumbnail', 'image'):
                if c[key] and not c[key].startswith(('https://', 'http://')):
                    raise ValueError('Image URLs must start with https:// or http://.')
        except ValueError as exc:
            return await i.response.send_message(str(exc), ephemeral=True)
        if not c['title'] and not c['description']:
            return await i.response.send_message('Keep an embed title or description.', ephemeral=True)
        db.set_setting(i.guild_id, 'reviews', c)
        await i.response.send_message('Saved. Type !r to post this prompt. Use {channel} in its description; - clears an optional field.', embed=prompt_embed(c), ephemeral=True)

    @commands.command(name='r')
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.channel)
    async def prompt(self, ctx):
        c = config(ctx.guild.id)
        if not ctx.guild.get_channel(c['channel_id']):
            return await ctx.send('An administrator needs to run /review-setup first.')
        await ctx.send(c['content'].replace('{channel}', f"<#{c['channel_id']}>") or None, embed=prompt_embed(c), allowed_mentions=discord.AllowedMentions.none())

    @prompt.error
    async def prompt_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f'Please wait {error.retry_after:.0f} seconds.', delete_after=5)
        elif isinstance(error, commands.CommandInvokeError):
            print(f'Review prompt failed: {type(error.original).__name__}')

    @app_commands.command(name='review', description='Leave a review of a service you received')
    @app_commands.guild_only()
    async def review_cmd(self, i: discord.Interaction):
        c = config(i.guild_id)
        if not c['channel_id']:
            return await i.response.send_message('Reviews are not configured yet.', ephemeral=True)
        if i.channel_id != c['channel_id']:
            return await i.response.send_message(f"Please use /review in <#{c['channel_id']}>.", ephemeral=True)
        await i.response.send_modal(ReviewForm(self))


async def setup(bot):
    await bot.add_cog(ReviewCog(bot))

>>> NEW IN v4.7: embed maker, Link Gamertag / Kick Me / Playtime panels, notifiers,
>>> /linknitrado and /add information. Read README_V4.7.txt first.

v4.6 UPDATE — CREDITS, WHEEL SPIN, MYSTERY BOXES, PRIZES, HYPE
(fused in from Fent Discord Manager v1.2. The old /credit balance / adjust
commands are gone; /credit daily and /credit pay are kept.)

FIRST TIME SETUP
1. Run INSTALL.bat (installs Python packages incl. Pillow for the wheel).
2. Open .env, paste your bot token after DISCORD_TOKEN=, save.
3. Run START-BOT.bat.
4. In Discord: /economy setup staff_role:@Staff
   -> makes private 🎁・prize-claims and 💰・economy-logs channels.
5. Set your prizes: /wheel option-add  and  /mysterybox option-add
   (starts with ARK prize examples — wipe them with option-clear).

UPGRADING FROM v4.5: copy your old data folder + .env over. Old credit
balances and daily cooldowns move over automatically on first start.

CREDITS ("Staff" = role from /economy staff-role, plus admins)
/credit give member amount [reason]     Staff
/credit remove member amount [reason]   Staff
/credit view [member]                   Anyone (shows credits, boxes, spins)
/credit leaderboard                     Anyone (pages with ◀ ▶)
/credit daily                           Anyone: free daily credits (default 100)
/credit pay member amount               Anyone: send your credits to someone

MYSTERY BOXES
/mysterybox give / remove member [amount]   Staff
/mysterybox view [member] / leaderboard     Anyone
/mysterybox open                            Anyone with a box (animated unbox)
/mysterybox buy [amount]                    Anyone: buy with credits (if priced)
/mysterybox options                         Anyone: every prize + odds
/mysterybox option-add name [weight]        Staff (higher weight = more common)
/mysterybox option-remove name / option-clear   Staff

WHEEL SPIN
/wheel spin                             Anyone with a spin: animated spinning wheel GIF
/wheel give / remove member [amount]    Staff
/wheel view [member] / leaderboard      Anyone
/wheel buy [amount]                     Anyone: buy spins with credits (if priced)
/wheel options                          Anyone: picture of the wheel + odds
/wheel option-add name [weight]         Staff (weight = slice size)
/wheel option-remove name / option-clear    Staff

SETTINGS
/economy setup staff_role               Admin: create prize + log channels
/economy staff-role role                Admin
/economy log-channel / prize-channel    Admin
/economy prices item price              Admin: credits per spin/box (0 = not for sale)
/economy daily credits                  Admin: daily amount (0 = off)
/economy settings                       Show everything

PRIZES (every box/wheel win posts in prize-claims with a "Mark Delivered"
button; the player gets a DM when it's delivered)
/prizes pending        Staff
/prizes deliver #      Staff
/prizes mine           Anyone

GAMERTAG LINK (shown on prize claims so staff know who to deliver to)
/link set gamertag  /link view [member]  /link remove
/link staff-set member gamertag  /link find gamertag   Staff

NAME-TAG REWARD (off until you set it up)
/nametag setup tag [credits] [ends] [announce_channel]   Admin
   e.g. tag:!Iceden credits:5 -> anyone with !Iceden in their name gets 5 credits once
/nametag scan / toggle   Admin      /nametag status   Anyone

HYPE EVENTS (wipe / launch countdowns)
/hype start when:"10/03 6:00PM" [title] [description] [channel] [ping_role] [image]
    Countdown post with a 🔥 I'm Hyped button + hype bar, reminders at
    24h / 1h / 10min and an "IS LIVE" post at go time. Uses TIMEZONE in .env.
/hype channel #channel   Admin: default channel
/hype list  /hype who event_id  /hype cancel event_id

NEW PERMISSION: give the bot "Attach Files" (wheel GIF) and "Manage Channels"
(for /economy setup).

========================================================================

v3.0 UPDATE — CUSTOM TICKETS, AUTO-REACT, TICKET CLOSE PERMISSION (v3.2)
- /ticket close-role-add role:@admins — that role can press Close / use
  /ticket close, and can see tickets (added to open ones + all new ones).
- /ticket close-role-remove role:@admins   /ticket close-roles (show list)
- Members with Discord's Administrator permission can always close.
- The bot needs Manage Channels to delete a closed ticket; it now tells you
  if that's missing instead of failing.

GOODBYE MESSAGES
- /goodbye edit channel:#goodbyes — same visual editor as welcome. Change the
  message, title, description, color, image, thumbnail and footer, then Save.
  "DM Message" sets the private message sent to the person who left;
  "Toggle DM" turns that DM on/off. Leave channel empty for DM only.
- Placeholders: {user} {mention} {server} {member_count}
- /goodbye test (posts + DMs you a test) • /goodbye status • /goodbye disable
- Note: Discord only delivers the DM if the person still shares another
  server with the bot and accepts DMs. If not, it's skipped silently; the
  channel message is always posted.

GIVEAWAYS
Stop the bot, copy this bot folder over your old one (keep .env and data),
then run START-BOT.bat. New commands can take a few minutes to show up.
NEW PERMISSION: give the bot "Add Reactions" (for auto-react).

CUSTOM TICKET SYSTEM
- The ticket panel now starts with NO options. /ticket panel-edit shows a
  greyed-out dropdown preview listing your current options.
- Add options:    /add ticket-option emoji:🎨 name:Design category:Design Tickets
                  (optional description: small text under the option)
- Remove options: /remove ticket-option option:Design   (pick from the list)
- The posted panel refreshes automatically. With zero options the panel shows
  no dropdown; it appears as soon as you add the first option. Max 25.
- Upgrading: the old built-in Support / Purchase / Report options are removed
  once. Options you added yourself are kept.

AUTO-REACT
- /autoreact set channel:#showcase emojis:🔥 👍 <:custom:123>  (include_bots optional)
  The bot reacts to every new message in that channel with those emojis.
  Running it again for the same channel replaces its emojis. Up to 20 emojis.
  Custom emojis must be from a server the bot is in.
- /autoreact remove channel:#showcase   /autoreact list

GIVEAWAYS
- /giveaway start prize:Huge Cat days:1 hours:2 minutes:30 winners:1
  Optional: channel, description, required_role. Minimum 1 minute, max 60 days.
  Members press the 🎉 Enter button (press again to leave). Ends automatically,
  edits the post with the winners and pings them. Survives bot restarts
  (if the bot was offline when it should end, it ends as soon as it's back on).
- /giveaway end   — end early and pick winners now
- /giveaway reroll — pick new winner(s) for an ended giveaway
- /giveaway cancel — stop without winners      /giveaway list — running ones

TICKET IMAGES v2.1 — INSTALL THIS UPDATE
Stop the bot before updating. Copy the included bot folder over the bot folder
in the installation you actually launch. Keep your existing .env and data.
Run INSTALL.bat if dependencies need updating, then START-BOT.bat.
Open a NEW /ticket panel-edit. Its message must say "Ticket media editor v2.1".
If it does not, you are running a different folder or the old process.

Use the existing Banner / Image and Thumbnail buttons and paste a fresh direct
image link. The bot now downloads the image, validates its format, saves it
in data/ticket_media, and uploads it as an embed attachment. The thumbnail
appears at the top right; the banner appears below the description.
Press Save + Post to publish. Both images survive further edits and restarts.
A broken, expired, or non-image link shows an error and preserves the last
working image. Leave a media field empty to clear that image only.
PNG, JPG, GIF and WebP are supported, up to 2 MB per image.
/ticket media is also available for direct file uploads.
Keep data/ticket_media when moving or backing up the bot.
The bot needs Embed Links and Attach Files in the destination channel.

Regression tests cover both image fields through modal submission, preview,
posting, saving, reloading, text editing and independent removal. HTTP failures
are simulated; live rendering on your Discord account has not been verified.

SERVICE DISCORD BOT — START HERE

1. Extract the ZIP into its own folder. Install Python 3.12 if needed.
2. Run INSTALL.bat. It creates .env from .env.example.
3. Open .env locally and put your bot token after DISCORD_TOKEN=.
   Do not share the token in chat. If upgrading the old bot, add your server ID
   after GUILD_ID= so old server-specific commands are removed.
4. In https://discord.com/developers/applications select your application.
   On the Bot page enable SERVER MEMBERS INTENT and MESSAGE CONTENT INTENT.
   Install to your server using bot and applications.commands scopes.
5. Permissions: View Channels, Send Messages, Embed Links, Attach Files,
   Read Message History, Manage Channels (tickets), Manage Server (invites),
   and Change Nickname (profile). Grant these in the relevant channels too.
   Members need Use Application Commands in the review channel.
6. Run START-BOT.bat. Leave it running on a computer or host to stay online.
   Slash commands are synced globally; Discord may take time to refresh them.

CONFIGURE IN DISCORD
/set-profile — server name, avatar, banner; always clears the server bio.
/ticket config — select ticket category and staff role.
/ticket panel-edit — customize the ticket panel, then save/post it.
/ticket post — publish the saved panel.
/welcome edit — pick a channel and customize welcome text/embed; press Save.
/review-setup channel:#reviews — select the review channel and customize !r.
/invite-setup channel:#invite-logs — select the invite notification channel.

REVIEWS
Anyone can type !r to show the review prompt in their current channel.
Default: a cyan embed titled '📌 | Leave us a review' linking to your channel.
/review-setup accepts title, description, message, color, thumbnail, image,
and footer. Omitted options retain previous values. Use - to clear a text
or image field, {channel} to link the selected channel, and \n for a newline.
Example: /review-setup channel:#reviews title:📌 | Leave us a review
Choose your own logo URL for thumbnail to match the reference's layout.
Anyone can run /review IN #reviews. A form asks for service, rating 1–5,
and their review, then posts an attributed embed. Five-minute per-user
cooldown prevents repeated posts. Reviews are user submissions, not verified
purchase claims. Administrators can delete a review message normally.

INVITES
/invites [member] — current, unique total, and departed invite counts.
/invited-by [member] — original tracked inviter.
Tracking starts while online and needs Manage Server permission. It compares
invite use counts. Deleted/single-use links, vanity links, concurrent joins,
missing permissions, or joins during downtime may be unknown. Historical
inviter identities cannot be reconstructed. Rejoins do not inflate unique
counts or transfer original invite credit. Counts/settings persist in data/.

NO BIO
Startup clears the application Description and every connected server bio.
/set-profile also sends an empty bio; there is no bio input or activity text.
If Discord rejects clearing a profile, the console reports it. Clear the
Description in Developer Portal manually if needed. Check the actual profile
after the first login; live account verification was not available here.

KEPT / REMOVED
Kept the original ticket functions, including claiming, transcripts, closing,
and its existing staff pay logging. Kept welcome editing.
Removed reaction roles, autoroles, general logs, suggestions,
announcements, generic embed tools, and the old starter-server command.
Bot setup and profile/review configuration require Administrator permission.

UPGRADING
Stop the previous bot before launching this version. To preserve settings
and open tickets, copy your previous data folder into this extracted folder
while BOTH versions are stopped. Back up that folder first. Existing ticket
panel and action buttons are restored. Use only one process per bot token.

VALIDATION
Local Python 3.12 / discord.py 2.6.4 checks passed: command serialization,
command scope, ticket persistent views, invite ambiguity and rejoin counting,
review prompt customization, and review channel enforcement.
No live Discord login, hosted deployment, or end-to-end server test performed.

API REFERENCES
https://github.com/discord/discord-api-docs/blob/main/developers/resources/guild.mdx
https://github.com/discord/discord-api-docs/blob/main/developers/resources/application.mdx
https://discordpy.readthedocs.io/en/latest/api.html

TICKET MEDIA FIX
- /ticket media: choose Banner / Image, Thumbnail, or Author Icon and attach
  a PNG, JPG, GIF, or WebP smaller than 2 MB. Images are saved in data/ticket_media.
- After uploading, CLOSE any old editor, reopen /ticket panel-edit, and use
  Save + Post. This updates the saved panel. /ticket post creates a new panel.
- Existing URL fields still work. Copy Media Link from an image, not Copy
  Message Link. Signed Discord links are retained while downloading; saved images are attached directly.
  Direct Imgur image pages are converted; gallery and GIF viewing pages show
  an actionable error. External sites must allow Discord to load the image.
- Longer links are accepted. The editor reports rejected embeds, invalid
  colors, excessive embed text, and missing permissions rather than failing
  silently. Save + Post acknowledges the interaction before network requests.
- Give the bot View Channel, Send Messages, Embed Links, and Attach Files in
  the target channel. If ALL embeds are hidden for only you, check Discord
  Settings > Chat for embed/link preview display options.
- Stop the old bot. Extract this version to a separate folder; copy your .env
  and entire data folder into it, then run INSTALL.bat and START-BOT.bat.
  Keep the old folder as a backup. Do not run both versions simultaneously.
- Local regression checks passed, including Discord rejection and permission
  failure simulations. Live Discord rendering has not been verified.

ADD TICKET OPTIONS
/add ticket-option emoji:🎨 name:Design category:Design Tickets
Administrator only. Adds to the existing Support/Purchase/Report options and
refreshes the most recently posted ticket panel without changing its images.
The selected Discord category is where tickets for the new option are created.
Names must be unique; a dropdown supports up to 25 options. If no panel exists,
use /ticket post after adding options. Restart the bot to sync the new command.

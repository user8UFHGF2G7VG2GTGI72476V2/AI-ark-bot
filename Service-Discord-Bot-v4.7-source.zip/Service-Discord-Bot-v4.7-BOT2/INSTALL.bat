@echo off
title Service Manager BOT 2 - Install
cd /d "%~dp0"
if not exist .venv (
  py -3.12 -m venv .venv 2>nul || py -3 -m venv .venv
)
if not exist .venv\Scripts\activate.bat goto failed
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
if not exist .env copy .env.example .env >nul
echo.
echo Installed. Open .env and add your Discord bot token.
pause
exit /b 0
:failed
echo Installation failed. Install Python 3.12 and check the error above.
pause
exit /b 1

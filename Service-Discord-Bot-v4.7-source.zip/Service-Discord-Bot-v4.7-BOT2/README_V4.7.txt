v4.7 UPDATE — EMBED MAKER, LINK GAMERTAG, KICK ME, PLAYTIME LEADERBOARD, NOTIFIERS
=====================================================================================
Everything from v4.6 still works. Copy your old "data" folder and .env over like usual.
New .env lines are already added at the bottom of your .env (they start empty).

ORDER TO SET IT UP (about 15 minutes)
  1. /linknitrado                  link Nitrado (one token, servers found automatically)
  2. /logs-setup staff_role:@Staff  start reading your server logs (needed for log notifiers)
  3. Xbox linking setup             see "LINK GAMERTAG SETUP" below (one time)
  4. /xbox setup                    linked role + staff log channel
  5. /embed create                  post the Link Gamertag, Kick Me and Playtime panels
  6. /cluster create + add-server   group servers for the leaderboard
  7. /notifier create               OSD / node / joins / server status posts


1) LINK NITRADO — /linknitrado
-------------------------------
Easiest possible way: ONE token, nothing else.
  - Run /linknitrado. Press "Get my token" -> log in to Nitrado -> make a Long-life token
    (tick every permission). If that button's page has moved, it is under your Nitrado
    account settings -> Developer / Long-life tokens.
  - Press "Paste token", paste it, submit.
  - Every ARK: Survival Evolved server on that account (Xbox / Win10 / PC) is found and
    saved. No service IDs to copy. Run /linknitrado again any time you buy a new server.
  The token is only saved in .env on your PC. It is never shown in Discord.
  (Old commands still work: /nitrado setup, /nitrado refresh, /nitrado serverlist.)


2) EMBED MAKER — /embed
------------------------
/embed create name:<anything> type:<Custom | Link Gamertag | Kick Me | Playtime Leaderboard>
  Opens a live editor only you can see, with a preview:
    ✏️ Text            message text above the embed, title, description, footer, color
    🖼️ Images          thumbnail, big image, author name/icon, title link
                        (type "server" as the thumbnail to use your server icon)
    🔤 Title Font      cycles Normal / 𝐁𝐨𝐥𝐝 𝐒𝐞𝐫𝐢𝐟 / 𝗕𝗼𝗹𝗱 𝗦𝗮𝗻𝘀 / 𝓢𝓬𝓻𝓲𝓹𝓽 / 𝔻𝕠𝕦𝕓𝕝𝕖
    🔘 Buttons & Menu  Connect/Kick Me button text + color, dropdown placeholder, timestamp
    ➕ / ➖ Field        add / remove fields
    🔗 Link Button     add a button that opens a website
    📤 channel picker  posts it (or moves it). After posting, every edit updates it live.
/embed edit, /embed list, /embed delete
/embed media           upload an image file straight into an embed (no links needed)

Placeholders you can type anywhere in the text:
  {server}             your Discord server name
  {link_channel}       channel where the Link Gamertag panel is posted
  {kickme_channel}     channel where the Kick Me panel is posted
  {playtime_channel}   channel where the Playtime panel is posted
  {#channel-name}      any channel by name, e.g. {#rules}

The 3 panel types come pre-written to match the style you sent, already working:
  Link Gamertag -> "Connect" button     Kick Me -> "Kick Me" button
  Playtime Leaderboard -> "Choose a leaderboard..." dropdown of your clusters


3) DROPDOWN INFO — /add information   (works like ticket options)
----------------------------------------------------------------
  1. Make + post an embed, e.g. "Duos Server Info" with your rates as the description.
  2. /add information channel:#duos-info
     A form opens: option name (Player Stats), emoji, small text, info title, info content.
     Content tip: start lines with "- " for bullets and wrap values in `backticks`:
        - ➕ `+12.5`
        - ⚡ `+50`
  3. The "Choose an option..." dropdown appears under the embed. Members pick an option
     and get that info privately ("Only you can see this").
  Extras:  image:<upload>  and  color:#1E90FF  on /add information
           edit:<option>   on /add information to change an existing option
           /remove information channel option
  If a channel has more than one saved embed, also pick embed:.


4) LINK GAMERTAG SETUP (one time) — the Connect button
--------------------------------------------------------
How it works for players (same as the big ARK servers):
  Discord Settings -> Connections -> Xbox, then press Connect on your panel and approve.
  The bot reads the Xbox account Discord already verified, so nobody can link someone
  else's gamertag, and no passwords are ever involved.

For that, Discord has to send the player back to your bot once, so the bot needs a public
web address. Steps:
  a) Discord Developer Portal -> your bot -> OAuth2:
       - press Reset Secret, copy it into .env:   DISCORD_CLIENT_SECRET=...
  b) Give the bot a public address (pick ONE):
       FREE + EASIEST TO KEEP RUNNING: Cloudflare Tunnel (needs a domain on Cloudflare,
       ~$10/year). Cloudflare dashboard -> Zero Trust -> Networks -> Tunnels -> Create
       a tunnel -> run the install command it shows on this PC -> add a Public Hostname
       like link.yourdomain.com pointing to http://localhost:8080
       -> .env:  LINK_PUBLIC_URL=https://link.yourdomain.com
       QUICK TEST, NO DOMAIN: download cloudflared.exe and run
       cloudflared tunnel --url http://localhost:8080
       It prints a https://something.trycloudflare.com address. Put that in
       LINK_PUBLIC_URL. (That address changes every time you restart it, so use the
       domain way for your real server.)
       OR: if the bot runs on a VPS, use that VPS address.
  c) Back in Developer Portal -> OAuth2 -> Redirects -> Add Redirect:
       <your LINK_PUBLIC_URL>/callback      e.g. https://link.yourdomain.com/callback
     It must match exactly. Save Changes.
  d) Restart the bot. Run /xbox status — everything should be ✅.

No time for that yet? /xbox setup allow_manual:True log_channel:#staff-links
  Players then type their gamertag and staff press Approve/Deny in that channel.
  Kick Me only works for approved/verified links.

/xbox setup      linked_role, log_channel, allow_manual, kick_cooldown_minutes, kick_method
/xbox status     shows what is missing
/xbox lookup     member -> gamertag, or gamertag -> member   (staff)
/xbox force-link /xbox unlink                                 (staff)
/xbox me  /xbox unlink-me                                     (anyone)
Verified links also fill in /link view, so prize claims show the right gamertag.


5) KICK ME
----------
Press Kick Me -> the bot finds your linked gamertag online on any of your Nitrado servers
and kicks it (cooldown 5 min by default).
kick_method (in /xbox setup):
  Auto (default)   uses Nitrado's kick if it offers one for that server, otherwise
                   bans then unbans after KICK_UNBAN_DELAY seconds (the usual console trick)
  Kick only / Ban + instant unban
Safety: an unban that fails is retried every 30 seconds until it works, and staff get a
message in the log channel. TEST IT ON YOURSELF ONCE after setup.


6) PLAYTIME LEADERBOARD — /cluster
-----------------------------------
Every minute the bot checks who is online on every linked server and adds up their time
(bot downtime never counts). No log feed needed.
  /cluster create name:Duos role:@Duos Playtime Record Holder
  /cluster add-server cluster:Duos server:<pick from list>
  /cluster role   /cluster remove-server   /cluster delete   /cluster list
  /cluster top                 public top 10
  /cluster announce-channel    shout-out when someone takes the record
  /cluster reset-playtime      wipe time after a server wipe (type RESET)
The panel's dropdown lists your clusters and shows the top 3 privately, plus the
viewer's own rank. Every 10 minutes the top LINKED player in each cluster gets that
cluster's role (and the old holder loses it). No clusters yet = "All servers".


7) NOTIFIERS — /notifier
--------------------------
/notifier create name channel preset [server] [ping_role] [cooldown_seconds]
  Presets:
    OSD, Element Node, Asteroid   -> embeds like your screenshots (Lat/Lon boxes, map name)
    Player joined / left          -> from the server log
    Tribe dino killed             -> from the tribe log lines
    Server online / offline       -> watches Nitrado status (no log feed needed)
    Custom log pattern            -> your own text to look for
    Manual                        -> staff post it with /notifier send
/notifier edit     title / fields / description / color / image link
                   Fields format:  Lat={lat}|Lon={lon}   (values show in colored boxes)
/notifier image    upload the picture (the OSD / node / asteroid screenshot)
/notifier send     post it now; a form asks for the values (lat, lon, color, map...)
/notifier test     paste a real log line to see if it would trigger
/notifier pattern  change what it looks for (regex; (?P<lat>...) becomes {lat})
/notifier list | toggle | delete
Log notifiers need the log feed running: /logs-setup staff_role:@Staff


IMPORTANT — READ THIS
---------------------
* OSD / Element Node / Asteroid spawns: as far as I could find, ARK: Survival Evolved on
  Xbox / Win10 does not write these spawns into the server log Nitrado gives access to.
  So those presets only fire if your log really contains such lines (check with
  /nitrado logs). If it doesn't, use the Manual preset + /notifier send and they still
  look exactly like the screenshots. Joins, leaves, tribe logs and server status come
  from real data and work automatically.
* Beacon: for ASE, Beacon is a config editor. Its live server monitoring (Sentinel) is
  built for ARK: Survival Ascended, so there is nothing in Beacon for this bot to plug
  into. Keep using Beacon to edit your ini settings; everything in this bot goes through
  your Nitrado token.
* Kick Me on Xbox: Nitrado may not offer a direct kick for console ASE; Auto mode falls
  back to ban + unban. Test once with your own gamertag.
* Playtime counts from the moment you update. It only counts what Nitrado reports as
  online — check /nitrado players shows people online for your servers.
* New dependencies: none. Just copy the files over and run START-BOT.bat.
